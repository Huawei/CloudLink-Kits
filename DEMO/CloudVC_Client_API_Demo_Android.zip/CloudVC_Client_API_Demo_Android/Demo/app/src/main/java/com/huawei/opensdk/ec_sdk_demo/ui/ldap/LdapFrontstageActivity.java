package com.huawei.opensdk.ec_sdk_demo.ui.ldap;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Handler;
import android.os.Message;
import android.text.TextUtils;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;
import com.huawei.ecterminalsdk.base.TsdkLdapContactsInfo;
import com.huawei.ecterminalsdk.base.TsdkOnEvtSearchLdapContactsResult;
import com.huawei.ecterminalsdk.base.TsdkPageCookieData;
import com.huawei.ecterminalsdk.models.ldap.TsdkLdapFrontstageManager;
import com.huawei.opensdk.commonservice.common.LocContext;
import com.huawei.opensdk.commonservice.util.LogUtil;
import com.huawei.opensdk.contactservice.ldap.ILdapFrontstageNotification;
import com.huawei.opensdk.contactservice.ldap.LdapFrontstageConstant;
import com.huawei.opensdk.contactservice.ldap.LdapFrontstageMgr;
import com.huawei.opensdk.ec_sdk_demo.R;
import com.huawei.opensdk.ec_sdk_demo.adapter.LdapFrontstageListAdapter;
import com.huawei.opensdk.ec_sdk_demo.adapter.LdapOuListAdapter;
import com.huawei.opensdk.ec_sdk_demo.beans.DeptDataInfo;
import com.huawei.opensdk.ec_sdk_demo.common.UIConstants;
import com.huawei.opensdk.ec_sdk_demo.interfaces.IOnClickListener;
import com.huawei.opensdk.ec_sdk_demo.ui.IntentConstant;
import com.huawei.opensdk.ec_sdk_demo.ui.base.BaseActivity;
import com.huawei.opensdk.ec_sdk_demo.util.ActivityUtil;

import java.util.ArrayList;

/**
 * This class is about search contacts activity.
 */
public class LdapFrontstageActivity extends BaseActivity implements View.OnClickListener,
        AdapterView.OnItemClickListener, ILdapFrontstageNotification, AdapterView.OnItemLongClickListener, IOnClickListener {

    private ImageView ldapBack;
    private EditText ldapKeys;
    private ImageView ldapSearch;
    private TextView ldapNext;
    private TextView tvRoot;
    private ListView ouListView;
    private View vLine;
    private ListView ldapList;
    private Toast toast;
    private LdapOuListAdapter ldapOuListAdapter;
    private LdapFrontstageListAdapter ldapFrontstageListAdapter;

    private ArrayList<TsdkLdapContactsInfo> ldapContactsList;
    private ProgressDialog mDialog;
    private boolean isSearchGroup = false;
    private String corpName = "";
    private int searchSingleLevel = 0;
    private int cookieLen = 0;
    private ArrayList<TsdkPageCookieData> pageCookie;
    private int pageSize = 10;

    public ArrayList<TsdkLdapContactsInfo> getList() {
        return ldapContactsList;
    }

    private int searchSeq = -1;


    /**
     * Waiting for querying a contact ID, In this user interface invokes the query again,
     * Ensure that in the last query results after
     * 等候查询联系人的标示，在本界面再次调用查询的时，必须保证在上次的查询结果出来之后进行
     */
    private boolean waitSearch = true;

    @Override
    public void initializeComposition() {
        setContentView(R.layout.activity_enterprise_addr_book);
        ldapBack = (ImageView)findViewById(R.id.book_back);
        ldapKeys = (EditText)findViewById(R.id.book_keys);
        ldapSearch = (ImageView)findViewById(R.id.book_right);
        ldapNext = (TextView)findViewById(R.id.next);

        tvRoot = (TextView)findViewById(R.id.tv_root);
        ouListView = (ListView)findViewById(R.id.ou_list);
        vLine = findViewById(R.id.v_line);
        ldapList = (ListView)findViewById(R.id.search_list);

        tvRoot.setVisibility(View.VISIBLE);
        ouListView.setVisibility(View.VISIBLE);
        vLine.setVisibility(View.VISIBLE);

        ldapContactsList = new ArrayList<>();
        pageCookie = new ArrayList<>();

        ldapOuListAdapter = new LdapOuListAdapter(this);
        ouListView.setAdapter(ldapOuListAdapter);
        ldapOuListAdapter.setOnClickListener(this);
        ldapOuListAdapter.notifyDataSetChanged();

        ldapFrontstageListAdapter = new LdapFrontstageListAdapter(this,ldapContactsList);
        ldapList.setAdapter(ldapFrontstageListAdapter);
        ldapFrontstageListAdapter.notifyDataSetChanged();

        ldapBack.setOnClickListener(this);
        ldapSearch.setOnClickListener(this);
        ldapNext.setOnClickListener(this);
        ldapList.setOnItemClickListener(this);
        ldapList.setOnItemLongClickListener(this);

        LdapFrontstageMgr.getInstance().registerNotification(this);

        //调搜索的接口获取分组
        searchGroup("",corpName,"",searchSingleLevel,0,0, new ArrayList<TsdkPageCookieData>());
    }

    @Override
    public void initializeData() {

    }

    /**
     * This method is used to show Toast content.
     * @param text Indicates show content
     */
    public void showToast(String text) {
        if (toast == null) {
            toast = Toast.makeText(this, text, Toast.LENGTH_SHORT);
        } else {
            toast.setText(text);
            toast.setDuration(Toast.LENGTH_SHORT);
        }
        toast.show();
    }

    /**
     * This method is used to cancel Toast content.
     */
    public void cancelToast() {
        if (toast != null) {
            toast.cancel();
        }
    }

    @Override
    public void onBackPressed() {
        cancelToast();
        super.onBackPressed();
    }

    @Override
    public void IOnClick(int position) {
        ArrayList<DeptDataInfo> deptDataList = ldapOuListAdapter.getDeptDataList();
        corpName = deptDataList.get(position).getCorpName();
        // searchSingleLevel = 2 搜索特定目录单级搜索，只返回这个节点的子节点内容
        searchSingleLevel = 2;
        searchGroup("*", corpName, "", searchSingleLevel, pageSize, 0, new ArrayList<TsdkPageCookieData>());
        ldapKeys.setText("");
    }

    public void searchGroup(String keyWords, String currentBaseDN, String sortAttribute, int searchSingleLevel, int pageSize, int cookieLength, ArrayList<TsdkPageCookieData> pageCookie) {
        showLoginDialog("搜索中");
        int result = LdapFrontstageMgr.getInstance().searchLdapContacts(keyWords,currentBaseDN,sortAttribute, searchSingleLevel, pageSize, cookieLength, pageCookie);
        if (result == 0){
            searchSeq = TsdkLdapFrontstageManager.getObject().getSeqNo();
        } else {
            dismissLoginDialog();
            showToast("search failed");
        }
        waitSearch = false;
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.book_back:
                finish();
                break;
            case R.id.next:
                //加载下一页
                if (ldapContactsList.size() >0) {
                    if (cookieLen != 0){
                        String keyText = ldapKeys.getText().toString();
                        if (waitSearch) {
                            if (TextUtils.isEmpty(keyText)) {
                                keyText = "*";
                            }
                            searchGroup(keyText,corpName,"",searchSingleLevel, pageSize, cookieLen, pageCookie);
                        } else {
                            showToast("Querying, Please try again later...");
                        }
                    } else {
                        showToast("no data ...");
                    }
                } else {
                    showToast("no data ...");
                }
                break;
            case R.id.book_right:
                String keywords = ldapKeys.getText().toString();
                if (waitSearch) {
                    if (TextUtils.isEmpty(corpName)) {
                        searchGroup(keywords, corpName, "", searchSingleLevel, 0, 0, new ArrayList<TsdkPageCookieData>());
                    } else {
                        if (TextUtils.isEmpty(keywords)) {
                            keywords = "*";
                        }
                        searchGroup(keywords, corpName, "", searchSingleLevel, pageSize, 0, new ArrayList<TsdkPageCookieData>());
                    }
                } else {
                    showToast("Querying, Please try again later...");
                }
                break;
            default:
                break;
        }
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

        TsdkLdapContactsInfo tsdkLdapContactsInfo = ldapContactsList.get(position);
        Intent intent = new Intent(IntentConstant.LDAP_FRONTSTAGE_DETAIL_ACTIVITY_ACTION);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        intent.addCategory(IntentConstant.DEFAULT_CATEGORY);
        intent.putExtra(UIConstants.LDAP_CONTACTS_INFO, tsdkLdapContactsInfo);
        ActivityUtil.startActivity(LocContext.getContext(),intent);
    }

    @Override
    public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
        showToast("onItemLongClick : " + String.valueOf(position));
        return true;
    }

    private Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {

            dismissLoginDialog();

            switch (msg.what) {
                case UIConstants.ENTERPRISE_SEARCH_FAILED:
                    waitSearch = true;
                    showToast("Search contact failed!");
                    break;
                case UIConstants.ENTERPRISE_SEARCH_NULL:
                    ldapContactsList.clear();
                    ldapFrontstageListAdapter.notifyDataSetChanged(ldapContactsList);
                    waitSearch = true;
                    showToast("There is no inquiry to the contact!");
                    break;
                case UIConstants.ENTERPRISE_SEARCH_SUCCESS:
                    TsdkOnEvtSearchLdapContactsResult.Param searchParamResult = (TsdkOnEvtSearchLdapContactsResult.Param) msg.obj;
                    if (searchParamResult.getSeqNo() == searchSeq)
                    {
                        ArrayList<TsdkLdapContactsInfo> ldapContactList = searchParamResult.getSearchResultData().getLdapContactList();
                        cookieLen = searchParamResult.getCookieLen();
                        pageCookie = searchParamResult.getPageCookie();

                        ArrayList<TsdkLdapContactsInfo> deptInfosList = new ArrayList<>();
                        ArrayList<TsdkLdapContactsInfo> contactsInfosList = new ArrayList<>();

                        for (TsdkLdapContactsInfo  ldapContactsInfo: ldapContactList) {
                            String deptName = ldapContactsInfo.getDeptName();
                            String name = ldapContactsInfo.getName();
                            String ucAcc = ldapContactsInfo.getUcAcc();

                            if (TextUtils.isEmpty(name) && !TextUtils.isEmpty(deptName)) {
                                //分组数据
                                deptInfosList.add(ldapContactsInfo);
                            } else if (!TextUtils.isEmpty(name) && !TextUtils.isEmpty(ucAcc)) {
                                //联系人数据
                                contactsInfosList.add(ldapContactsInfo);
                            } else if (!TextUtils.isEmpty(name) && TextUtils.isEmpty(deptName)) {
                                //特殊联系人数据
                                contactsInfosList.add(ldapContactsInfo);
                            } else {
                                LogUtil.e(LdapFrontstageActivity.class.getSimpleName(), "contacts data no match" );
                            }
                        }

                        ArrayList<DeptDataInfo> deptNameList = getdeptDataList(deptInfosList);
                        if (deptNameList.size() >0) {
                            if (!isSearchGroup){
                                ldapOuListAdapter.setDeptDataList(deptNameList);
                                ldapOuListAdapter.notifyDataSetChanged();
                                isSearchGroup = true;
                                String ldapGroupStr = new Gson().toJson(deptInfosList);
                                LogUtil.i("LDAP_GROUP", ldapGroupStr);
                            }
                        }

                        if (contactsInfosList.size() >0) {
                            ldapContactsList = contactsInfosList;
                            ldapFrontstageListAdapter.notifyDataSetChanged(ldapContactsList);
                        }
                    }
                    waitSearch = true;
                    break;
                default:
                    break;
            }
        }
    };

    private ArrayList<DeptDataInfo> getdeptDataList(ArrayList<TsdkLdapContactsInfo> deptInfosList) {
        ArrayList<String> deptStrList = new ArrayList<>();
        ArrayList<DeptDataInfo> deptDataInfoList = new ArrayList<>();
        if (deptInfosList.size() >0) {
            //组装数据
            for (TsdkLdapContactsInfo  deptInfos: deptInfosList) {
                String corpName = deptInfos.getCorpName();
                String deptName = deptInfos.getDeptName();
                if (!TextUtils.isEmpty(corpName)){
                    String[] corpNameArr = corpName.split(",");//corpNameSplitStr
                    ArrayList<String> corpNameList = new ArrayList<>();
                    for (String cName: corpNameArr) {
                        if (cName.contains("ou=")) {
                            corpNameList.add(cName);
                        }
                    }
                    if (corpNameList.size()>0){
                        String firstLevelName = corpNameList.get(corpNameList.size()-1);
                        if (!deptStrList.contains(firstLevelName)){
                            deptStrList.add(firstLevelName);
                            DeptDataInfo deptDataInfo = new DeptDataInfo(corpName,deptName);
                            deptDataInfoList.add(deptDataInfo);
                        }
                    }
                } else {
                    LogUtil.e(LdapFrontstageActivity.class.getSimpleName(), "corpName is null" );
                }
            }
        }
        return deptDataInfoList;
    }

    @Override
    public void onEntLdapFrontstageNotify(LdapFrontstageConstant.Event event, Object obj) {
        switch (event)
        {
            case SEARCH_CONTACTS_FAILED:
                Message msgContactFailed = handler.obtainMessage(UIConstants.ENTERPRISE_SEARCH_FAILED, obj);
                handler.sendMessage(msgContactFailed);
                break;
            case SEARCH_CONTACTS_NOT_FOUND:
                Message msgContactNull = handler.obtainMessage(UIConstants.ENTERPRISE_SEARCH_NULL, obj);
                handler.sendMessage(msgContactNull);
                break;
            case SEARCH_CONTACTS_COMPLETE:
                Message msgContactSuccess = handler.obtainMessage(UIConstants.ENTERPRISE_SEARCH_SUCCESS, obj);
                handler.sendMessage(msgContactSuccess);
                break;
            default:
                break;
        }
    }

    public void showLoginDialog(String msg) {
        if (null == mDialog)
        {
            mDialog = new ProgressDialog(this);
        }

        mDialog.setCanceledOnTouchOutside(false);
        mDialog.setTitle(msg);
        mDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        mDialog.show();
    }

    public void dismissLoginDialog()
    {
        if (mDialog != null && mDialog.isShowing()){
            mDialog.dismiss();
            mDialog = null;
        }
    }
}
