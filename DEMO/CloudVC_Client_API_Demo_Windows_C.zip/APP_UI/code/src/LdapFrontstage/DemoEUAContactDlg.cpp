//
//  DemoEUAContactDlg.cpp
//  EC_SDK_DEMO
//
//  Created by EC Open support team.
//  Copyright(C), 2018, Huawei Tech. Co., Ltd. ALL RIGHTS RESERVED.
//
#include <afxpriv.h>
#include "stdafx.h"
#include "afxdialogex.h"
#include "DemoData.h"
#include "DemoCommonTools.h"
#include "DemoEUAContactDlg.h"
#include "service_tools.h"
#include "service_call_interface.h"
#include "tsdk_ldap_frontstage_def.h"
#include "service_ldap_interface.h"
#include "service_os_adapt.h"
#include "SearchResultDetailDlg.h"


// DemoEUAContactDlg dialog

IMPLEMENT_DYNAMIC(CDemoEUAContactDlg, CDialogEx)

CDemoEUAContactDlg::CDemoEUAContactDlg(CWnd* pParent /*=NULL*/)
    : CDialogEx(CDemoEUAContactDlg::IDD, pParent)
{
    m_cookie_len = 0;
    memset(m_page_cookie, 0, 100);
}

CDemoEUAContactDlg::~CDemoEUAContactDlg()
{

}

void CDemoEUAContactDlg::DoDataExchange(CDataExchange* pDX)
{
    CDialogEx::DoDataExchange(pDX);
    DDX_Control(pDX, IDC_DEPARTMENT_TREE, m_treeContactDepartmentList);
    DDX_Control(pDX, IDC_EDIT_KEYWORDS, m_editSearchKeyWord);
    DDX_Control(pDX, IDC_EDIT_PAGE_SIZE, m_editPageSize);
    DDX_Control(pDX, IDC_SEARCH_RESULT_LIST, m_listBoxSearchResult);
}

BEGIN_MESSAGE_MAP(CDemoEUAContactDlg, CDialogEx)
    ON_BN_CLICKED(IDC_SEARCH_BTN, &CDemoEUAContactDlg::OnBnClickedGetSearchlist)
    //ON_BN_CLICKED(IDC_BT_CREATE_CONF, &CDemoMeetingDlg::OnBnClickedCreateConf)
    //ON_BN_CLICKED(IDC_BT_JOIN_CONF, &CDemoMeetingDlg::OnBnClickedJoinConf)
    //ON_NOTIFY(NM_DBLCLK, IDC_TREE_MEETINGLIST, &CDemoMeetingDlg::OnNMDblclkTreeMeetingList)
    //ON_NOTIFY(NM_RCLICK, IDC_TREE_MEETINGLIST, &CDemoMeetingDlg::OnNMRClickTreeMeetingList)
    //ON_COMMAND_RANGE(ID_CONF_JOIN_MENU, ID_CONF_DETAIL_MENU, &CDemoMeetingDlg::OnClickMeetingMenuItem)
    ON_MESSAGE(WM_LDAP_FRONTSTAGE_GET_SEARCH_LIST_RESULT, &CDemoEUAContactDlg::OnGetSearchResultList)
    //ON_MESSAGE(WM_CONF_CTRL_GET_CONF_INFO_RESULT, &CDemoMeetingDlg::OnGetConfDetail)
    ON_NOTIFY(TVN_SELCHANGED, IDC_DEPARTMENT_TREE, &CDemoEUAContactDlg::OnTvnSelchangedDepartmentTree)
    ON_BN_CLICKED(IDC_BUTTON_NEXT_PAGE, &CDemoEUAContactDlg::OnNextPageBtnClicked)
    ON_NOTIFY(HDN_ITEMCLICK, 0, &CDemoEUAContactDlg::OnResultListItemClick)
    ON_NOTIFY(NM_CLICK, IDC_SEARCH_RESULT_LIST, &CDemoEUAContactDlg::OnResultListNMClick)
    ON_WM_CLOSE()
    ON_WM_DESTROY()
END_MESSAGE_MAP()

// CDemoMeetingDlg message handlers
BOOL CDemoEUAContactDlg::OnInitDialog()
{
    CDialogEx::OnInitDialog();

    m_editPageSize.SetWindowTextW(0);
    
    m_listBoxSearchResult.InsertColumn(0, _T("����"), LVCFMT_LEFT, 60, - 1);
    m_listBoxSearchResult.InsertColumn(1, _T("����"), LVCFMT_LEFT, 80, -1);
    m_listBoxSearchResult.InsertColumn(2, _T("����"), LVCFMT_LEFT, 60, -1);
    m_listBoxSearchResult.InsertColumn(3, _T("�ƶ��绰"), LVCFMT_LEFT, 80, -1);
    m_listBoxSearchResult.InsertColumn(4, _T("�칫�绰"), LVCFMT_LEFT, 80, -1);
    m_listBoxSearchResult.InsertColumn(5, _T("��������"), LVCFMT_LEFT, 80, -1);
    m_listBoxSearchResult.InsertColumn(6, _T("��ַ"), LVCFMT_LEFT, 60, -1);
    m_listBoxSearchResult.SetExtendedStyle(LVS_EX_GRIDLINES | LVS_EX_FULLROWSELECT);

    /*m_listBoxSearchResult.DeleteAllItems();
    m_listBoxSearchResult.InsertItem(0, _T("��ΰ"));
    m_listBoxSearchResult.SetItemText(0, 1, _T("13088960840"));
    m_listBoxSearchResult.SetItemText(0, 2, _T("SIP"));
    m_listBoxSearchResult.SetItemText(0, 3, _T("13088960840"));
    m_listBoxSearchResult.SetItemText(0, 4, _T("02912345678"));
    m_listBoxSearchResult.SetItemText(0, 5, _T("gaow_1985@163.com"));
    m_listBoxSearchResult.SetItemText(0, 6, _T("����ʡ������"));*/

    m_tree_root = m_treeContactDepartmentList.InsertItem(_T("ROOT"), TVI_ROOT);

    TSDK_S_SEARCH_CONDITION search_condition;
    search_condition.keywords = "";
    search_condition.page_size = 0;
    search_condition.sort_attribute = TSDK_NULL_PTR;
    search_condition.search_single_level = 0;
    search_condition.page_cookie = TSDK_NULL_PTR;
    search_condition.cookie_length = 0;

    unsigned int seq_no = 0;
    if (0 != service_ldap_search(&search_condition, &seq_no))
    {
        AfxMessageBox(_T("call service ldap search failed!"));
        return FALSE;
    }
    g_current_seq_no = seq_no;

    return TRUE;
}

void CDemoEUAContactDlg::OnBnClickedGetSearchlist()
{
    m_editSearchKeyWord.GetWindowTextW(m_SearchKeyWordString);
    if (m_SearchKeyWordString.IsEmpty())
    {
        AfxMessageBox(_T("Search KeyWord is empty!"));
        return;
    }

    std::string searchKeyWord = CTools::UNICODE2UTF(m_SearchKeyWordString);
    unsigned int nlen = searchKeyWord.length();
    char* pszSearchKeyWord = new char[nlen + 1];
    service_memset_s(pszSearchKeyWord, nlen + 1, 0, nlen + 1);
    strncpy_s(pszSearchKeyWord, nlen + 1, searchKeyWord.c_str(), _TRUNCATE);

    m_editPageSize.GetWindowTextW(m_PageSizeString);
    CString strPageSize = m_PageSizeString.SpanIncluding(_T("0123456789"));
    if (m_PageSizeString.IsEmpty() || m_PageSizeString != strPageSize)
    {
        AfxMessageBox(_T("please input valid page size!"));
        return;
    }

    //������ʶ
    USES_CONVERSION;
    //����T2A��W2A��֧��ATL��MFC�е��ַ�
    char * strptrPageSize = T2A(m_PageSizeString);

    TSDK_S_SEARCH_CONDITION search_condition;
    search_condition.keywords = pszSearchKeyWord;
    search_condition.page_size = atoi(strptrPageSize);
    search_condition.sort_attribute = TSDK_NULL_PTR;
    search_condition.search_single_level = 0;
    search_condition.page_cookie = TSDK_NULL_PTR;
    search_condition.cookie_length = 0;

    unsigned int seq_no = 0;
    if (0 != service_ldap_search(&search_condition, &seq_no))
    {
        AfxMessageBox(_T("call service ldap search failed!"));
        return;
    }
    g_current_seq_no = seq_no;
}

LRESULT CDemoEUAContactDlg::OnGetSearchResultList(WPARAM wParam, LPARAM lparam)
{
    unsigned int index = 0;
    CHECK_POINTER_RETURN(wParam, -1L);
    TSDK_S_LDAP_SEARCH_RESULT_INFO* notifyInfo = (TSDK_S_LDAP_SEARCH_RESULT_INFO*)wParam;

    for (int n = 0; n < m_listBoxSearchResult.GetItemCount(); n++)
    {
        TSDK_S_LDAP_CONTACT * temContact = (TSDK_S_LDAP_CONTACT *)m_listBoxSearchResult.GetItemData(n);
        if (temContact != NULL)
        {
            delete temContact;
        }
    }
    m_listBoxSearchResult.DeleteAllItems();

    int listBoxSearchResultRowNum = 0;
    if (notifyInfo != TSDK_NULL_PTR && g_current_seq_no == notifyInfo->seq_no)
    {
        if (notifyInfo->cookie_len > 0)
        {
            m_cookie_len = notifyInfo->cookie_len;
            memset(m_page_cookie, 0, 100);
            memcpy(m_page_cookie, notifyInfo->page_cookie, m_cookie_len);
            //AfxMessageBox(CTools::UTF2UNICODE(m_page_cookie));
        }
        m_treeContactDepartmentList.Expand(m_tree_root, TVE_EXPAND);
        for (index = 0; index < notifyInfo->search_result_data->current_count; index++)
        {
            if (strlen(notifyInfo->search_result_data->contact_list[index].name_) == 0
                && strlen(notifyInfo->search_result_data->contact_list[index].deptName_) > 0)
            {
                //m_treeContactDepartmentList.ItemHasChildren
                CString corpName = CTools::UTF2UNICODE(notifyInfo->search_result_data->contact_list[index].corpName_);
                CString groupName;
                vector<CString> parentName;
                int ouCount = 0;
                int Position = 0;
                CString Token;
                Token = corpName.Tokenize(_T(","), Position);
                while (!Token.IsEmpty())
                {
                    int indexOfOU = Token.Find(_T("ou="));
                    if (indexOfOU < 0)
                    {
                        Token = corpName.Tokenize(_T(","), Position);
                        continue;
                    }
                    CString tmpGroupName = Token.Mid(indexOfOU + strlen("ou="));
                    if (ouCount > 0)
                    {
                        parentName.push_back(tmpGroupName);
                    }
                    else
                    {
                        groupName = tmpGroupName;
                    }
                    ouCount++;
                    Token = corpName.Tokenize(_T(","), Position);
                }

                if (!groupName.IsEmpty())
                {
                    if (parentName.empty())
                    {
                        if (m_treeContactDepartmentList.ItemHasChildren(m_tree_root))
                        {
                            bool find = false;
                            HTREEITEM hChild = m_treeContactDepartmentList.GetChildItem(m_tree_root);
                            while (hChild)
                            {
                                CString     cstrNodeOU = m_treeContactDepartmentList.GetItemText(hChild);
                                if (cstrNodeOU == groupName)
                                { 
                                    find = true;
                                    break;
                                }
                                else 
                                {
                                    hChild = m_treeContactDepartmentList.GetNextItem(hChild, TVGN_NEXT);
                                }
                            }
                            if (find)
                            {
                                continue;
                            }
                        }
                        HTREEITEM insertItemNode = m_treeContactDepartmentList.InsertItem(groupName, m_tree_root);
                        m_treeContactDepartmentList.Expand(m_tree_root, TVE_EXPAND);
                        char *charPtrTempNode = new char[100];
                        memset(charPtrTempNode, 0, 100);
                        CTools::CString2Char(corpName, charPtrTempNode, 100);
                        m_treeContactDepartmentList.SetItemData(insertItemNode, (DWORD_PTR)charPtrTempNode);
                    }
                    else
                    {
                        vector<CString>::reverse_iterator iteratorOU = parentName.rbegin();
                        HTREEITEM parentNode = m_tree_root;
                        while (iteratorOU != parentName.rend())
                        {
                            HTREEITEM tmpParentNode = parentNode;
                            CString tempNode = *iteratorOU;
                            HTREEITEM hFind = m_treeContactDepartmentList.GetChildItem(parentNode);
                            while (hFind != NULL)
                            {
                                CString findNode = m_treeContactDepartmentList.GetItemText(hFind);
                                if (findNode == tempNode)
                                {
                                    parentNode = hFind;
                                    break;
                                }
                                else
                                {
                                    hFind = m_treeContactDepartmentList.GetNextSiblingItem(hFind);
                                }
                            }

                            if (tmpParentNode == parentNode)
                            {
                                HTREEITEM insertItem = m_treeContactDepartmentList.InsertItem(tempNode, parentNode);
                                char *charPtrTempNode = new char[100];
                                memset(charPtrTempNode, 0, 100);
                                CTools::CString2Char(corpName, charPtrTempNode, 100);
                                m_treeContactDepartmentList.SetItemData(insertItem, (DWORD_PTR)charPtrTempNode);
                                m_treeContactDepartmentList.Expand(parentNode, TVE_EXPAND);
                                parentNode = insertItem;
                            }
                            
                            iteratorOU++;
                        }

                        if (m_treeContactDepartmentList.ItemHasChildren(parentNode))
                        {
                            bool find = false;
                            HTREEITEM hChild = m_treeContactDepartmentList.GetChildItem(parentNode);
                            while (hChild)
                            {
                                CString     cstrNodeOU = m_treeContactDepartmentList.GetItemText(hChild);
                                if (cstrNodeOU == groupName)
                                {
                                    find = true;
                                    break;
                                }
                                else
                                {
                                    hChild = m_treeContactDepartmentList.GetNextItem(hChild, TVGN_NEXT);
                                }
                            }
                            if (find)
                            {
                                continue;
                            }
                        }
                        HTREEITEM insertItemNode = m_treeContactDepartmentList.InsertItem(groupName, parentNode);
                        m_treeContactDepartmentList.Expand(parentNode, TVE_EXPAND);
                        char *charPtrTempNode = new char[100];
                        memset(charPtrTempNode, 0, 100);
                        CTools::CString2Char(corpName, charPtrTempNode, 100);
                        m_treeContactDepartmentList.SetItemData(insertItemNode, (DWORD_PTR)charPtrTempNode);
                    }
                }
            }
            else if(strlen(notifyInfo->search_result_data->contact_list[index].name_) > 0 
                && strlen(notifyInfo->search_result_data->contact_list[index].ucAcc_) > 0)
            {
                m_listBoxSearchResult.InsertItem(listBoxSearchResultRowNum, CTools::UTF2UNICODE(notifyInfo->search_result_data->contact_list[index].name_));
                m_listBoxSearchResult.SetItemText(listBoxSearchResultRowNum, 1, CTools::UTF2UNICODE(notifyInfo->search_result_data->contact_list[index].ucAcc_));
                char contactType[20] = { 0 };
                if (0 == strcmp(notifyInfo->search_result_data->contact_list[index].gender_, "6"))
                {
                    strncpy_s(contactType, 20, "SIP", _TRUNCATE);
                }
                m_listBoxSearchResult.SetItemText(listBoxSearchResultRowNum, 2, CTools::UTF2UNICODE(contactType));
                m_listBoxSearchResult.SetItemText(listBoxSearchResultRowNum, 3, CTools::UTF2UNICODE(notifyInfo->search_result_data->contact_list[index].mobile_));
                m_listBoxSearchResult.SetItemText(listBoxSearchResultRowNum, 4, CTools::UTF2UNICODE(notifyInfo->search_result_data->contact_list[index].officePhone_));
                m_listBoxSearchResult.SetItemText(listBoxSearchResultRowNum, 5, CTools::UTF2UNICODE(notifyInfo->search_result_data->contact_list[index].email_));
                m_listBoxSearchResult.SetItemText(listBoxSearchResultRowNum, 6, CTools::UTF2UNICODE(notifyInfo->search_result_data->contact_list[index].address_));
                TSDK_S_LDAP_CONTACT *ldap_contact = new TSDK_S_LDAP_CONTACT;
                memset(ldap_contact, 0, sizeof(TSDK_S_LDAP_CONTACT));
                memcpy(ldap_contact, &(notifyInfo->search_result_data->contact_list[index]), sizeof(TSDK_S_LDAP_CONTACT));
                m_listBoxSearchResult.SetItemData(listBoxSearchResultRowNum, (DWORD_PTR)ldap_contact);
                listBoxSearchResultRowNum++;
            }
        }
    }

    if (notifyInfo != NULL)
    {
        if (notifyInfo->cookie_len > 0)
        {
            delete notifyInfo->page_cookie;
        }

        if (notifyInfo->search_result_data != NULL)
        {
            if (notifyInfo->search_result_data->contact_list != NULL)
            {
                delete notifyInfo->search_result_data->contact_list;
            }
            delete notifyInfo->search_result_data;
        }
        delete notifyInfo;
    }
    

    return 0L;
}

bool CDemoEUAContactDlg::findinExistGroup(CString groupName)
{
    vector<CString>::iterator itor = added_grp_tree_node.begin();
    while (itor != added_grp_tree_node.end())
    {
        CString tempNode = *itor;
        if (tempNode == groupName)
        {
            return true;
        }
        itor++;
    }
    return false;
}

void CDemoEUAContactDlg::ClearSearchResult()
{
    m_listBoxSearchResult.DeleteAllItems();
}

void CDemoEUAContactDlg::OnTvnSelchangedDepartmentTree(NMHDR *pNMHDR, LRESULT *pResult)
{
    *pResult = 0;
    
    char * ptrNodeData = (char *)m_treeContactDepartmentList.GetItemData(m_treeContactDepartmentList.GetSelectedItem());

    m_listBoxSearchResult.DeleteAllItems();

    TSDK_S_SEARCH_CONDITION search_condition;
    search_condition.keywords = "";
    search_condition.curent_base_dn = ptrNodeData;
    search_condition.page_size = 0;
    search_condition.sort_attribute = TSDK_NULL_PTR;
    search_condition.search_single_level = 1;
    search_condition.page_cookie = TSDK_NULL_PTR;
    search_condition.cookie_length = 0;

    unsigned int seq_no = 0;
    if (0 != service_ldap_search(&search_condition, &seq_no))
    {
        AfxMessageBox(_T("call service ldap search failed!"));
        return;
    }
    g_current_seq_no = seq_no;
}


void CDemoEUAContactDlg::OnNextPageBtnClicked()
{
    // TODO: �ڴ����ӿؼ�֪ͨ�����������
    if (m_cookie_len == 0 && m_page_cookie != TSDK_NULL_PTR)
    {
        AfxMessageBox(_T("no page search!"));
        return;
    }

    m_editSearchKeyWord.GetWindowTextW(m_SearchKeyWordString);
    if (m_SearchKeyWordString.IsEmpty())
    {
        AfxMessageBox(_T("Search KeyWord is empty!"));
        return;
    }

    std::string searchKeyWord = CTools::UNICODE2UTF(m_SearchKeyWordString);
    unsigned int nlen = searchKeyWord.length();
    char* pszSearchKeyWord = new char[nlen + 1];
    service_memset_s(pszSearchKeyWord, nlen + 1, 0, nlen + 1);
    strncpy_s(pszSearchKeyWord, nlen + 1, searchKeyWord.c_str(), _TRUNCATE);

    m_editPageSize.GetWindowTextW(m_PageSizeString);
    CString strPageSize = m_PageSizeString.SpanIncluding(_T("0123456789"));
    if (m_PageSizeString.IsEmpty() || m_PageSizeString != strPageSize)
    {
        AfxMessageBox(_T("please input valid page size!"));
        return;
    }

    //������ʶ
    USES_CONVERSION;
    //����T2A��W2A��֧��ATL��MFC�е��ַ�
    char * strptrPageSize = T2A(m_PageSizeString);

    TSDK_S_SEARCH_CONDITION search_condition;
    search_condition.keywords = pszSearchKeyWord;
    search_condition.page_size = atoi(strptrPageSize);
    search_condition.sort_attribute = TSDK_NULL_PTR;
    search_condition.search_single_level = 0;
    search_condition.page_cookie = m_page_cookie;
    search_condition.cookie_length = m_cookie_len;

    unsigned int seq_no = 0;
    if (0 != service_ldap_search(&search_condition, &seq_no))
    {
        AfxMessageBox(_T("call service ldap search failed!"));
        return;
    }
    g_current_seq_no = seq_no;
}


void CDemoEUAContactDlg::OnResultListItemClick(NMHDR *pNMHDR, LRESULT *pResult)
{
    LPNMHEADER phdr = reinterpret_cast<LPNMHEADER>(pNMHDR);
    // TODO: �ڴ����ӿؼ�֪ͨ�����������
    *pResult = 0;

    TSDK_S_LDAP_CONTACT *ldap_contact = (TSDK_S_LDAP_CONTACT *)m_listBoxSearchResult.GetItemData(phdr->iItem);
    //AfxMessageBox(CTools::UTF2UNICODE(ldap_contact->ucAcc_));

    CSearchResultDetailDlg detailDlg = new CSearchResultDetailDlg();
    detailDlg.SetContactData(ldap_contact);
    detailDlg.DoModal();
}


void CDemoEUAContactDlg::OnResultListNMClick(NMHDR *pNMHDR, LRESULT *pResult)
{
    LPNMITEMACTIVATE pNMItemActivate = reinterpret_cast<LPNMITEMACTIVATE>(pNMHDR);
    // TODO: �ڴ����ӿؼ�֪ͨ�����������
    *pResult = 0;

    TSDK_S_LDAP_CONTACT *ldap_contact = (TSDK_S_LDAP_CONTACT *)m_listBoxSearchResult.GetItemData(pNMItemActivate->iItem);
    //AfxMessageBox(CTools::UTF2UNICODE(ldap_contact->ucAcc_));

    CSearchResultDetailDlg detailDlg = new CSearchResultDetailDlg();
    detailDlg.SetContactData(ldap_contact);
    detailDlg.DoModal();
}

void CDemoEUAContactDlg::FreeTreeNodeData(HTREEITEM nodeItem)
{
    if (m_treeContactDepartmentList.ItemHasChildren(nodeItem))
    {
        HTREEITEM childItem = m_treeContactDepartmentList.GetChildItem(nodeItem);
        while (childItem)
        {
            char * treeNodeData = (char *)m_treeContactDepartmentList.GetItemData(childItem);
            if (treeNodeData != NULL)
            {
                delete treeNodeData;
            }

            if (m_treeContactDepartmentList.ItemHasChildren(childItem))
            {
                FreeTreeNodeData(childItem);
            }

            childItem = m_treeContactDepartmentList.GetNextItem(childItem, TVGN_NEXT);
        }
    }
}

void CDemoEUAContactDlg::OnClose()
{
    // TODO: �ڴ�������Ϣ������������/�����Ĭ��ֵ
    //FreeTreeNodeData(m_tree_root);

    CDialogEx::OnClose();
}


void CDemoEUAContactDlg::OnDestroy()
{
    CDialogEx::OnDestroy();

    // TODO: �ڴ˴�������Ϣ�����������
    FreeTreeNodeData(m_tree_root);

    for (int n = 0; n < m_listBoxSearchResult.GetItemCount(); n++)
    {
        TSDK_S_LDAP_CONTACT * temContact = (TSDK_S_LDAP_CONTACT *)m_listBoxSearchResult.GetItemData(n);
        if (temContact != NULL)
        {
            delete temContact;
        }
    }
}
