//
//  CDemoLoginSettingDlg.cpp
//  EC_SDK_DEMO
//
//  Created by EC Open support team.
//  Copyright(C), 2018, Huawei Tech. Co., Ltd. ALL RIGHTS RESERVED.
//

#include "stdafx.h"
#include "afxdialogex.h"
#include "DemoLoginSettingDlg.h"
#include "DemoCommonTools.h"


// CDemoLoginSettingDlg dialog

IMPLEMENT_DYNAMIC(CDemoLoginSettingDlg, CDialogEx)

CDemoLoginSettingDlg::CDemoLoginSettingDlg(CWnd* pParent /*=NULL*/)
    : CDialogEx(CDemoLoginSettingDlg::IDD, pParent)
    , m_strServerType(_T(""))
{
    m_strServerAddress = _T("");
    m_strServerPort = _T("");
    m_strTransportMode = _T("");
    m_strSipURI = _T("");
}

CDemoLoginSettingDlg::~CDemoLoginSettingDlg()
{
}

void CDemoLoginSettingDlg::DoDataExchange(CDataExchange* pDX)
{
    CDialogEx::DoDataExchange(pDX);
    DDX_Control(pDX, IDC_EDIT_SERVER_ADDRESS, m_editServerAddress);
    DDX_Control(pDX, IDC_EDIT_SERVER_PORT, m_editServerPort);
    DDX_Control(pDX, IDC_COMBO_SERVER_TYPE, m_comServerType);
    DDX_CBString(pDX, IDC_COMBO_SERVER_TYPE, m_strServerType);
    DDX_Control(pDX, IDC_EDIT_SIP_URI, m_editSipURI);
}


BEGIN_MESSAGE_MAP(CDemoLoginSettingDlg, CDialogEx)
    ON_BN_CLICKED(IDOK, &CDemoLoginSettingDlg::OnBnClickedOk)
END_MESSAGE_MAP()


// CDemoLoginSettingDlg message handlers
BOOL CDemoLoginSettingDlg::OnInitDialog()
{
    CDialogEx::OnInitDialog();

    CTools::GetIniConfigParam(_T("ServerConfig"), _T("serverIP"), m_strServerAddress);
    CTools::GetIniConfigParam(_T("NetworkInfo"), _T("transportMode"), m_strTransportMode);
    m_editServerAddress.SetWindowText(m_strServerAddress);
    if ("tls" == m_strTransportMode)
    {
        ((CButton *)GetDlgItem(IDC_RADIO_TLS))->SetCheck(TRUE);
        CTools::GetIniConfigParam(_T("NetworkInfo"), _T("tlsPort"), m_strServerPort);
    }
    else if ("udp" == m_strTransportMode)
    {
        ((CButton *)GetDlgItem(IDC_RADIO_UDP))->SetCheck(TRUE);
        CTools::GetIniConfigParam(_T("NetworkInfo"), _T("udpPort"), m_strServerPort);
    }
    else
    {
        ((CButton *)GetDlgItem(IDC_RADIO_TLS))->SetCheck(TRUE);
        CTools::GetIniConfigParam(_T("NetworkInfo"), _T("tlsPort"), m_strServerPort);
    }
    m_editServerPort.SetWindowText(m_strServerPort);

    m_comServerType.InsertString(0, _T("UPortal"));
    m_comServerType.InsertString(1, _T("SMC"));
    m_comServerType.InsertString(2, _T("UAP"));
    CTools::GetIniConfigParam(_T("ServerConfig"), _T("serverType"), m_strServerType);
    if (m_strServerType.Compare(_T("SMC")) == 0)
    {
        m_comServerType.SetCurSel(1);
    }
    else if (m_strServerType.Compare(_T("UPortal")) == 0)
    {
        m_comServerType.SetCurSel(0);
    }
    else
    {
        m_comServerType.SetCurSel(2);
    }
    CTools::GetIniConfigParam(_T("ServerConfig"), _T("sipURI"), m_strSipURI);
    m_editSipURI.SetWindowText(m_strSipURI);

    UpdateData(FALSE);
    return TRUE;
}

void CDemoLoginSettingDlg::OnBnClickedOk()
{
    // TODO: Add your control notification handler code here
    SaveServer();
    CDialogEx::OnOK();
}

void CDemoLoginSettingDlg::SaveServer()
{
    UpdateData(TRUE);
    m_editServerAddress.GetWindowText(m_strServerAddress);
    m_editServerPort.GetWindowText(m_strServerPort);
    m_editSipURI.GetWindowText(m_strSipURI);

    int iRadioButton = GetCheckedRadioButton(IDC_RADIO_TLS,IDC_RADIO_UDP);
    if (IDC_RADIO_TLS == iRadioButton)
    {
        m_strTransportMode = "tls";
        CTools::WriteIniConfigParam(_T("NetworkInfo"), _T("tlsPort"), m_strServerPort);
    }
    else if (IDC_RADIO_UDP == iRadioButton)
    {
        m_strTransportMode = "udp";
        CTools::WriteIniConfigParam(_T("NetworkInfo"), _T("udpPort"), m_strServerPort);
    }
    else
    {
        m_strTransportMode = "tls";
        CTools::WriteIniConfigParam(_T("NetworkInfo"), _T("tlsPort"), m_strServerPort);
    }


    CTools::WriteIniConfigParam(_T("ServerConfig"), _T("serverIP"), m_strServerAddress);
    CTools::WriteIniConfigParam(_T("NetworkInfo"), _T("transportMode"), m_strTransportMode);
    CTools::WriteIniConfigParam(_T("ServerConfig"), _T("serverType"), m_strServerType);
    CTools::WriteIniConfigParam(_T("ServerConfig"), _T("serverPort"), m_strServerPort);
    CTools::WriteIniConfigParam(_T("ServerConfig"), _T("sipURI"), m_strSipURI);
    UpdateData(FALSE);
}

