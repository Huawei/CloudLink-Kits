//
//  DemoAudioMeetingDlg.cpp
//  EC_SDK_DEMO
//
//  Created by EC Open support team.
//  Copyright(C), 2018, Huawei Tech. Co., Ltd. ALL RIGHTS RESERVED.
//

#include "stdafx.h"
#include "DemoApp.h"
#include "DemoAudioMeetingDlg.h"
#include "DemoMainDlg.h"
#include "afxdialogex.h"
#include "DemoCommonTools.h"
#include "DemoMeetingAddMemDlg.h"
#include "DemoCallDtmfDlg.h"
#include "service_call_interface.h"
#include "service_conf_interface.h"
#include "service_tools.h"
#include "service_os_adapt.h"
#include "service_login_def.h"

#include <string>
#include <vector>
#include "service_login_def.h"
#include "demochatdlg.h"
#include "securec.h"

extern CString g_sipNumber;
extern CString g_shortNumber;
extern LOGIN_ENV_TYPE g_login_env_type;
extern bool g_shareState;
#define  DLG_CONF_WIDE            570
#define  DLG_CONF_AUDIO_HEI        320
#define  DLG_CONF_VIDEO_HEI        480


// CDemoAudioMeetingDlg dialog
IMPLEMENT_DYNAMIC(CDemoAudioMeetingDlg, CDialogEx)

CDemoAudioMeetingDlg::CDemoAudioMeetingDlg(CWnd* pParent /*=NULL*/)
    : CDialogEx(CDemoAudioMeetingDlg::IDD, pParent)
    , ischairman(false)
    , ispresenter(false)
    , m_confID(0)
    , m_callID(0)
    , m_handle(0)
    , m_confType(AUDIO_CONF)
    , m_postponeTime(0)
    , isNeedPrompting(true)
    , isMsgShow(false)
    , m_pNetWorkInfoDlg(NULL)
    , is_in_roll_calling(false)
    , rollCalledNumber("")
    , m_edit_send_data_msgid(0)
{

}

CDemoAudioMeetingDlg::~CDemoAudioMeetingDlg()
{
    SAFE_DELETE(m_pNetWorkInfoDlg);
    m_pNetWorkInfoDlg = NULL;
}

void CDemoAudioMeetingDlg::DoDataExchange(CDataExchange* pDX)
{
    CDialogEx::DoDataExchange(pDX);
    DDX_Control(pDX, IDC_MEMBER_LIST, m_listMember);
    DDX_Control(pDX, IDC_BT_MUTE, m_bt_Mute);
    DDX_Control(pDX, IDC_BT_LOCK, m_bt_Lock);
    DDX_Control(pDX, IDC_BT_DATACONF, m_bt_DataConf);
    DDX_Control(pDX, IDC_BT_HAND_UP, m_bt_Handup);
    DDX_Control(pDX, IDC_BT_APPLY_FOR_CHAIRMAN, m_bt_Apply);
    DDX_Control(pDX, IDC_BT_RELEASE_CHAIRMAN, m_bt_Release);
    DDX_Control(pDX, IDC_BT_ADD_MEMBER, m_bt_Add);
    DDX_Control(pDX, IDC_BT_CONF_DTMF, m_bt_Dtmf);
    DDX_Control(pDX, IDC_BT_END_CONF,m_bt_End_Conf);
    DDX_Control(pDX, IDC_BT_LEAVE_CONF, m_bt_Leave_Conf);
    DDX_Control(pDX, IDC_STATIC_SUBJECT, m_static_subject);
    DDX_Control(pDX, IDC_COM_CONF_MODE, m_cbxVideoConfMode);
    DDX_Control(pDX, IDC_EDIT_CHAIRMAN_PWD,m_edit_chairman_pwd);
    DDX_Text(pDX, IDC_EDIT_POSTPONE_TIME, m_postponeTime);
    DDX_Control(pDX, IDC_BT_POSTPONE_CONF, m_btn_postpone);
    DDX_Control(pDX, IDC_BUTTON_PUBLICCHAT, m_btn_publicMsg);
    DDX_Control(pDX, IDC_BT_APPLY_SPEAK, m_btn_apply_speak);
    DDX_Control(pDX, IDC_BT_CANCEL_ROLLCALL, m_btn_cancel_rollcall);
    DDX_Text(pDX, IDC_EDIT_SEND_DATA_MSGID, m_edit_send_data_msgid);
    DDX_Control(pDX, IDC_BUTTON_PUBLICDATA, m_btn_publicData);
    DDX_Control(pDX, IDC_EDIT_SUBJECT, m_edit_subject);
    DDX_Control(pDX, IDC_BUTTON_SET_WIREDPROJECTION, m_btn_wiredProjection);
    DDX_Control(pDX, IDC_BUTTON_SET_WIRELESSPROJECTION, m_btn_wirelessProjection);
}


BEGIN_MESSAGE_MAP(CDemoAudioMeetingDlg, CDialogEx)
    ON_BN_CLICKED(IDC_BT_ADD_MEMBER, &CDemoAudioMeetingDlg::OnBnClickedBtAddMember)
    ON_BN_CLICKED(IDC_BT_MUTE, &CDemoAudioMeetingDlg::OnBnClickedBtMute)
    ON_BN_CLICKED(IDC_BT_LOCK, &CDemoAudioMeetingDlg::OnBnClickedBtLock)
    ON_BN_CLICKED(IDC_BT_APPLY_FOR_CHAIRMAN, &CDemoAudioMeetingDlg::OnBnClickedBtApplyChairman)
    ON_BN_CLICKED(IDC_BT_RELEASE_CHAIRMAN, &CDemoAudioMeetingDlg::OnBnClickedBtReleaseChairman)
    ON_BN_CLICKED(IDC_BT_HAND_UP, &CDemoAudioMeetingDlg::OnBnClickedBtHandUp)
    ON_BN_CLICKED(IDC_BT_DATACONF, &CDemoAudioMeetingDlg::OnBnClickedBtDataconf)
    ON_BN_CLICKED(IDC_BT_CONF_DTMF, &CDemoAudioMeetingDlg::OnBnClickedBtDtmf)
    ON_BN_CLICKED(IDC_BT_END_CONF, &CDemoAudioMeetingDlg::OnBnClickedBtEndConf)
    ON_BN_CLICKED(IDC_BT_LEAVE_CONF, &CDemoAudioMeetingDlg::OnBnClickedBtLeaveConf)
    ON_CBN_SELCHANGE(IDC_COM_CONF_MODE, &CDemoAudioMeetingDlg::OnCbnSelchangeComboSetConfMode)
    ON_NOTIFY(NM_RCLICK, IDC_MEMBER_LIST, &CDemoAudioMeetingDlg::OnNMRClickMemberList)
    ON_COMMAND_RANGE(ID_CONF_DEL_MEM_MENU, ID_DCONF_SEND_USER_DATA, &CDemoAudioMeetingDlg::OnClickListMemMenuItem)
    ON_COMMAND_RANGE(ID_CONF_DEL_MEM_MENU, ID_DCONF_CANCEL_REMOTE_CONTROL_MENU, &CDemoAudioMeetingDlg::OnClickListMemMenuItem)
    ON_MESSAGE(WM_CONF_CTRL_INFO_AND_STATUS_UPDATE, &CDemoAudioMeetingDlg::OnConfInfoAndStatusUpdate)
    ON_MESSAGE(WM_CONF_CTRL_ADDRESSER_UPDATE_IND, &CDemoAudioMeetingDlg::OnConfSpeakerUpdate)
    ON_MESSAGE(WM_CONF_CTRL_OPERATION_RESULT,&CDemoAudioMeetingDlg::OnConfOperationResult)
    ON_MESSAGE(WM_CONF_CTRL_UI_PLUGIN_CLICK_LEAVE_CONF, &CDemoAudioMeetingDlg::OnConfUiPluginClickLeaveConf)
    ON_MESSAGE(WM_CONF_CTRL_UI_PLUGIN_CLICK_END_CONF, &CDemoAudioMeetingDlg::OnConfUiPluginClickEndConf)
    ON_MESSAGE(WM_CONF_CTRL_UI_PLUGIN_CLICK_START_SHARE, &CDemoAudioMeetingDlg::OnConfUiPluginClickStartShare)
    ON_MESSAGE(WM_CONF_CTRL_UI_PLUGIN_EVT_SET_WINDOW_SIZE, &CDemoAudioMeetingDlg::OnConfUiPluginSetWindowSize)


    ON_WM_CLOSE()
    ON_BN_CLICKED(IDC_BT_POSTPONE_CONF, &CDemoAudioMeetingDlg::OnBnClickedBtPostponeConf)
    ON_BN_CLICKED(IDC_BT_APPLY_PRESENTER, &CDemoAudioMeetingDlg::OnBnClickedBtApplyPresenter)
    ON_MESSAGE(WM_DATACONF_MODULE_RECEIVED_CHATMSG,&CDemoAudioMeetingDlg::OnReceivedChatMsg)
    ON_MESSAGE(WM_DATACONF_MODULE_RECEIVED_USER_DATAMSG,&CDemoAudioMeetingDlg::OnReceivedUserDataMsg)
    
    ON_BN_CLICKED(IDC_BUTTON_PUBLICCHAT, &CDemoAudioMeetingDlg::OnBnClickedButtonPublicchat)
    ON_BN_CLICKED(IDC_BT_APPLY_SPEAK, &CDemoAudioMeetingDlg::OnBnClickedBtApplySpeak)
    ON_BN_CLICKED(IDC_BUTTON_NET, &CDemoAudioMeetingDlg::OnBnClickedButtonNet)
    ON_BN_CLICKED(IDC_BT_CANCEL_ROLLCALL, &CDemoAudioMeetingDlg::OnBnClickedBtCancelRollcall)
    ON_BN_CLICKED(IDC_BUTTON_PUBLICDATA, &CDemoAudioMeetingDlg::OnBnClickedButtonPublicdata)
    ON_BN_CLICKED(IDC_BUTTON_SET_SUBJECT, &CDemoAudioMeetingDlg::OnBnClickedButtonSetSubject)
    ON_BN_CLICKED(IDC_BUTTON_SET_WIREDPROJECTION, &CDemoAudioMeetingDlg::OnBnClickedButtonSetWiredprojection)
    ON_BN_CLICKED(IDC_BUTTON_SET_WIRELESSPROJECTION, &CDemoAudioMeetingDlg::OnBnClickedButtonSetWirelessprojection)
END_MESSAGE_MAP()


// CDemoAudioMeetingDlg handle function
BOOL CDemoAudioMeetingDlg::OnInitDialog()
{
    CDialogEx::OnInitDialog();

    CString strCaption;
    if (0 == g_sipNumber.GetLength())
    {
        strCaption.Format(_T("Conference Manage"));
    }
    else
    {
        strCaption.Format(_T("Conference Manage(%s)"), g_sipNumber);
    }

    this->SetWindowText(strCaption);

    //��ʼ��combox�ؼ�
    m_cbxVideoConfMode.InsertString(0, _T("Broadcast"));
    m_cbxVideoConfMode.InsertString(1, _T("Vas"));
    m_cbxVideoConfMode.InsertString(2, _T("Free"));

    //��ʼ��������б�
    m_listMember.ModifyStyle(0, LVS_SINGLESEL);
    m_listMember.InsertColumn(COL_MEM_COMPERE, _T("Chirman"), LVCFMT_JUSTIFYMASK, 78);
    m_listMember.InsertColumn(COL_MEM_PRESENT, _T("Present"), LVCFMT_JUSTIFYMASK, 78);
    m_listMember.InsertColumn(COL_MEM_NAME, _T("Name"), LVCFMT_JUSTIFYMASK, 78);
    m_listMember.InsertColumn(COL_MEM_ACCOUNT, _T("Account"), LVCFMT_JUSTIFYMASK, 78);
    m_listMember.InsertColumn(COL_MEM_CALLNO, _T("Number"), LVCFMT_JUSTIFYMASK, 78);
    m_listMember.InsertColumn(COL_MEM_CALLSTATE, _T("CallStatus"), LVCFMT_JUSTIFYMASK, 78);
    m_listMember.InsertColumn(COL_MEM_SPK, _T("Speaker"), LVCFMT_JUSTIFYMASK, 78);
    m_listMember.InsertColumn(COL_MEM_MUTE, _T("Mute"), LVCFMT_JUSTIFYMASK, 78);
    m_listMember.InsertColumn(COL_MEM_HANDUP, _T("HandUp"), LVCFMT_JUSTIFYMASK, 78);
    m_listMember.InsertColumn(COL_MEM_BROADCAST, _T("Broadcast"), LVCFMT_JUSTIFYMASK, 78);
    m_listMember.InsertColumn(COL_MEM_APPLY_SPK, _T("ApplySpeak"), LVCFMT_JUSTIFYMASK, 78);
    DWORD dwStyle = m_listMember.GetExtendedStyle();
    dwStyle |= LVS_EX_FULLROWSELECT;    //ѡ��ĳ��ʹ���и�����ֻ������report����listctrl��
    dwStyle |= LVS_EX_GRIDLINES;        //�����ߣ�ֻ������report����listctrl��
    m_listMember.SetExtendedStyle(dwStyle); //������չ���
    return TRUE;  // return TRUE unless you set the focus to a control
}

void CDemoAudioMeetingDlg::OnBnClickedBtAddMember()
{
    CDemoMeetingAddMemDlg dlg;
    INT_PTR nResponse = dlg.DoModal();

    //new attendee insert to list
    if (IDOK != nResponse)
    {
        return;
    }

    //use the service interface of add member
    TSDK_S_ADD_ATTENDEES_INFO addAttendeeInfo = { 0 };
    addAttendeeInfo.attendee_num = 1;
    TSDK_UINT32 count = addAttendeeInfo.attendee_num;
    addAttendeeInfo.attendee_list = (TSDK_S_ATTENDEE_BASE_INFO*)malloc(count*sizeof(TSDK_S_ATTENDEE_BASE_INFO));
    if (NULL == addAttendeeInfo.attendee_list)
    {
        AfxMessageBox(_T("addAttendeeInfo.attendee_list is NULL"));
        return;
    }
    (void)service_memset_s(addAttendeeInfo.attendee_list, count*sizeof(TSDK_S_ATTENDEE_BASE_INFO), 0, count*sizeof(TSDK_S_ATTENDEE_BASE_INFO));
    TSDK_S_ATTENDEE_BASE_INFO* pTempAttendee = addAttendeeInfo.attendee_list;
    for (unsigned int i = 0; i < count; i++)
    {
        if (pTempAttendee)
        {
            (void)strncpy_s(pTempAttendee->number, TSDK_D_MAX_PARTICIPANTID_LEN + 1, CTools::UNICODE2UTF(dlg.addMemSipNum).c_str(), TSDK_D_MAX_PARTICIPANTID_LEN - 1);
            (void)strncpy_s(pTempAttendee->display_name, TSDK_D_MAX_ATTENDEE_DISPLAY_NAME_LEN + 1, CTools::UNICODE2UTF(dlg.addMemSipNumDisplayname).c_str(), TSDK_D_MAX_ATTENDEE_DISPLAY_NAME_LEN);
            pTempAttendee->role = TSDK_E_CONF_ROLE_ATTENDEE;
        }
        else
        {
            break;
        }

        pTempAttendee++;
    }
    (void)service_conf_add_attendee(m_handle, &addAttendeeInfo);
    free(addAttendeeInfo.attendee_list);
    addAttendeeInfo.attendee_list = NULL;
}

void CDemoAudioMeetingDlg::OnBnClickedBtMute()
{
    CString cstrtxt;
    m_bt_Mute.GetWindowText(cstrtxt);
    if (_T("Mute Conf") == cstrtxt)
    {
        //// mute conf
        service_conf_mute(m_handle, 1);
    }
    else
    {
        /////unmute conf
        service_conf_mute(m_handle, 0);
    }
}

void CDemoAudioMeetingDlg::OnBnClickedBtLock()
{
    CString cstrtxt;
    m_bt_Lock.GetWindowText(cstrtxt);
    if (_T("Lock Conf") == cstrtxt)
    {
        ////Lock conf
        service_conf_lock(m_handle, 1);
    }
    else
    {
        ////Unlock conf
        service_conf_lock(m_handle, 0);
    }
}

void CDemoAudioMeetingDlg::OnBnClickedBtHandUp()
{
    /*CString attendeeNum = CTools::GetSipNumber(g_sipNumber);*/
    std::string strAttendeeNum = CTools::UNICODE2UTF(g_sipNumber);

    CString cstrtxt;
    m_bt_Handup.GetWindowText(cstrtxt);
    if (_T("Hand Up") == cstrtxt)
    {
        (void)service_conf_handup(m_handle, TRUE, const_cast<char*>(strAttendeeNum.c_str()));
    }
    else
    {
        (void)service_conf_handup(m_handle, FALSE, const_cast<char*>(strAttendeeNum.c_str()));
    }
}

void CDemoAudioMeetingDlg::OnBnClickedBtDataconf()
{
    (void)service_conf_upgrade_conf(m_handle);
}

void CDemoAudioMeetingDlg::OnBnClickedBtApplyChairman()
{
    CString cstrPwd;
    m_edit_chairman_pwd.GetWindowText(cstrPwd);
    (void)service_conf_request_chairman(m_handle, const_cast<char*>(CTools::UNICODE2UTF(cstrPwd).c_str()));
}

void CDemoAudioMeetingDlg::OnBnClickedBtReleaseChairman()
{
    (void)service_conf_release_chairman(m_handle);
}

void CDemoAudioMeetingDlg::OnBnClickedBtDtmf()
{
    CDemoApp* app = (CDemoApp*)AfxGetApp();
    if (!app)
    {
        //�����Ѿ��ر�
        return;
    }
    CDemoMainDlg* maindlg = (CDemoMainDlg*)(app->m_pMainDlgWnd);
    CHECK_POINTER(maindlg);
    ::PostMessage(maindlg->GetSafeHwnd(), WM_CALL_DTMF, NULL, NULL);
}

void CDemoAudioMeetingDlg::OnBnClickedBtEndConf()
{
    (void)service_conf_end(m_handle);

    if(LOGIN_ENV_EC == g_login_env_type) 
    {
        /*End Call*/
        if (m_callID != 0)
        {
            service_call_end(m_callID);
            m_callID = 0;
        }
    }
    m_handle = 0;
   

    /////close confDlg/////
    ::PostMessage(theApp.m_pMainDlgWnd->GetSafeHwnd(), WM_CALL_CONF_CLOSE_DLG, NULL, NULL);
    CDialogEx::OnClose();
}

void CDemoAudioMeetingDlg::OnBnClickedBtLeaveConf()    
{
    /*End Call*/
    if(g_shareState)
    {
        (void)service_data_conf_app_share_stop();
        g_shareState = false;
    }

    if (LOGIN_ENV_VC == g_login_env_type) 
    {
        if (m_handle != 0)
        {
            (void)service_conf_leave(m_handle);
            m_handle = 0;
        }
    }
    else
    {
        if (m_callID != 0)
        {
            service_call_end(m_callID);
            m_callID = 0;
        }

        if (m_handle != 0)
        {
            (void)service_conf_leave(m_handle);
            m_handle = 0;
        }
    }

    /////close confDlg/////
    ::PostMessage(theApp.m_pMainDlgWnd->GetSafeHwnd(), WM_CALL_CONF_CLOSE_DLG, NULL, NULL);
    CDialogEx::OnClose();
}

void CDemoAudioMeetingDlg::OnCbnSelchangeComboSetConfMode()
{
    CString strVideoModeType;
    m_cbxVideoConfMode.GetLBText(m_cbxVideoConfMode.GetCurSel(),strVideoModeType);
    m_cbxVideoConfMode.SetWindowText(strVideoModeType);

    if (_T("Broadcast") == strVideoModeType)
    {
        (void)service_conf_set_video_mode(m_handle, TSDK_E_CONF_VIDEO_BROADCAST);
    }
    else if (_T("Vas") == strVideoModeType)
    {
        (void)service_conf_set_video_mode(m_handle, TSDK_E_CONF_VIDEO_VAS);
    }
    else if (_T("Free") == strVideoModeType)
    {
        (void)service_conf_set_video_mode(m_handle, TSDK_E_CONF_VIDEO_FREE);
    }
    else
    {
        return;
    }
}

void CDemoAudioMeetingDlg::OnNMRClickMemberList(NMHDR *pNMHDR, LRESULT *pResult)
{
    if ((NULL == pNMHDR) || (NULL == pResult))
    {
        return;
    }

    /*lint -e826 */
    LPNMITEMACTIVATE pNMItemActivate = reinterpret_cast<LPNMITEMACTIVATE>(pNMHDR);
    /*lint +e826 */

    *pResult = 0;

    CPoint pt, pmenu;
    ::GetCursorPos(&pt);
    ::GetCursorPos(&pmenu);
    m_listMember.ScreenToClient(&pt);
    UINT uFlag = 0;
    int hSelectedItem = m_listMember.HitTest(pt, &uFlag);
    if (0 <= hSelectedItem)
    {
        CMenu menu;
        menu.CreatePopupMenu();

        CString cstrIsChairman = m_listMember.GetItemText(hSelectedItem, COL_MEM_COMPERE);
        CString cstrIsPresenter = m_listMember.GetItemText(hSelectedItem, COL_MEM_PRESENT);
        CString cstrCallState = m_listMember.GetItemText(hSelectedItem, COL_MEM_CALLSTATE);
        CString cstrMute = m_listMember.GetItemText(hSelectedItem, COL_MEM_MUTE);
        CString cstrHandup = m_listMember.GetItemText(hSelectedItem, COL_MEM_HANDUP);
        CString cstrBroadcast = m_listMember.GetItemText(hSelectedItem, COL_MEM_BROADCAST);
        CString cstrSipNum = m_listMember.GetItemText(hSelectedItem, COL_MEM_CALLNO);
        //�˵�ѡ��ȫ���г���δ������ϯ������ߣ��������Ż�
        //���������
        if(ischairman)
        {
            if (cstrMute != _T("Mute"))
            {
                menu.AppendMenu(MF_STRING, ID_CONF_MUTE_MEM_MENU, _T("Mute"));
            }
            else
            {
                menu.AppendMenu(MF_STRING, ID_CONF_UNMUTE_MEM_MENU, _T("UnMute"));
            }
        }
        else
        {
            if(0 == cstrSipNum.CompareNoCase(g_sipNumber))
            {
                if (cstrMute != _T("Mute"))
                {
                    menu.AppendMenu(MF_STRING, ID_CONF_MUTE_MEM_MENU, _T("Mute"));
                }
                else
                {
                    menu.AppendMenu(MF_STRING, ID_CONF_UNMUTE_MEM_MENU, _T("UnMute"));
                }
            }
        }

        //����
        if (cstrHandup == _T("HandUp"))
        {
            menu.AppendMenu(MF_STRING, ID_CONF_UNHANDUP_MEM_MENU, _T("unHandUp"));
        }

        if (ischairman)
        {
            if (cstrCallState == _T("InConf"))
            {
                //�Ҷ������
                menu.AppendMenu(MF_STRING, ID_CONF_HANGUP_MEM_MENU, _T("HangUp"));
            }
            else
            {
                //�غ�
                menu.AppendMenu(MF_STRING, ID_CONF_RECALL_MEM_MENU, _T("ReCall"));
            }

            if(0 != cstrSipNum.CompareNoCase(g_sipNumber))
            {
                //ɾ�������
                menu.AppendMenu(MF_STRING, ID_CONF_DEL_MEM_MENU, _T("Delete Attendee"));
            }
        }

        //ѡ��
        menu.AppendMenu(MF_STRING, ID_DCONF_WATCH_MENU, _T("Watch"));

        //�㲥
        if (ischairman)
        {
            if (cstrBroadcast == _T("Broadcast"))
            {
                menu.AppendMenu(MF_STRING, ID_CONF_UNBROADCAST_MEM_MENU, _T("unBroadcast"));
            }
            else
            {
                menu.AppendMenu(MF_STRING, ID_CONF_BROADCAST_MEM_MENU, _T("Broadcast"));  
            }
        }

        //���빲��,����ϯ�����빲��
        if((0 != cstrSipNum.CompareNoCase(g_sipNumber)) && (ispresenter))
        {
            menu.AppendMenu(MF_STRING, ID_DCONF_SHARE_DESKTOP_MEM_MENU, _T("invite share"));
        }

        //����Ϊ������

        if(AUDIO_DATA_CONF == m_confType || VIDEO_DATA_CONF == m_confType)
        {
            if(ischairman)
            {
                menu.AppendMenu(MF_STRING, ID_DCONF_SETPRESENT_MEM_MENU, _T("To be Present"));
            }
        }


        if (AUDIO_DATA_CONF == m_confType || VIDEO_DATA_CONF == m_confType)
        {
            menu.AppendMenu(MF_STRING, ID_DCONF_SEND_CHAT_MESSAGE, _T("Send Chat Message"));
            menu.AppendMenu(MF_STRING, ID_DCONF_SEND_USER_DATA, _T("Send User Defined Data"));
        }

        //��ϯ��������
        if(ischairman)
        {
            if (cstrIsChairman != _T("Yes"))
            {
                menu.AppendMenu(MF_STRING, ID_DCONF_ROLL_CALL_MENU, _T("Roll Call"));
            }
        }
        
        menu.AppendMenu(MF_STRING, ID_DCONF_REQ_REMOTE_CONTROL_MENU, _T("Request Control"));

        menu.AppendMenu(MF_STRING, ID_DCONF_CANCEL_REMOTE_CONTROL_MENU, _T("Cancel Control"));

        menu.TrackPopupMenu(0, pmenu.x, pmenu.y, this);
    }
}


void CDemoAudioMeetingDlg::OnClickListMemMenuItem(UINT nID)
{
    int nItem = -1;
    POSITION pos = m_listMember.GetFirstSelectedItemPosition();
    if (pos == NULL)
    {
        TRACE0("No items were selected!\n");
        return;
    }
    else
    {
        while (pos)
        {
            nItem = m_listMember.GetNextSelectedItem(pos);
            TRACE1("Item %d was selected!\n", nItem);
            break;
        }
    }
    CString cstrAccount = m_listMember.GetItemText(nItem, COL_MEM_ACCOUNT);
    CString cstrBindNo = m_listMember.GetItemText(nItem, COL_MEM_CALLNO);
    std::string strCallNo = CTools::UNICODE2UTF(cstrBindNo);
    switch (nID)
    {
    case ID_CONF_DEL_MEM_MENU:
    {
        (void)service_conf_delete_attendee(m_handle, strCallNo.c_str());
        break;
    }
    case ID_CONF_RECALL_MEM_MENU:
    {
        if(g_login_env_type == LOGIN_ENV_VC)
        {
            (void)service_conf_redial_attendee(m_handle, strCallNo.c_str());
            break;
        }

        //use the service interface of add member
        TSDK_S_ADD_ATTENDEES_INFO addAttendeeInfo = { 0 };
        addAttendeeInfo.attendee_num = 1;
        TSDK_UINT32 count = addAttendeeInfo.attendee_num;
        addAttendeeInfo.attendee_list = (TSDK_S_ATTENDEE_BASE_INFO*)malloc(count*sizeof(TSDK_S_ATTENDEE_BASE_INFO));
        if (NULL == addAttendeeInfo.attendee_list)
        {
            AfxMessageBox(_T("addAttendeeInfo.attendee_list is NULL"));
            return;
        }
        (void)service_memset_s(addAttendeeInfo.attendee_list, count*sizeof(TSDK_S_ATTENDEE_BASE_INFO), 0, count*sizeof(TSDK_S_ATTENDEE_BASE_INFO));
        TSDK_S_ATTENDEE_BASE_INFO* pTempAttendee = addAttendeeInfo.attendee_list;
        for (unsigned int i = 0; i < count; i++)
        {
            if (pTempAttendee)
            {
                (void)strncpy_s(pTempAttendee->number, TSDK_D_MAX_PARTICIPANTID_LEN + 1, strCallNo.c_str(), TSDK_D_MAX_PARTICIPANTID_LEN - 1);
                pTempAttendee->role = TSDK_E_CONF_ROLE_ATTENDEE;
            }
            else
            {
                break;
            }

            pTempAttendee++;
        }
        (void)service_conf_add_attendee(m_handle, &addAttendeeInfo);
        free(addAttendeeInfo.attendee_list);
        addAttendeeInfo.attendee_list = NULL;
        break;
    }
    case ID_CONF_MUTE_MEM_MENU:
    {
        (void)service_conf_mute_attendee(m_handle, strCallNo.c_str(), TRUE);
        break;
    }
    case ID_CONF_UNMUTE_MEM_MENU:
    {
        (void)service_conf_mute_attendee(m_handle, strCallNo.c_str(), FALSE);
        break;
    }
    case ID_CONF_HANGUP_MEM_MENU:
    {
        (void)service_conf_hangup_attendee(m_handle, strCallNo.c_str());
        break;
    }
    case ID_CONF_UNHANDUP_MEM_MENU:
    {
        if (TSDK_SUCCESS != service_conf_handup(m_handle, FALSE, const_cast<char*>(strCallNo.c_str())))
        {
            AfxMessageBox(_T("Handup failed!"));
        }
        break;
    }
    case ID_DCONF_WATCH_MENU:
    {
        TSDK_S_WATCH_ATTENDEES_INFO watchAttendeesInfo = { 0 };
        watchAttendeesInfo.watch_attendee_num = 1;
        watchAttendeesInfo.watch_attendee_list = (TSDK_S_WATCH_ATTENDEES*)malloc(watchAttendeesInfo.watch_attendee_num * sizeof(TSDK_S_WATCH_ATTENDEES));
        if (NULL == watchAttendeesInfo.watch_attendee_list)
        {
            return;
        }
        (void)service_memset_s(watchAttendeesInfo.watch_attendee_list, watchAttendeesInfo.watch_attendee_num * sizeof(TSDK_S_WATCH_ATTENDEES), 0, watchAttendeesInfo.watch_attendee_num * sizeof(TSDK_S_WATCH_ATTENDEES));
        strncpy_s(watchAttendeesInfo.watch_attendee_list->number, TSDK_D_MAX_NUMBER_LEN + 1, strCallNo.c_str(), _TRUNCATE);
        (void)service_conf_watch_attendee(m_handle, &watchAttendeesInfo);
        break;
    }
    case ID_CONF_BROADCAST_MEM_MENU:
    {
        (void)service_conf_broadcast_attendee(m_handle, const_cast<char*>(strCallNo.c_str()), TRUE);
        break;
    }
    case ID_CONF_UNBROADCAST_MEM_MENU:
    {
        std::string attendNum = "";

        if(g_login_env_type == LOGIN_ENV_VC)
        {
            attendNum = strCallNo;
        }
        (void)service_conf_broadcast_attendee(m_handle, const_cast<char*>(attendNum.c_str()), FALSE);
        break;
    }
    case ID_DCONF_SETPRESENT_MEM_MENU:
    {
        if (TSDK_SUCCESS != service_data_conf_set_presenter(m_handle, const_cast<char*>(strCallNo.c_str()))) 
        {
            AfxMessageBox(_T("set presenter failed"));
        }
        break;
    }
    case ID_DCONF_SHARE_DESKTOP_MEM_MENU:
    {
        (void)service_data_conf_app_share_set_owner(const_cast<char*>(strCallNo.c_str()), TSDK_E_CONF_AS_ACTION_ADD);
        break;
    }
    case ID_DCONF_STOP_SHARE_DESKTOP_MEM_MENU:
    {
        (void)service_data_conf_app_share_set_owner(const_cast<char*>(strCallNo.c_str()), TSDK_E_CONF_AS_ACTION_DELETE);
        break;
    }
    case ID_DCONF_APPLY_AS_PRESENT_MENU:
    {
        (void)service_data_conf_apply_presenter(m_handle);
        break;
    }
    case ID_DCONF_SEND_CHAT_MESSAGE:
    {
        SendChatMessage(TSDK_E_CONF_CHAT_PRIVATE, cstrBindNo);
        break;
    }
    case ID_DCONF_ROLL_CALL_MENU:
    {
        TSDK_RESULT result = service_roll_call(m_handle, const_cast<char*>(strCallNo.c_str()));
        if(TSDK_SUCCESS != result)
        {
            is_in_roll_calling = FALSE;
            m_btn_cancel_rollcall.EnableWindow(FALSE);
            rollCalledNumber = "";
        }
        else
        {
            rollCalledNumber = strCallNo;
        }
        break;
    }
    case ID_DCONF_SEND_USER_DATA:
    {
        UpdateData(true);
        SendData(TSDK_S_CONF_CUSTOM_PRIVATE_DATA, cstrBindNo, m_edit_send_data_msgid);
        break;
    }
    case ID_DCONF_REQ_REMOTE_CONTROL_MENU:
    {
        (void)service_data_conf_app_share_set_privilege(const_cast<char*>(strCallNo.c_str()), TSDK_E_CONF_SHARE_PRIVILEGE_CONTROL, TSDK_E_CONF_AS_ACTION_ADD);
        break;
    }

    case ID_DCONF_CANCEL_REMOTE_CONTROL_MENU:
    {
        (void)service_data_conf_app_share_set_privilege(const_cast<char*>(strCallNo.c_str()), TSDK_E_CONF_SHARE_PRIVILEGE_CONTROL, TSDK_E_CONF_AS_ACTION_DELETE);
        break;
    }
    default:
        break;
    }
}

LRESULT CDemoAudioMeetingDlg::OnConfInfoAndStatusUpdate(WPARAM wparam, LPARAM lparam)
{
    CHECK_POINTER_RETURN(wparam, 0L);
    TSDK_S_CONF_STATUS_INFO* notifyInfo = (TSDK_S_CONF_STATUS_INFO*)wparam;
    TSDK_S_ATTENDEE* participants = notifyInfo->attendee_list;

    /* conferecne lock status*/
    if (notifyInfo->is_lock)
    {
        m_bt_Lock.SetWindowText(_T("UnLock Conf"));
    }
    else
    {
        m_bt_Lock.SetWindowText(_T("Lock Conf"));
    }

    /* Conferecne lock status */
    if (notifyInfo->is_all_mute)
    {
        m_bt_Mute.SetWindowText(_T("UnMute Conf"));
    }
    else
    {
        m_bt_Mute.SetWindowText(_T("Mute Conf"));
    }

    /*Conferecne subject*/
    if (strlen(notifyInfo->subject))
    {
        m_static_subject.SetWindowText(CTools::UTF2UNICODE(notifyInfo->subject));
    }

    m_listMember.DeleteAllItems();
    ischairmanexist = false;

    /* Update participant */
    for (unsigned int i = 0; i < notifyInfo->attendee_num; i++)
    {
        if (participants)
        {
            CString cstrNum = CTools::UTF2UNICODE(participants->base_info.account_id);
            CString cstrStatus = CTools::UTF2UNICODE(GetUserStatus(participants->status_info.state));
            int j = -1;
            if (!FindColum(cstrNum, COL_MEM_ACCOUNT, j))//��account��ΪΨһ��ʶ��number�п���Ϊ��
            {
                int iSize = m_listMember.GetItemCount();
                m_listMember.InsertItem(iSize, _T(""));
                j = iSize;
            }

            /*User role*/
            if (TSDK_E_CONF_ROLE_CHAIRMAN == participants->base_info.role)
            {
                ischairmanexist = true;
                m_listMember.SetItemText(j, COL_MEM_COMPERE, _T("Yes"));
            }
            else
            {
                m_listMember.SetItemText(j, COL_MEM_COMPERE, _T(""));
            }

            m_listMember.SetItemText(j, COL_MEM_NAME, CTools::UTF2UNICODE(participants->base_info.display_name));
            m_listMember.SetItemText(j, COL_MEM_ACCOUNT, CTools::UTF2UNICODE(participants->base_info.account_id));
            m_listMember.SetItemText(j, COL_MEM_CALLNO, CTools::UTF2UNICODE(participants->base_info.number));
            m_listMember.SetItemText(j, COL_MEM_CALLSTATE, cstrStatus);

            //�����������뿪��������ϯ�ĵ���̬���
            if(cstrStatus == _T("Leave")
                && is_in_roll_calling
                && strcmp(rollCalledNumber.c_str(),participants->base_info.number) == 0)
            {
                is_in_roll_calling = false;
                m_btn_cancel_rollcall.EnableWindow(FALSE);
                rollCalledNumber = "";
            }

            /*mic mute*/
            if (participants->status_info.is_mute)
            {
                m_listMember.SetItemText(j, COL_MEM_MUTE, _T("Mute"));
            }
            else
            {
                m_listMember.SetItemText(j, COL_MEM_MUTE, _T("UnMute"));
            }

            /*broadcast*/
            if (participants->status_info.is_broadcast)
            {
                m_listMember.SetItemText(j, COL_MEM_BROADCAST, _T("Broadcast"));
            }
            else
            {
                m_listMember.SetItemText(j, COL_MEM_BROADCAST, _T("UnBroadcast"));
            }

            /*present*/
            if (participants->status_info.is_present)
            {
                m_listMember.SetItemText(j, COL_MEM_PRESENT, _T("Yes"));
            }
            else
            {
                m_listMember.SetItemText(j, COL_MEM_PRESENT, _T(""));
            }

            if (participants->status_info.is_self)
            {
                g_sipNumber = participants->base_info.number;

                if (TSDK_E_CONF_ROLE_CHAIRMAN == participants->base_info.role)
                {
                    ischairman = true;
                }
                else
                {
                    ischairman = false;
                }

                ispresenter = participants->status_info.is_present?true:false;
            }

            /*hand up*/
            if (participants->status_info.is_handup) //mcu�°汾���ֻ��������������;���ind�¼�
            {
                m_listMember.SetItemText(j, COL_MEM_HANDUP, _T("HandUp"));
            }
            else
            {
                m_listMember.SetItemText(j, COL_MEM_HANDUP, _T(""));
                //�յ�ȡ������֪ͨ�¼�����ȡ�������Լ��ľ���ʱ��ȡ�����ְ�ť�ָ�Ϊ���ְ�ť
                if (participants->status_info.is_self && false==participants->status_info.is_handup)
                {
                    m_bt_Handup.SetWindowText(_T("Hand Up"));
                }
            }

            //���뷢��
            if (participants->status_info.is_req_talk)
            {
                m_listMember.SetItemText(j, COL_MEM_APPLY_SPK, _T("Yes"));
            }
            else
            {
                m_listMember.SetItemText(j, COL_MEM_APPLY_SPK, _T(""));
            }
            //���뷢�Ե��û��뿪����������뷢��״̬
            if(cstrStatus == _T("Leave"))
            {
                CString cstrApplySpeak = m_listMember.GetItemText(j, COL_MEM_APPLY_SPK);
                if (cstrApplySpeak == _T("Yes"))
                {
                    m_listMember.SetItemText(j, COL_MEM_APPLY_SPK, _T(""));
                }
            }
        }
        else
        {
            break;
        }
        participants++;
    }

    //��������ϯ��ɫ����ȡ�����ְ�ť��Ϊ���ְ�ť
    if (false == ischairmanexist)
    {
        m_bt_Handup.SetWindowText(_T("Hand Up"));
    }

    UpdateAudioConfButtonStatus();

    if((notifyInfo->remain_time > 0 && notifyInfo->remain_time <= 10) 
        && isNeedPrompting
        && ischairman
        && !isMsgShow)
    {
        isMsgShow = true;
        if(MessageBox(_T("The remaining time of the meeting is less than 10 minutes,if you want to continue the meeting, please extend the meeting time! Click \"OK\" button , will not be prompted."),
            _T("Message"), MB_OKCANCEL|MB_ICONINFORMATION ) == IDOK )
        {
            isNeedPrompting = false;
        }
        isMsgShow = false;
    }

    free(notifyInfo->attendee_list);
    notifyInfo->attendee_list = NULL;
    delete notifyInfo;

    CDemoApp* app = (CDemoApp*)AfxGetApp();
    if (!app)
    {
        //�����Ѿ��ر�
        return 0L;
    }
    CDemoMainDlg* maindlg = (CDemoMainDlg*)(app->m_pMainDlgWnd);
    if (NULL == maindlg)
    {
        return 0L;
    }
    ::PostMessage(maindlg->GetSafeHwnd(), WM_CALL_CONF_REFRESH, NULL, NULL);

    return 0L;
}

BOOL CDemoAudioMeetingDlg::FindColum(const CString& cstrKey, int iColnum, int& iFind)
{
    int iSize = m_listMember.GetItemCount();
    for (int i = 0; i < iSize; i++)
    {
        if (cstrKey.Compare(m_listMember.GetItemText(i, iColnum)) == 0)
        {
            iFind = i;
            return TRUE;
        }
    }
    return FALSE;
}

void CDemoAudioMeetingDlg::GetAttendes(std::vector<CString> &_member)
{
    auto iSize = m_listMember.GetItemCount();
    for (auto i = 0; i < iSize; i++)
    {
        CString cstr(L"");
        cstr = m_listMember.GetItemText(i, COL_MEM_CALLNO);
        _member.push_back(cstr);
    }
    m_listMember.DeleteAllItems();
}

void CDemoAudioMeetingDlg::CloseDlg()
{
    //�رնԻ���ʱ�˳����飬��ֱֹ�ӹس����쳣
    OnBnClickedBtLeaveConf();

    /////data clear////
    m_confID = 0;
    m_callID = 0;
    m_handle = 0;
    ischairman = false;
    ispresenter = false;
    isNeedPrompting = true;
    is_in_roll_calling = false;
    rollCalledNumber = "";
    OnOK();
}

//��ز����������
LRESULT CDemoAudioMeetingDlg::OnConfOperationResult(WPARAM wparam, LPARAM)
{
    TSDK_S_CONF_OPERATION_RESULT* notifyInfo = (TSDK_S_CONF_OPERATION_RESULT*)wparam;
    CHECK_POINTER_RETURN(notifyInfo, -1L);

    if (TSDK_SUCCESS != notifyInfo->reason_code)
    {
        if(notifyInfo->operation_type == TSDK_E_CONF_ROLL_CALL)
        {
            is_in_roll_calling = FALSE;
            m_btn_cancel_rollcall.EnableWindow(FALSE);
            rollCalledNumber = "";
        }
        MessageBox(_T("operation failed!"));
        return -1L;
    }
   
    switch (notifyInfo->operation_type)
    {
    case TSDK_E_CONF_MUTE_CONF:
    {
        m_bt_Mute.SetWindowText(_T("UnMute Conf"));
        break;
    }
    case TSDK_E_CONF_UNMUTE_CONF:
    {
        m_bt_Mute.SetWindowText(_T("Mute Conf"));
        break;
    }
    case TSDK_E_CONF_LOCK_CONF:
    {
        m_bt_Lock.SetWindowText(_T("UnLock Conf"));
        break;
    }
    case TSDK_E_CONF_UNLOCK_CONF:
    {
        m_bt_Lock.SetWindowText(_T("Lock Conf"));
        break;
    }
    case TSDK_E_CONF_SET_HANDUP:
    case TSDK_E_CONF_CANCLE_HANDUP:
    {
        CString csHandup;
        m_bt_Handup.GetWindowText(csHandup);
        if (_T("Hand Up") == csHandup)
        {
            m_bt_Handup.SetWindowText(_T("unHand Up"));
        }
        else
        {
            m_bt_Handup.SetWindowText(_T("Hand Up"));
        }
        
        break;
    }
    case TSDK_E_CONF_REQUEST_CHAIRMAN:
    {
        ischairman = true;
        m_bt_Apply.EnableWindow(FALSE);
        m_bt_Release.EnableWindow(TRUE);
        break;
    }
    case TSDK_E_CONF_RELEASE_CHAIRMAN:
    {
        ischairman = false;
        m_bt_Apply.EnableWindow(TRUE);
        m_bt_Release.EnableWindow(FALSE);
        break;
    }
    case TSDK_E_CONF_POSTPONE_CONF:
    {
        MessageBox(_T("postpone conference success!"));
        isNeedPrompting = true;
        break;
    }
    case TSDK_E_CONF_ROLL_CALL:
    {
        is_in_roll_calling = TRUE;
        m_btn_cancel_rollcall.EnableWindow(TRUE);
        break;
    }

    default:
        break;
    }
    
    return 0L;
}

//���Է�֪ͨ
LRESULT CDemoAudioMeetingDlg::OnConfSpeakerUpdate(WPARAM wparam, LPARAM)
{
    TSDK_S_CONF_SPEAKER_INFO* notifyInfo = (TSDK_S_CONF_SPEAKER_INFO*)wparam;
    CHECK_POINTER_RETURN(notifyInfo, -1L);

    for(int i = 0; i < m_listMember.GetItemCount(); i++)
    {
        m_listMember.SetItemText(i, COL_MEM_SPK, _T(""));
    }

    unsigned int number = notifyInfo->speaker_num;
    for (unsigned int i = 0; i < number; i++)
    {
        std::string attendeesnumber = notifyInfo->speakers[i].base_info.number;
        int iColumn;
        if (!FindColum(CTools::UTF2UNICODE(attendeesnumber), COL_MEM_CALLNO, iColumn))
        {
            continue;
        }
        if (notifyInfo->speakers[i].is_speaking)
        {
            m_listMember.SetItemText(iColumn, COL_MEM_SPK, _T("Speaking"));
        }
        else
        {
            m_listMember.SetItemText(iColumn, COL_MEM_SPK, _T(""));
        }
    }

    delete notifyInfo;
    return 0L;
}


LRESULT CDemoAudioMeetingDlg::OnConfUiPluginClickLeaveConf(WPARAM wparam, LPARAM)
{
    OnBnClickedBtLeaveConf();
    return 0L;
}


LRESULT CDemoAudioMeetingDlg::OnConfUiPluginClickEndConf(WPARAM wparam, LPARAM)
{
    OnBnClickedBtEndConf();
    return 0L;
}


LRESULT CDemoAudioMeetingDlg::OnConfUiPluginClickStartShare(WPARAM wparam, LPARAM)
{
    CString selfNum = CTools::GetSipNumber(g_sipNumber);
    std::string strSelfNum = CTools::UNICODE2UTF(selfNum);

    (void)service_data_conf_app_share_set_owner(const_cast<char*>(strSelfNum.c_str()), TSDK_E_CONF_AS_ACTION_ADD);

    return 0L;
}

LRESULT CDemoAudioMeetingDlg::OnConfUiPluginSetWindowSize(WPARAM wparam, LPARAM lparam)
{
    TSDK_S_UI_PLUGIN_WND_SIZE_INFO* wndSizeInfo = (TSDK_S_UI_PLUGIN_WND_SIZE_INFO *)lparam;
    CHECK_POINTER_RETURN(wndSizeInfo, -1L);

    CRect wndinfo;
    GetWindowRect(&wndinfo);
    this->MoveWindow(wndSizeInfo->left_top_x - wndinfo.Width(), wndSizeInfo->left_top_y, wndinfo.Width(), wndinfo.Height());

    delete wndSizeInfo;
    return 0L;
}


std::string CDemoAudioMeetingDlg::GetUserStatus(TSDK_E_CONF_PARTICIPANT_STATUS status)
{
    std::string strStatus;
    switch (status)
    {

    case TSDK_E_CONF_PARTICIPANT_STATUS_IN_CONF:  /**< in conference*/
    {
        strStatus = "InConf";
        break;
    }
    case TSDK_E_CONF_PARTICIPANT_STATUS_CALLING: /**< calling */
    {
        strStatus = "Inviting";
        break;
    }
    case TSDK_E_CONF_PARTICIPANT_STATUS_JOINING: /**< joining conference */
    {
        strStatus = "Joining";
        break;
    }
    case TSDK_E_CONF_PARTICIPANT_STATUS_LEAVED:  /**< leave conference */
    {
        strStatus = "Leave";
        break;
    }
    case TSDK_E_CONF_PARTICIPANT_STATUS_NO_EXIST: /**< this participant is not exist */
    {
        strStatus = "None";
        break;
    }
    case TSDK_E_CONF_PARTICIPANT_STATUS_BUSY:     /**< busy */
    {
        strStatus = "Busy";
        break;
    }
    default:
        strStatus = "Add Fail";
        break;
    }
    return strStatus;
}


void CDemoAudioMeetingDlg::UpdateAudioConfButtonStatus()
{
    if (ischairman)
    {
        m_bt_Mute.EnableWindow(TRUE);
        m_bt_Lock.EnableWindow(TRUE);

        if (LOGIN_ENV_VC == g_login_env_type)
        {
            //VCģʽ�²�֧����������
            m_bt_DataConf.EnableWindow(FALSE);
        }
        else
        {
            m_bt_DataConf.EnableWindow(TRUE);
        }

        m_bt_Handup.EnableWindow(FALSE);
        m_bt_Apply.EnableWindow(FALSE);
        m_bt_Release.EnableWindow(TRUE);
        m_bt_Add.EnableWindow(TRUE);
        m_bt_Dtmf.EnableWindow(TRUE);
        m_cbxVideoConfMode.EnableWindow(TRUE);
        m_bt_End_Conf.EnableWindow(TRUE);
        m_bt_Leave_Conf.EnableWindow(TRUE);
        m_btn_postpone.EnableWindow(TRUE);
        m_btn_apply_speak.EnableWindow(FALSE);
    }
    else
    {
        m_bt_Mute.EnableWindow(FALSE);
        m_bt_Lock.EnableWindow(FALSE);
        m_bt_DataConf.EnableWindow(FALSE);
        m_bt_Handup.EnableWindow(TRUE);
        m_bt_Release.EnableWindow(FALSE);
        m_bt_Add.EnableWindow(FALSE);
        m_bt_Dtmf.EnableWindow(TRUE);
        m_cbxVideoConfMode.EnableWindow(FALSE);
        m_bt_End_Conf.EnableWindow(FALSE);
        m_bt_Leave_Conf.EnableWindow(TRUE);
        m_btn_postpone.EnableWindow(FALSE);
        if (ischairmanexist)//����������ϯ����
        {
             m_bt_Apply.EnableWindow(FALSE);
             m_btn_apply_speak.EnableWindow(TRUE);
        }
        else
        {
             m_bt_Apply.EnableWindow(TRUE);
             m_btn_apply_speak.EnableWindow(FALSE);
        }

    }

    if(is_in_roll_calling && ischairman)
    {
        m_btn_cancel_rollcall.EnableWindow(TRUE);
    }
    else
    {
        m_btn_cancel_rollcall.EnableWindow(FALSE);
    }

    if (AUDIO_DATA_CONF == m_confType || VIDEO_DATA_CONF == m_confType)
    {
        m_bt_DataConf.EnableWindow(FALSE);
        m_btn_publicMsg.EnableWindow(TRUE);
        GetDlgItem(IDC_BT_APPLY_PRESENTER)->EnableWindow(TRUE);
        m_btn_publicData.EnableWindow(TRUE);
        m_btn_wiredProjection.EnableWindow(TRUE);
        m_btn_wirelessProjection.EnableWindow(TRUE);
    }
    else
    {
        m_btn_publicMsg.EnableWindow(FALSE);
        GetDlgItem(IDC_BT_APPLY_PRESENTER)->EnableWindow(FALSE);
        m_btn_publicData.EnableWindow(FALSE);
        m_btn_wiredProjection.EnableWindow(FALSE);
        m_btn_wirelessProjection.EnableWindow(FALSE);
    }

}


void CDemoAudioMeetingDlg::OnBnClickedBtPostponeConf()
{
    UpdateData(true);
    (void)service_conf_postpone_conference(m_handle, m_postponeTime);
}

void CDemoAudioMeetingDlg::OnBnClickedBtApplyPresenter()
{
    // TODO: ���������˴���
    (void)service_data_conf_apply_presenter(m_handle);
}

LRESULT CDemoAudioMeetingDlg::OnReceivedChatMsg(WPARAM wparam, LPARAM)
{
    TSDK_S_CONF_CHAT_MSG_INFO* notifyInfo = (TSDK_S_CONF_CHAT_MSG_INFO*)wparam;
    CHECK_POINTER_RETURN(notifyInfo, -1L);
    CString chatMsg;
    chatMsg = CTools::UTF2UNICODE(notifyInfo->chat_msg);
    CString cstrNum = CTools::UTF2UNICODE(notifyInfo->sender_number);

    CTime sendTime = CTime(notifyInfo->time);
    CString szTime = sendTime.Format("%Y-%m-%d %H:%M:%S");

    delete []notifyInfo->chat_msg;
    delete notifyInfo;

    CDemoChatDlg dlg;
    dlg.SetDlgType(false);
    CString& msg =  dlg.GetChatMsg();
    msg.Format(L"Sender Number : %s\r\nSend Time : %s \r\nChat Content : %s", cstrNum, szTime, chatMsg);
    dlg.DoModal();

    return 0L;
}

void CDemoAudioMeetingDlg::OnBnClickedButtonPublicchat()
{
    // TODO: �ڴ����ӿؼ�֪ͨ�����������
    SendChatMessage(TSDK_E_CONF_CHAT_PUBLIC, _T(""));
}

void CDemoAudioMeetingDlg::SendChatMessage(TSDK_E_CONF_CHAT_TYPE chatType, CString szRevicierNum)
{
    CDemoChatDlg dlg;
    dlg.SetDlgType(true);
    if(IDOK == dlg.DoModal())
    {
        TSDK_S_CONF_CHAT_MSG_INFO msgInfo;
        memset_s(&msgInfo, sizeof(msgInfo), 0, sizeof(TSDK_S_CONF_CHAT_MSG_INFO));
        msgInfo.chat_type = chatType;
        if(TSDK_E_CONF_CHAT_PRIVATE == chatType)
        {
            CTools::CString2Char(szRevicierNum, msgInfo.receiver_number, TSDK_D_MAX_NUMBER_LEN + 1);
        }
        string utf8Str = CTools::UNICODE2UTF(dlg.GetChatMsg());
        msgInfo.chat_msg = (TSDK_CHAR *)utf8Str.c_str();
        msgInfo.chat_msg_len = strlen(msgInfo.chat_msg);

        if(TSDK_SUCCESS != service_data_conf_send_chat_msg(&msgInfo))
        {
            MessageBox(_T("Send Message failed."));
        }
    }
}

void CDemoAudioMeetingDlg::OnBnClickedBtApplySpeak()
{
    //����ϯ�ն����뷢��
    (void)service_conf_apply_speak(m_handle, FALSE);
}

void CDemoAudioMeetingDlg::OnBnClickedButtonNet()
{
    TSDK_S_MEDIA_QOS_INFO qos_info = {0};
    service_get_call_info(m_callID, &qos_info);

    CDemoApp* app = (CDemoApp*)AfxGetApp();
    if (!app)
    {
        //�����Ѿ��ر�
        return;
    }
    CDemoMainDlg* maindlg = (CDemoMainDlg*)(app->m_pMainDlgWnd);
    CHECK_POINTER(maindlg);

    if (NULL == m_pNetWorkInfoDlg)
    {
        m_pNetWorkInfoDlg = new CDemoCallNetInfoDlg(maindlg, m_callID);
    }
    if (!::IsWindow(m_pNetWorkInfoDlg->GetSafeHwnd()))
    {
        (void)m_pNetWorkInfoDlg->Create(CDemoCallNetInfoDlg::IDD, maindlg);
    }
    m_pNetWorkInfoDlg->ShowWindow(SW_SHOW);
    m_pNetWorkInfoDlg->UpdateNetInfo(qos_info);
}

void CDemoAudioMeetingDlg::CloseNetWorkWindow()
{
    //�ر�������Ϣ����
    if (NULL != m_pNetWorkInfoDlg
        && NULL != m_pNetWorkInfoDlg->GetSafeHwnd()
        && ::IsWindow(m_pNetWorkInfoDlg->GetSafeHwnd()))
    {
        m_pNetWorkInfoDlg->DestroyWindow();
        SAFE_DELETE(m_pNetWorkInfoDlg);
    }
}


//ȡ������
void CDemoAudioMeetingDlg::OnBnClickedBtCancelRollcall()
{
    int result = service_roll_call(m_handle, TSDK_NULL_PTR);
    if(TSDK_SUCCESS == result)
    {
        is_in_roll_calling = FALSE;
        m_btn_cancel_rollcall.EnableWindow(FALSE);
        rollCalledNumber = "";
    }
}


LRESULT CDemoAudioMeetingDlg::OnReceivedUserDataMsg(WPARAM wparam, LPARAM)
{
    TSDK_S_CONF_CUSTOM_DATA_INFO* notifyInfo = (TSDK_S_CONF_CUSTOM_DATA_INFO*)wparam;
    CHECK_POINTER_RETURN(notifyInfo, -1L);
    CString chatMsg;
    char* buffer = new char[notifyInfo->data_len+1];
    memset_s(buffer, notifyInfo->data_len + 1, 0, notifyInfo->data_len + 1);
    memcpy_s(buffer, notifyInfo->data_len+1, notifyInfo->data_content, notifyInfo->data_len);
    string str = buffer;
    chatMsg = CTools::UTF2UNICODE(str); 
    CString cstrNum = CTools::UTF2UNICODE(notifyInfo->sender_number);
 
    if(TSDK_AS_NOTICE_ALL_USERS_CLOSE_SHARING_TAB != notifyInfo->msg_id && TSDK_AS_NOTICE_ALL_USERS_SHIFT_SHARING_TAB != notifyInfo->msg_id)   //���ݻ��������������󣬻ᷢ��msg_id=20�Ĺ�����Ϣ���Դ���Ϣid�����е���
    {
        CDemoChatDlg dlg;
        dlg.SetDlgType(false);
        CString& msg =  dlg.GetChatMsg();
        msg.Format(L"Sender Number : %s\r\nData Content : %s\r\nmsg_id: %d", cstrNum, chatMsg, notifyInfo->msg_id);
        dlg.DoModal();
    }

    delete []buffer;
    delete []notifyInfo->data_content;
    delete notifyInfo;
    return 0L;
}

void CDemoAudioMeetingDlg::SendData(TSDK_S_CONF_CUSTOM_DATA_TYPE dataType, CString szRevicierNum, UINT cstrDataMsgid)
{
    CDemoChatDlg dlg;
    dlg.SetDlgType(true);
    if(IDOK == dlg.DoModal())
    {
        TSDK_S_CONF_CUSTOM_DATA_INFO dataInfo;
        memset_s(&dataInfo, sizeof(dataInfo), 0, sizeof(TSDK_S_CONF_CUSTOM_DATA_INFO));
        dataInfo.data_type = dataType;
        if(TSDK_S_CONF_CUSTOM_PRIVATE_DATA == dataType)
        {
            CTools::CString2Char(szRevicierNum, dataInfo.receiver_number, TSDK_D_MAX_NUMBER_LEN + 1);
        }
        string utf8Str = CTools::UNICODE2UTF(dlg.GetChatMsg());
        dataInfo.data_content = (TSDK_UINT8 *)utf8Str.c_str();
        dataInfo.data_len = strlen(utf8Str.c_str());
        dataInfo.msg_id = cstrDataMsgid;

        if(TSDK_SUCCESS != service_data_conf_send_data_msg(&dataInfo))
        {
            MessageBox(_T("Send Data failed."));
        }
    }
}

void CDemoAudioMeetingDlg::OnBnClickedButtonPublicdata()
{
    UpdateData(true);
    //���͹�������
    if(m_edit_send_data_msgid < 0 || m_edit_send_data_msgid > 85)
    {
        MessageBox(_T("The msgid must between 0 to 85"));
        return;
    }

    SendData(TSDK_S_CONF_CUSTOM_PUBLIC_DATA, _T(""), m_edit_send_data_msgid);
}


void CDemoAudioMeetingDlg::OnBnClickedButtonSetSubject()
{
    CString subject;
    CString seperator = _T("#");
    int position = 0;
    CString title("HuaweiMeeting");
    CString confId("123456");
    
    m_edit_subject.GetWindowText(subject);
    
    if (subject.GetLength() > 0)
    {
        title = subject.Tokenize(seperator,position);
        confId = subject.Right(subject.GetLength() - position);
    }
    (void)service_conf_set_window_title(const_cast<char*>(CTools::UNICODE2UTF(title).c_str()), 
        const_cast<char*>(CTools::UNICODE2UTF(confId).c_str()));
}


void CDemoAudioMeetingDlg::OnBnClickedButtonSetWiredprojection()
{
    service_set_projection_mode(TSDK_E_UI_WIRED_PROJECTION_TYPE, 0);
}


void CDemoAudioMeetingDlg::OnBnClickedButtonSetWirelessprojection()
{
    TSDK_S_AS_WINDOW_INFO appInfoList[256] = { 0 };
    TSDK_UINT32 appCount = 256;

    service_conf_get_app_list(m_handle, appInfoList, &appCount);
    if (appCount < 0 || appCount >256)
    {
        return;
    }

    for (TSDK_UINT32 loop = 0; loop < appCount; loop++)
    {
        if (appInfoList[loop].window_title != NULL && appInfoList[loop].window_handle != NULL)
        {
            wstring pTitle = (wchar_t*)appInfoList[loop].window_title;
            if (pTitle == L"eShare")
            {
                service_set_projection_mode(TSDK_E_UI_WIRELESS_PROJECTION_TYPE, (TSDK_UINT32)((HWND)(appInfoList[loop].window_handle)));
                break;
            }
        }
    }
}
