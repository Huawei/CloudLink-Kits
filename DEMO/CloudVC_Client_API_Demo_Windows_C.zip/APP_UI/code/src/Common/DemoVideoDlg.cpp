//
//  DemoVideoDlg.cpp
//  EC_SDK_DEMO
//
//  Created by EC Open support team.
//  Copyright(C), 2018, Huawei Tech. Co., Ltd. ALL RIGHTS RESERVED.
//

#include "stdafx.h"
#include "afxdialogex.h"
#include "DemoVideoDlg.h"
#include "service_call_interface.h"

extern CString g_sipNumber;
// CDemoVideoDlg dialog

IMPLEMENT_DYNAMIC(CDemoVideoDlg, CDialogEx)

	CDemoVideoDlg::CDemoVideoDlg(CWnd* pParent /*=NULL*/)
	: CDialogEx(CDemoVideoDlg::IDD, pParent)
    , m_callID(0)
{

}

CDemoVideoDlg::~CDemoVideoDlg()
{
    m_callID = 0;
}

void CDemoVideoDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_REMOTE_VIDEO, m_remoteVideo);
	DDX_Control(pDX, IDC_LOCAL_VIDEO, m_localVideo);
	DDX_Control(pDX, IDC_TITLE_REMOTE_VIDEO, m_title_remote);
	DDX_Control(pDX, IDC_TITLE_LOCAL_VIDEO, m_title_local);
    DDX_Control(pDX, IDC_BT_CONTROL_VIDEO, m_bt_video_control);
}

BEGIN_MESSAGE_MAP(CDemoVideoDlg, CDialogEx)
    ON_BN_CLICKED(IDC_BT_CONTROL_VIDEO,CDemoVideoDlg::OnClickedBtControlVideo)
END_MESSAGE_MAP()


// CDemoRunInfoDlg message handlers
BOOL CDemoVideoDlg::OnInitDialog()
{
    CDialog::OnInitDialog();

    CString strCaption;
    if (0 == g_sipNumber.GetLength())
    {
        strCaption.Format(_T("Video Dialog"));
    }
    else
    {
        strCaption.Format(_T("Video Dialog(%s)"), g_sipNumber);
    }

    this->SetWindowText(strCaption);

	return TRUE;
}


void CDemoVideoDlg::BindVideoWindow()
{
    HWND localVideo = m_localVideo.GetSafeHwnd();
    HWND remoteVideo = m_remoteVideo.GetSafeHwnd();
    (void)service_set_video_window(m_callID, (unsigned int)localVideo, (unsigned int)remoteVideo);
}

void CDemoVideoDlg::OnClickedBtControlVideo()
{
    CString csMIc;
    m_bt_video_control.GetWindowText(csMIc);
    if (m_callID)
    {
        if (_T("Stop Video") == csMIc)
        {
            m_bt_video_control.SetWindowText(_T("Start Video"));
            service_call_video_control(m_callID, TRUE);
        }
        else
        {
            m_bt_video_control.SetWindowText(_T("Stop Video"));
            service_call_video_control(m_callID, FALSE);
        }
    }
}
