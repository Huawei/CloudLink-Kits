//
//  DemoMediaSettingDlg.cpp
//  EC_SDK_DEMO
//
//  Created by EC Open support team.
//  Copyright(C), 2018, Huawei Tech. Co., Ltd. ALL RIGHTS RESERVED.
//

#include "stdafx.h"
#include "afxdialogex.h"
#include "DemoMediaSettingDlg.h"
#include "DemoCommonTools.h"
#include "DemoData.h"
#include "DemoMainDlg.h"
#include "tsdk_call_def.h"
#include "service_os_adapt.h"
#include "service_call_interface.h"
#include "service_init.h"

#define DEVICE_NUM 10

int global_max_band = 5;
CString global_account_label_name = _T("");

// CDemoMediaSettingDlg dialog

IMPLEMENT_DYNAMIC(CDemoMediaSettingDlg, CDialogEx)

CDemoMediaSettingDlg::CDemoMediaSettingDlg(CWnd* pParent /*=NULL*/)
    : CDialogEx(CDemoMediaSettingDlg::IDD, pParent)
{
    preview_open = false;
}

CDemoMediaSettingDlg::~CDemoMediaSettingDlg()
{
}

void CDemoMediaSettingDlg::DoDataExchange(CDataExchange* pDX)
{
    CDialogEx::DoDataExchange(pDX);
    DDX_Control(pDX, IDC_COMBO_AUDIN_DEV, m_cbxAudioInputDev);
    DDX_Control(pDX, IDC_COMBO_AUDOUT_DEV, m_cbxAudioOutDev);
    DDX_Control(pDX, IDC_COMBO_VIDEO_DEV, m_cbxVideoDev);
    DDX_Control(pDX, IDC_SLIDER_AUD_OUT, m_sldSpeakLevel);
    DDX_Control(pDX, IDC_STATIC_PREVIEW, m_PreviewWnd);
    DDX_Control(pDX, IDC_COMBO_MAX_BAND_WIDTH, m_cbxMaxBand);
    DDX_Control(pDX, IDC_EDIT_ACCOUNT_LABEL_NAME, m_account_label_name);
}


BEGIN_MESSAGE_MAP(CDemoMediaSettingDlg, CDialogEx)
    ON_CBN_SELCHANGE(IDC_COMBO_AUDIN_DEV, &CDemoMediaSettingDlg::OnCbnSelchangeComboAudinDev)
    ON_CBN_SELCHANGE(IDC_COMBO_AUDOUT_DEV, &CDemoMediaSettingDlg::OnCbnSelchangeComboAudoutDev)
    ON_CBN_SELCHANGE(IDC_COMBO_VIDEO_DEV, &CDemoMediaSettingDlg::OnCbnSelchangeComboVideoDev)
    ON_NOTIFY(NM_RELEASEDCAPTURE, IDC_SLIDER_AUD_OUT, &CDemoMediaSettingDlg::OnNMReleasedcaptureSliderAudOut)
    ON_BN_CLICKED(IDC_BUTTON_PREVIEW_OPEN, &CDemoMediaSettingDlg::OnBnClickedButtonPreviewOpen)
    ON_BN_CLICKED(IDC_BUTTON_PREVIEW_CLOSE, &CDemoMediaSettingDlg::OnBnClickedButtonPreviewClose)
    ON_CBN_SELCHANGE(IDC_COMBO_MAX_BAND_WIDTH, &CDemoMediaSettingDlg::OnCbnSelchangeComboMaxBand)
    ON_BN_CLICKED(IDC_BUTTON_SET_ACCOUNT_LABEL_NAME, &CDemoMediaSettingDlg::OnBnClickedButtonSetAccountLabelName)
END_MESSAGE_MAP()

// CDemoMediaSettingDlg ��Ϣ��������
BOOL CDemoMediaSettingDlg::OnInitDialog()
{
    CDialogEx::OnInitDialog();

    InitDevice();
    RefreshControl();

    return TRUE;
}

void CDemoMediaSettingDlg::InitDevice()
{
    unsigned int uiDevideNUm(DEVICE_NUM);
    ///get mic devices
    TSDK_S_DEVICE_INFO* pMicdevices = new TSDK_S_DEVICE_INFO[DEVICE_NUM];
    service_memset_s(pMicdevices, sizeof(TSDK_S_DEVICE_INFO)*DEVICE_NUM, 0, sizeof(TSDK_S_DEVICE_INFO)*DEVICE_NUM);
    service_get_devices(&uiDevideNUm, pMicdevices, TSDK_E_DEVICE_MIC);
    for (unsigned int i = 0; i < uiDevideNUm; i++)
    {
        m_cbxAudioInputDev.InsertString((int)pMicdevices[i].index, CTools::UTF2UNICODE(pMicdevices[i].device_name));
    }
    delete (pMicdevices);

    ///get spk devices
    uiDevideNUm = DEVICE_NUM;
    TSDK_S_DEVICE_INFO* pSpkdevice = new TSDK_S_DEVICE_INFO[DEVICE_NUM];
    service_memset_s(pSpkdevice, sizeof(TSDK_S_DEVICE_INFO)*DEVICE_NUM, 0, sizeof(TSDK_S_DEVICE_INFO)*DEVICE_NUM);
    service_get_devices(&uiDevideNUm, pSpkdevice, TSDK_E_DEVICE_SPEAKER);
    for (unsigned int i = 0; i < uiDevideNUm; i++)
    {
        m_cbxAudioOutDev.InsertString((int)pSpkdevice[i].index, CTools::UTF2UNICODE(pSpkdevice[i].device_name));
    }
    delete (pSpkdevice);

    //GetVideo Device
    uiDevideNUm = DEVICE_NUM;
    TSDK_S_DEVICE_INFO* pVideo = new TSDK_S_DEVICE_INFO[DEVICE_NUM];
    service_memset_s(pVideo, sizeof(TSDK_S_DEVICE_INFO)*DEVICE_NUM, 0, sizeof(TSDK_S_DEVICE_INFO)*DEVICE_NUM);
    service_get_devices(&uiDevideNUm, pVideo, TSDK_E_DEVICE_CAMERA);
    for (unsigned int i = 0; i < uiDevideNUm; i++)
    {
        m_cbxVideoDev.InsertString((int)pVideo[i].index, CTools::UTF2UNICODE(pVideo[i].device_name));
    }
    delete(pVideo);

    //init spk volue
    m_sldSpeakLevel.SetRange(0, 100);
    unsigned int spkLevel;
    service_get_speak_volume(&spkLevel);
    m_sldSpeakLevel.SetPos((int)spkLevel);

    //��ʼ������������ѡ���
    m_cbxMaxBand.InsertString(0, _T("64kbit/s"));
    m_cbxMaxBand.InsertString(1, _T("128kbit/s"));
    m_cbxMaxBand.InsertString(2, _T("256kbit/s"));
    m_cbxMaxBand.InsertString(3, _T("384kbit/s"));
    m_cbxMaxBand.InsertString(4, _T("512kbit/s"));
    m_cbxMaxBand.InsertString(5, _T("768kbit/s"));
    m_cbxMaxBand.InsertString(6, _T("1024kbit/s"));
    m_cbxMaxBand.InsertString(7, _T("1472kbit/s"));
    m_cbxMaxBand.InsertString(8, _T("1536kbit/s"));
    m_cbxMaxBand.InsertString(9, _T("1920kbit/s"));
    m_cbxMaxBand.InsertString(10, _T("2048kbit/s"));
    m_cbxMaxBand.InsertString(11, _T("3072kbit/s"));
    m_cbxMaxBand.InsertString(12, _T("4096kbit/s"));

    m_cbxMaxBand.SetCurSel(global_max_band);
    CString strMaxBandText;
    m_cbxMaxBand.GetLBText(global_max_band, strMaxBandText);
    if (strMaxBandText.GetLength() > 0)
    {
        m_cbxMaxBand.SetWindowText(strMaxBandText);
    }

    //����account_label_name
    m_account_label_name.SetWindowText(global_account_label_name);
}


void CDemoMediaSettingDlg::RefreshControl()
{
    unsigned int micIndex = 0;
    unsigned int spkIndex = 0;
    unsigned int videoIndex = 0;
    ///setMIC
    service_device_get_index(&micIndex, TSDK_E_DEVICE_MIC);
    m_cbxAudioInputDev.SetCurSel((int)micIndex);
    ////Set spk
    service_device_get_index(&spkIndex, TSDK_E_DEVICE_SPEAKER);
    m_cbxAudioOutDev.SetCurSel((int)spkIndex);
    ////set video
    service_device_get_index(&videoIndex, TSDK_E_DEVICE_CAMERA);
    m_cbxVideoDev.SetCurSel((int)videoIndex);
}



void CDemoMediaSettingDlg::OnCbnSelchangeComboAudinDev()
{
    int Index = m_cbxAudioInputDev.GetCurSel();
    service_device_set_index((unsigned int)Index, TSDK_E_DEVICE_MIC);
}


void CDemoMediaSettingDlg::OnCbnSelchangeComboAudoutDev()
{
    int Index = m_cbxAudioOutDev.GetCurSel();
    service_device_set_index((unsigned int)Index, TSDK_E_DEVICE_SPEAKER);
}

void CDemoMediaSettingDlg::OnCbnSelchangeComboVideoDev()
{
    int Index = m_cbxVideoDev.GetCurSel();
    service_device_set_index((unsigned int)Index, TSDK_E_DEVICE_CAMERA);
}


void CDemoMediaSettingDlg::OnNMReleasedcaptureSliderAudOut(NMHDR *pNMHDR, LRESULT *pResult)
{
    *pResult = 0;
    unsigned int spkLevel = (unsigned int)m_sldSpeakLevel.GetPos();
    service_set_speak_volume(spkLevel);
}


void CDemoMediaSettingDlg::OnBnClickedButtonPreviewOpen()
{
    unsigned int videoIndex = 0;
    HANDLE previewhand = m_PreviewWnd.GetSafeHwnd();
    service_device_get_index(&videoIndex, TSDK_E_DEVICE_CAMERA);
    service_video_open_preview((unsigned int)previewhand, videoIndex);
}


void CDemoMediaSettingDlg::OnBnClickedButtonPreviewClose()
{
    Invalidate(TRUE);
    service_video_close_preview();
}

void CDemoMediaSettingDlg::OnCbnSelchangeComboMaxBand()
{
    int selected = m_cbxMaxBand.GetCurSel();
    TSDK_E_VIDEO_DATA_RATE enum_data_rate = (TSDK_E_VIDEO_DATA_RATE)selected;
    service_set_video_data_rate(enum_data_rate);
    global_max_band = selected;
}

void CDemoMediaSettingDlg::OnBnClickedButtonSetAccountLabelName()
{
    CString tmp_account_label_name;
    m_account_label_name.GetWindowText(tmp_account_label_name);
    if (tmp_account_label_name.GetLength() > 0)
    {
        TSDK_CHAR chr_account_label_name[64 + 1] = { 0 };
        (CTools::UNICODE2UTF(tmp_account_label_name)).copy(chr_account_label_name, 64, 0);
        int result = service_set_account_lable_name(chr_account_label_name);
        if (result == 0)
        {
            global_account_label_name.Empty();
            string str_account_label_name = chr_account_label_name;
            global_account_label_name = CTools::UTF2UNICODE(str_account_label_name);
            m_account_label_name.SetWindowText(global_account_label_name);
            AfxMessageBox(_T("set account lable name success"));
        }
        else 
        {
            AfxMessageBox(_T("set account lable name failed!"));
        }
    }
    else
    {
        AfxMessageBox(_T("please input account lable name"));
    }
}
