
#include "stdio.h"
#include "windows.h"
#include "tsdk.h"
#include "service_log.h"
#include "service_ldap_interface.h"

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* __cplusplus */

    SERVICE_LDAP int service_ldap_search(TSDK_S_SEARCH_CONDITION *searchCondition, TSDK_UINT32 *seq_no)
    {
        TSDK_UINT32 result = 0;

        if (TSDK_NULL_PTR == searchCondition)
        {
            LOG_D_LDAP_ERROR("param searchCondition is null");
            return -1;
        }
        result = tsdk_ldap_search(searchCondition, seq_no);
        if (TSDK_SUCCESS != result)
        {
            LOG_D_LDAP_ERROR("tsdk_ldap_search failed!");
            return -1;
        }
        return result;
    }

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* __cplusplus */