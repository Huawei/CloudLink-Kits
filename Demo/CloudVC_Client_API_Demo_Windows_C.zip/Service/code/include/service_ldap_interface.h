//
//  service_login.h
//  EC_SDK_DEMO
//
//  Created by EC Open support team.
//  Copyright(C), 2018, Huawei Tech. Co., Ltd. ALL RIGHTS RESERVED.
//

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* __cplusplus */

#include "tsdk_ldap_frontstage_def.h"

#ifdef SERVICE_EXPORTS
#define SERVICE_LDAP __declspec(dllexport)
#else
#define SERVICE_LDAP __declspec(dllimport)
#endif

    /**
    * @service_ldap_search
    * @brief [en]This interface is used to search contacts.
    *        [cn]��ѯ��ϵ�˽ӿ�
    *
    * @param [in] TSDK_S_SEARCH_CONDITION *searchCondition       [en]Indicates info of search condition.
    *                                                            [cn]��ѯ����
    *
    * @param [in] TSDK_UINT32 *seq_no                            [en]Indicates info of search sequence no.
    *                                                            [cn]��ѯ����
    * @retval int                [en]If success return TSDK_SUCCESS, otherwise return corresponding error code.
    *                            [cn]�ɹ�����TSDK_SUCCESS��ʧ�ܷ�����Ӧ�����룬ȡֵ�ο�TSDK_E_CONF_ERR_ID
    *
    * @attention [en]Before querying contacts, make sure that the LDAP service is enabled before calling this interface
    *            [cn]��ѯ��ϵ�ˣ����ýӿ�֮ǰ��ȷ��LDAP �����ѿ���
    **/
    SERVICE_LDAP int service_ldap_search(TSDK_S_SEARCH_CONDITION *searchCondition, TSDK_UINT32 *seq_no);

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* __cplusplus */