#pragma once

#include "afxcmn.h"
#include "Resource.h"
#include "afxwin.h"
#include "service_call_interface.h"

// CDemoCallNetInfoDlg �Ի���

class CDemoCallNetInfoDlg : public CDialogEx
{
    DECLARE_DYNAMIC(CDemoCallNetInfoDlg)

public:
    CDemoCallNetInfoDlg(CWnd* pParent = NULL, unsigned int CallID = 0);   // ��׼���캯��
    virtual ~CDemoCallNetInfoDlg();

// �Ի�������
    enum { IDD = IDD_NETINFO_DLG };

protected:
    virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

    DECLARE_MESSAGE_MAP()
public:
    CListCtrl m_lstAudioInfo;
    CListCtrl m_lstVideoInfo;
    unsigned int m_CallID;
    virtual BOOL OnInitDialog();
    void UpdateNetInfo(TSDK_S_MEDIA_QOS_INFO qos_info);
    afx_msg void OnTimer(UINT_PTR nIDEvent);
    CListCtrl m_lstRxVideo;
};
