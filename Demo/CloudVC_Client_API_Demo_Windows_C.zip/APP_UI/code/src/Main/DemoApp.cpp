//
//  DemoApp.cpp
//  EC_SDK_DEMO
//
//  Created by EC Open support team.
//  Copyright(C), 2018, Huawei Tech. Co., Ltd. ALL RIGHTS RESERVED.
//

#include "stdafx.h"
#include "DemoApp.h"
#include "DemoLoginDlg.h"
#include "DemoEventProc.h"
#include "DemoData.h"
#include "service_init.h"
#include "service_callback_to_ui.h"
#include "service_uninit.h"
#include <DbgHelp.h>
/*#include <windows.h>
#include <winuser.h>
#include <VersionHelpers.h>
#include <ShellScalingAPI.h>*/
#include "securec.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

// CDemoApp

BEGIN_MESSAGE_MAP(CDemoApp, CWinApp)
    ON_COMMAND(ID_HELP, &CWinApp::OnHelp)
END_MESSAGE_MAP()


// CDemoApp construction

CDemoApp::CDemoApp()
{
    // support Restart Manager
    m_dwRestartManagerSupportFlags = AFX_RESTART_MANAGER_SUPPORT_RESTART;
    m_pMainDlgWnd = NULL;
    m_pLoginDlgWnd = NULL;
    /*m_pRunInfoDlg = NULL;*/
}


// The one and only CDemoApp object
CDemoApp theApp;


//����DUMP�ļ�
int GenerateMiniDump(HANDLE hFile, PEXCEPTION_POINTERS pExceptionPointers, PWCHAR pwAppName)
{
    BOOL bOwnDumpFile = FALSE;
    HANDLE hDumpFile = hFile;
    MINIDUMP_EXCEPTION_INFORMATION ExpParam;

    typedef BOOL(WINAPI * MiniDumpWriteDumpT)(
        HANDLE,
        DWORD,
        HANDLE,
        MINIDUMP_TYPE,
        PMINIDUMP_EXCEPTION_INFORMATION,
        PMINIDUMP_USER_STREAM_INFORMATION,
        PMINIDUMP_CALLBACK_INFORMATION
        );

    MiniDumpWriteDumpT pfnMiniDumpWriteDump = NULL;
    HMODULE hDbgHelp = LoadLibrary(L"DbgHelp.dll");
    if (hDbgHelp)
        pfnMiniDumpWriteDump = (MiniDumpWriteDumpT)GetProcAddress(hDbgHelp, "MiniDumpWriteDump");

    if (pfnMiniDumpWriteDump)
    {
        if (hDumpFile == NULL || hDumpFile == INVALID_HANDLE_VALUE)
        {
            TCHAR szPath[MAX_PATH] = { 0 };
            TCHAR szFileName[MAX_PATH] = { 0 };
            TCHAR* szAppName = pwAppName;
            TCHAR dwBufferSize = MAX_PATH;
            SYSTEMTIME stLocalTime;

            CString appPath;
            appPath = CTools::getCurrentPath();

            _snwprintf_s(szPath, MAX_PATH, L"%s\\%s", appPath.GetBuffer(MAX_PATH), L"CrashDump");
            appPath.ReleaseBuffer();
            CreateDirectory(szPath, NULL);

            GetLocalTime(&stLocalTime);
            _snwprintf_s(szFileName, MAX_PATH, L"%s\\%s_%04d%02d%02d%02d%02d%02d.dmp", szPath, pwAppName,
                stLocalTime.wYear, stLocalTime.wMonth, stLocalTime.wDay,
                stLocalTime.wHour, stLocalTime.wMinute, stLocalTime.wSecond);

            hDumpFile = CreateFile(szFileName, GENERIC_READ | GENERIC_WRITE,
                FILE_SHARE_WRITE | FILE_SHARE_READ, 0, CREATE_ALWAYS, 0, 0);

            bOwnDumpFile = TRUE;
            OutputDebugString(szFileName);
        }

        if (hDumpFile != INVALID_HANDLE_VALUE)
        {
            ExpParam.ThreadId = GetCurrentThreadId();
            ExpParam.ExceptionPointers = pExceptionPointers;
            ExpParam.ClientPointers = FALSE;

            pfnMiniDumpWriteDump(GetCurrentProcess(), GetCurrentProcessId(),
                hDumpFile, MiniDumpWithDataSegs, (pExceptionPointers ? &ExpParam : NULL), NULL, NULL);

            if (bOwnDumpFile)
                CloseHandle(hDumpFile);
        }
    }

    if (hDbgHelp != NULL)
        FreeLibrary(hDbgHelp);

    return EXCEPTION_EXECUTE_HANDLER;
}


LONG WINAPI ExceptionFilter(LPEXCEPTION_POINTERS lpExceptionInfo)
{
    if (IsDebuggerPresent())
    {
        return EXCEPTION_CONTINUE_SEARCH;
    }
    return GenerateMiniDump(NULL, lpExceptionInfo, L"SDK_Demo");
}

// CDemoApp initialization
BOOL CDemoApp::InitInstance()
{
    //�������dump�ļ�����
    //SetUnhandledExceptionFilter(ExceptionFilter);

    // InitCommonControlsEx() is required on Windows XP if an application
    // manifest specifies use of ComCtl32.dll version 6 or later to enable
    // visual styles.  Otherwise, any window creation will fail.
    INITCOMMONCONTROLSEX InitCtrls;
    InitCtrls.dwSize = sizeof(InitCtrls);
    // Set this to include all the common control classes you want to use
    // in your application.
    InitCtrls.dwICC = ICC_WIN95_CLASSES;
    InitCommonControlsEx(&InitCtrls);

    (void)CWinApp::InitInstance();

    if (!AfxSocketInit())
    {
        AfxMessageBox(IDP_SOCKETS_INIT_FAILED);
        return FALSE;
    }

    // Initialize OLE libraries
    if (!AfxOleInit())
    {
        AfxMessageBox(IDP_OLE_INIT_FAILED);
        return FALSE;
    }

    // Init gdi+
    GdiplusStartupInput m_gdiplusStartupInput;
    ULONG_PTR m_pGdiToken;
    GdiplusStartup(&m_pGdiToken, &m_gdiplusStartupInput, NULL);

    AfxEnableControlContainer();

    // Create the shell manager, in case the dialog contains
    // any shell tree view or shell list view controls.
    CShellManager *pShellManager = new CShellManager;

    // Activate "Windows Native" visual manager for enabling themes in MFC controls
    CMFCVisualManager::SetDefaultManager(RUNTIME_CLASS(CMFCVisualManagerWindows));

    // Standard initialization
    // If you are not using these features and wish to reduce the size
    // of your final executable, you should remove from the following
    // the specific initialization routines you do not need
    // Change the registry key under which our settings are stored
    // TODO: You should modify this string to be something appropriate
    // such as the name of your company or organization
    SetRegistryKey(_T("Local AppWizard-Generated Applications"));

    // Set Config Param
    CString cstrIsIdoConfControl;
    CTools::GetIniConfigParam(_T("IDOConfig"), _T("IdoConfControl"), cstrIsIdoConfControl);
    if (_T("") == cstrIsIdoConfControl)
    {
        CTools::WriteIniConfigParam(_T("IDOConfig"), _T("IdoConfControl"), _T("1"));
    }

    CTools::GetIniConfigParam(_T("IDOConfig"), _T("IdoConfControl"), cstrIsIdoConfControl);
    if (_T("1") == cstrIsIdoConfControl)
    {
        service_set_config_param(TRUE);
    }
    else
    {
        service_set_config_param(FALSE);
    }

    // Set IsUseUiPlugin
    CString cstrIsUseUiPlugin;
    CTools::GetIniConfigParam(_T("UIPluginConfig"), _T("UseUiPlugin"), cstrIsUseUiPlugin);
    if (_T("") == cstrIsUseUiPlugin)
    {
        CTools::WriteIniConfigParam(_T("UIPluginConfig"), _T("UseUiPlugin"), _T("1"));
    }

    CTools::GetIniConfigParam(_T("UIPluginConfig"), _T("UseUiPlugin"), cstrIsUseUiPlugin);
    if (_T("1") == cstrIsUseUiPlugin)
    {
        service_set_ui_plugin_value(1);
    }
    else
    {
        service_set_ui_plugin_value(0);
    }
    
    // Set tlsParam
    SetTlsParam();

    // Init All Module
    if (RESULT_SUCCESS != ServiceInitAllModule())
    {
        AfxMessageBox(_T("Init All Module failed"));
    }

    //// Get history config info
 //   if (m_pRunInfoDlg == NULL)
 //   {
 //       m_pRunInfoDlg = new CDemoRunInfoDlg();
 //       m_pRunInfoDlg->Create(CDemoRunInfoDlg::IDD);
 //   }
 //   m_pRunInfoDlg->ShowWindow(SW_SHOW);


    ///���ûص�����//////
    service_register_login_callback(NotifyCallBack::loginMsgNotify);
    service_register_call_callback(NotifyCallBack::callMsgNotify);
    service_register_conf_callback(NotifyCallBack::confMsgNotify);
    service_register_ldap_frontstage_callback(NotifyCallBack::ldapFrontstageMsgNotify);

    if (1 == service_is_use_ui_plugin())
    {
        //������Ƶ����
        service_register_ui_plugin_callback(NotifyCallBack::uiPluginMsgNotify);
    }

    CString ParaStr = this->m_lpCmdLine;
    TSDK_S_CONF_ANONYMOUS_JOIN_PARAM anonymousJoinConfParam = {0};
    if (ParaStr.GetLength() > 0)
    {
        CString Seperator = _T("?&");
        int Position = 0;
        CString Token;
        Token = ParaStr.Tokenize(Seperator,Position);
        map <CString,CString> Paras;

        while(!Token.IsEmpty())
        {
            int index = Token.Find(_T("="));
            if (0 <= index)
            {
                Paras[Token.Left(index)]=Token.Mid(index+1);
            }
            Token = ParaStr.Tokenize(Seperator, Position);
        }

        //��������������������ʾ����ip������demo��Ҫ�������û�����
        char HostName[100] = {0};
        gethostname(HostName, sizeof(HostName));// ��ñ���������.
        hostent* hn;
        hn = gethostbyname(HostName);//���ݱ����������õ�����ip

        strncpy_s(anonymousJoinConfParam.display_name, TSDK_D_MAX_DISPLAY_NAME_LEN + 1, inet_ntoa(*(struct in_addr *)hn->h_addr_list[0]), _TRUNCATE);

        anonymousJoinConfParam.auth_type = TSDK_E_CONF_ANONYMOUS_AUTH_RANDOM;
        CTools::CString2Char(Paras[_T("site_url")], anonymousJoinConfParam.server_addr, TSDK_D_MAX_URL_LENGTH);
        CTools::CString2Char(Paras[_T("random")], anonymousJoinConfParam.random, TSDK_D_MAX_NUMBER_LEN);

        (void)service_join_conference_by_anonymous(&anonymousJoinConfParam);
    }

    //�������ݻ��鷢�����ݽӿ�
    service_set_send_data_config_param(true);

    for (;;)
    {
        CDemoLoginDlg  LoginDlg;
        m_pLoginDlgWnd = &LoginDlg;
        INT_PTR mRet = LoginDlg.DoModal();
        if (mRet == IDCANCEL)
        {
            break;
        }
        bool bRet = LoginDlg.GetLoginFlag();

        CDemoMainDlg mainDlg;
        if (bRet)
        {
            m_pMainDlgWnd = &mainDlg;
            INT_PTR nResponse = mainDlg.DoModal();
            if (nResponse == IDOK)
            {
                continue;
            }
            else if (nResponse == IDCANCEL)
            {
                break;
            }
            else if (nResponse == -1)
            {
                TRACE(traceAppMsg, 0, "Warning: dialog creation failed, so application is terminating unexpectedly.\n");
                TRACE(traceAppMsg, 0, "Warning: if you are using MFC controls on the dialog, you cannot #define _AFX_NO_MFC_CONTROLS_IN_DIALOGS.\n");
            }
        }
    }

    //// Get history config info
    //if (m_pRunInfoDlg == NULL)
    //{
    //    m_pRunInfoDlg = new CDemoRunInfoDlg();
    //    m_pRunInfoDlg->Create(CDemoRunInfoDlg::IDD);
    //}
    //m_pRunInfoDlg->ShowWindow(SW_SHOW);

    // Delete the shell manager created above.
    if (pShellManager != NULL)
    {
        delete pShellManager;
    }

    //ж��gdi+
    GdiplusShutdown(m_pGdiToken);

    // Since the dialog has been closed, return FALSE so that we exit the
    //  application, rather than start the application's message pump.
    return FALSE;
}

int CDemoApp::ExitInstance()
{
    AfxOleTerm(FALSE);

    //ȥ��ʼ��
    int ret;
    ret = ServiceUninitAllModule();
    if (RESULT_SUCCESS != ret)
    {
        AfxMessageBox(_T("uninit failed"));
    }

    ////����RunInfoDlg
    //if (m_pRunInfoDlg)
    //{
    //    m_pRunInfoDlg->OnClose();
    //    SAFE_DELETE(m_pRunInfoDlg);
    //}

    return CWinApp::ExitInstance();
}

void CDemoApp::SetTlsParam()
{
    // Set tlsParam
    TSDK_S_TLS_PARAM  tls_param;
    CString strCaCertPath;
    CString strClientCertPath;
    CString strclientKeyPath;
    CString strclientPriKeyPwd;
    CString strVerifyMode;
    CString strVerifyServerMode;
    CString strTlsVersion;
    memset_s(&tls_param, sizeof(tls_param), 0, sizeof(tls_param));

    CTools::GetIniConfigParam(_T("TlsParamConfig"), _T("caCertPath"), strCaCertPath);
    CTools::GetIniConfigParam(_T("TlsParamConfig"), _T("clientCertPath"), strClientCertPath);
    CTools::GetIniConfigParam(_T("TlsParamConfig"), _T("clientKeyPath"), strclientKeyPath);
    CTools::GetIniConfigParam(_T("TlsParamConfig"), _T("clientPriKeyPwd"), strclientPriKeyPwd);
    CTools::GetIniConfigParam(_T("TlsParamConfig"), _T("verifyMode"), strVerifyMode);
    CTools::GetIniConfigParam(_T("TlsParamConfig"), _T("verifyServerMode"), strVerifyServerMode);
    CTools::GetIniConfigParam(_T("TlsParamConfig"), _T("tlsVersion"), strTlsVersion);

    CTools::CString2Char(strCaCertPath, tls_param.ca_cert_path, TSDK_D_MAX_CA_PATH_LEN);
    CTools::CString2Char(strClientCertPath, tls_param.client_cert_path, TSDK_D_MAX_CA_PATH_LEN);
    CTools::CString2Char(strclientKeyPath, tls_param.client_key_path, TSDK_D_MAX_CA_PATH_LEN);
    CTools::CString2Char(strclientPriKeyPwd, tls_param.client_privkey_pwd, TSDK_D_MAX_PASSWORD_LENGTH);
    tls_param.verify_mode = (TSDK_E_VERIFY_MODE)CTools::str2num(CTools::UNICODE2UTF(strVerifyMode));
    tls_param.verify_server_mode = (TSDK_E_VERIFY_SERVER_MODE)CTools::str2num(CTools::UNICODE2UTF(strVerifyServerMode));
    tls_param.tls_version = (TSDK_INT32)CTools::str2num(CTools::UNICODE2UTF(strTlsVersion));

    if (_T("") != strCaCertPath)
    {
        service_set_tls_param(&tls_param);
    }
}
