//
//  DemoEventProc.cpp
//  EC_SDK_DEMO
//
//  Created by EC Open support team.
//  Copyright(C), 2018, Huawei Tech. Co., Ltd. ALL RIGHTS RESERVED.
//

#include "stdafx.h"
#include <string>
#include "DemoEventProc.h"
#include "DemoApp.h"
#include "DemoMainDlg.h"
#include "DemoLoginDlg.h"
#include "DemoCallCtrlDlg.h"
#include "DemoCallInCommingDlg.h"
#include "DemoShare.h"
#include "DemoData.h"
#include "DemoCallDlgManager.h"
#include "DemoPromptDlg.h"
#include "service_tools.h"
#include "service_os_adapt.h"
#include "service_init.h"
#include "service_conf_handle_global.h"

extern bool g_bIsJoinConf;
extern bool g_isQueryConfList;
extern CString g_sipNumber;
int  g_JoinConfCallId;

CString share_number;

NotifyCallBack::NotifyCallBack(void)
{
}

NotifyCallBack::~NotifyCallBack(void)
{
}

void NotifyCallBack::loginMsgNotify(unsigned int msg_id, unsigned int param1, unsigned int param2, void*  data)
{
    CDemoApp* app = (CDemoApp*)AfxGetApp();
    if (!app)
    {
        //�����Ѿ��ر�
        return;
    }
    CDemoLoginDlg* logindlg = (CDemoLoginDlg*)(app->m_pLoginDlgWnd);
    CHECK_POINTER(logindlg);

    switch (msg_id)
    {
    case TSDK_E_LOGIN_EVT_AUTH_FAILED:
    {
        ::PostMessage(logindlg->GetSafeHwnd(), WM_LOGIN_AUTH_RESULT, NULL, NULL);
        break;
    }
    case TSDK_E_LOGIN_EVT_LOGIN_SUCCESS:
    {
        ::PostMessage(logindlg->GetSafeHwnd(), WM_LOGIN_RESULT, (WPARAM)TRUE, (LPARAM)param2);
        break;
    }
    case TSDK_E_LOGIN_EVT_LOGIN_FAILED:
    {
        ::PostMessage(logindlg->GetSafeHwnd(), WM_LOGIN_RESULT, (WPARAM)FALSE, NULL);
        break;
    }
    case TSDK_E_LOGIN_EVT_AUTH_REFRESH_FAILED:
    {
        ::PostMessage(logindlg->GetSafeHwnd(), WM_LOGIN_TOKEN_REFRESH_FAILED, NULL, NULL);
        break;
    }
    case TSDK_E_LOGIN_EVT_LOGOUT_SUCCESS:
    {
        CDemoMainDlg* maindlg = (CDemoMainDlg*)(app->m_pMainDlgWnd);
        CHECK_POINTER(maindlg);
        ::PostMessage(maindlg->GetSafeHwnd(), WM_LOGOUT_RESULT, NULL, NULL);
        break;
    }
    case TSDK_E_LOGIN_EVT_FORCE_LOGOUT:
    {
        CDemoMainDlg* maindlg = (CDemoMainDlg*)(app->m_pMainDlgWnd);
        CHECK_POINTER(maindlg);
        ::PostMessage(maindlg->GetSafeHwnd(), WM_FORCE_LOGOUT, NULL, NULL);
        break;
    }
    case TSDK_E_LOGIN_EVT_VOIP_ACCOUNT_STATUS:
    {
        CHECK_POINTER(data);
        TSDK_S_VOIP_ACCOUNT_INFO* selfInfo = (TSDK_S_VOIP_ACCOUNT_INFO*)data;
        TSDK_S_VOIP_ACCOUNT_INFO* notifyInfo = new TSDK_S_VOIP_ACCOUNT_INFO;
        service_memset_s(notifyInfo, sizeof(TSDK_S_VOIP_ACCOUNT_INFO), 0, sizeof(TSDK_S_VOIP_ACCOUNT_INFO));
        memcpy_s(notifyInfo, sizeof(TSDK_S_VOIP_ACCOUNT_INFO), selfInfo, sizeof(TSDK_S_VOIP_ACCOUNT_INFO));
        ::PostMessage(logindlg->GetSafeHwnd(), WM_AUTH_LOGIN_SAVE_SELF_INFO, (WPARAM)notifyInfo, NULL);
        break;
    }
    case TSDK_E_LOGIN_EVT_GET_TEMP_USER_RESULT:
    {
        CHECK_POINTER(data);
        TSDK_CHAR* notifyInfo = (TSDK_CHAR*)data;
        ::PostMessage(logindlg->GetSafeHwnd(), WM_LOGIN_GET_TEMP_USER_RESULT, (WPARAM)notifyInfo, NULL);
        break;
    }
    default:
        break;
    }
}


void NotifyCallBack::callMsgNotify(unsigned int msg_id, unsigned int param1, unsigned int param2, void* data)
{
    CDemoApp* app = (CDemoApp*)AfxGetApp();
    if (!app)
    {
        //�����Ѿ��ر�
        return;
    }

    CDemoMainDlg* maindlg = (CDemoMainDlg*)(app->m_pMainDlgWnd);
    CHECK_POINTER(maindlg);

    switch (msg_id)
    {
    case TSDK_E_CALL_EVT_CALL_INCOMING:
    {
        CHECK_POINTER(data);
        TSDK_S_CALL_INFO* callInfo = (TSDK_S_CALL_INFO*)data;
        TSDK_S_CALL_INFO* notifyInfo = new TSDK_S_CALL_INFO;
        service_memset_s(notifyInfo, sizeof(TSDK_S_CALL_INFO), 0, sizeof(TSDK_S_CALL_INFO));
        memcpy_s(notifyInfo, sizeof(TSDK_S_CALL_INFO), callInfo, sizeof(TSDK_S_CALL_INFO));

        ::PostMessage(maindlg->GetSafeHwnd(), WM_CALL_INCOMMING, (WPARAM)notifyInfo, NULL);
        break;
    }
    case TSDK_E_CALL_EVT_CALL_OUTGOING:
    {
        CHECK_POINTER(data);
        TSDK_S_CALL_INFO* callInfo = (TSDK_S_CALL_INFO*)data;
        TSDK_S_CALL_INFO* notifyInfo = new TSDK_S_CALL_INFO;
        service_memset_s(notifyInfo, sizeof(TSDK_S_CALL_INFO), 0, sizeof(TSDK_S_CALL_INFO));
        memcpy_s(notifyInfo, sizeof(TSDK_S_CALL_INFO), callInfo, sizeof(TSDK_S_CALL_INFO));

        ::PostMessage(maindlg->GetSafeHwnd(), WM_CALL_STARTCALL, WPARAM(notifyInfo), NULL);
        break;
    }
    case TSDK_E_CALL_EVT_CALL_CONNECTED:
    {
        CHECK_POINTER(data);
        TSDK_S_CALL_INFO* callInfo = (TSDK_S_CALL_INFO*)data;
        TSDK_S_CALL_INFO* notifyInfo = new TSDK_S_CALL_INFO;
        service_memset_s(notifyInfo, sizeof(TSDK_S_CALL_INFO), 0, sizeof(TSDK_S_CALL_INFO));
        memcpy_s(notifyInfo, sizeof(TSDK_S_CALL_INFO), callInfo, sizeof(TSDK_S_CALL_INFO));

        CDemoCallCtrlDlg* pCallDlg;
        pCallDlg = CallDlgManager::GetInstance().GetCallDlgByCallID(notifyInfo->call_id);
        CHECK_POINTER(pCallDlg);
        ::PostMessage(pCallDlg->GetSafeHwnd(), WM_CALL_CONNECTED, (WPARAM)notifyInfo, NULL);
        break;
    }
    case TSDK_E_CALL_EVT_CALL_ENDED:
        /*case TSDK_E_CALL_EVT_CALL_DESTROY:*/
    {
        CHECK_POINTER(data);
        TSDK_S_CALL_INFO* callInfo = (TSDK_S_CALL_INFO*)data;
        TSDK_S_CALL_INFO* notifyInfo = new TSDK_S_CALL_INFO;
        service_memset_s(notifyInfo, sizeof(TSDK_S_CALL_INFO), 0, sizeof(TSDK_S_CALL_INFO));
        memcpy_s(notifyInfo, sizeof(TSDK_S_CALL_INFO), callInfo, sizeof(TSDK_S_CALL_INFO));

        if (g_JoinConfCallId == callInfo->call_id)
        {
            g_bIsJoinConf = false;
            g_JoinConfCallId = 0;
        }

        ::PostMessage(maindlg->GetSafeHwnd(), WM_CALL_END, (WPARAM)notifyInfo, NULL);
        break;
    }
    case TSDK_E_CALL_EVT_OPEN_VIDEO_REQ:
    {
        ::PostMessage(maindlg->GetSafeHwnd(), WM_CALL_ADD_VIDEO, (WPARAM)param1, NULL);
        break;
    }
    case TSDK_E_CALL_EVT_OPEN_VIDEO_IND:
    {
        ::PostMessage(maindlg->GetSafeHwnd(), WM_CALL_OPEN_VIDEO, (WPARAM)param1, NULL);
        break;
    }
    case TSDK_E_CALL_EVT_CLOSE_VIDEO_IND:
    {
        ::PostMessage(maindlg->GetSafeHwnd(), WM_CALL_CLOSE_VIDEO, (WPARAM)param1, NULL);
        break;
    }
    case TSDK_E_CALL_EVT_REFUSE_OPEN_VIDEO_IND:
    {
        ::PostMessage(maindlg->GetSafeHwnd(), WM_CALL_REFUSE_OPEN_VIDEO, (WPARAM)param1, NULL);
        break;
    }
    case TSDK_E_CALL_EVT_HOLD_SUCCESS:
    {
        CHECK_POINTER(data);
        TSDK_S_CALL_INFO* callInfo = (TSDK_S_CALL_INFO*)data;
        TSDK_S_CALL_INFO* notifyInfo = new TSDK_S_CALL_INFO;
        service_memset_s(notifyInfo, sizeof(TSDK_S_CALL_INFO), 0, sizeof(TSDK_S_CALL_INFO));
        memcpy_s(notifyInfo, sizeof(TSDK_S_CALL_INFO), callInfo, sizeof(TSDK_S_CALL_INFO));

        CDemoCallCtrlDlg* pCallDlg;
        pCallDlg = CallDlgManager::GetInstance().GetCallDlgByCallID(notifyInfo->call_id);
        CHECK_POINTER(pCallDlg);
        ::PostMessage(pCallDlg->GetSafeHwnd(), WM_CALL_HOLD_SUCESS, NULL, NULL);
        break;
    }
    case TSDK_E_CALL_EVT_UNHOLD_SUCCESS:
    {
        CHECK_POINTER(data);
        TSDK_S_CALL_INFO* callInfo = (TSDK_S_CALL_INFO*)data;
        TSDK_S_CALL_INFO* notifyInfo = new TSDK_S_CALL_INFO;
        service_memset_s(notifyInfo, sizeof(TSDK_S_CALL_INFO), 0, sizeof(TSDK_S_CALL_INFO));
        memcpy_s(notifyInfo, sizeof(TSDK_S_CALL_INFO), callInfo, sizeof(TSDK_S_CALL_INFO));

        CDemoCallCtrlDlg* pCallDlg;
        pCallDlg = CallDlgManager::GetInstance().GetCallDlgByCallID(notifyInfo->call_id);
        CHECK_POINTER(pCallDlg);
        ::PostMessage(pCallDlg->GetSafeHwnd(), WM_CALL_UNHOLD_SUCESS, NULL, NULL);
        break;
    }
    case TSDK_E_CALL_EVT_STATISTIC_LOCAL_QOS://UI�ݲ�����
    {
        break;
    }
    case TSDK_E_CALL_EVT_BLD_TRANSFER_FAILED:
    {
        CHECK_POINTER(data);
        TSDK_S_CALL_INFO* callInfo = (TSDK_S_CALL_INFO*)data;
        CDemoCallCtrlDlg* pCallDlg;
        pCallDlg = CallDlgManager::GetInstance().GetCallDlgByCallID(callInfo->call_id);
        CHECK_POINTER(pCallDlg);
        ::PostMessage(pCallDlg->GetSafeHwnd(), WM_CALL_BLD_TRANSFER_FAILED, NULL, NULL);
        break;
    }
    default:
        break;
    }
}


void NotifyCallBack::confMsgNotify(unsigned int msg_id, unsigned int param1, unsigned int param2, void* data)
{
    CDemoApp* app = (CDemoApp*)AfxGetApp();
    if (!app)
    {
        //�����Ѿ��ر�
        return;
    }

    CDemoMainDlg* maindlg = (CDemoMainDlg*)(app->m_pMainDlgWnd);
    CHECK_POINTER(maindlg);

    switch (msg_id)
    {
    case TSDK_E_CONF_EVT_BOOK_CONF_RESULT:
    {
        if (TSDK_SUCCESS == param1)
        {
            CTools::ShowMessageTimeout(_T("Book conference success."), 2000);
        }
        else
        {
            CTools::ShowMessageTimeout(_T("Book conference failed."), 2000);
        }
        break;
    }
    case TSDK_E_CONF_EVT_QUERY_CONF_LIST_RESULT:
    {
        if (false == g_isQueryConfList)
        {
            return;
        }

        if (TSDK_SUCCESS == param1)
        {
            CHECK_POINTER(data);
            TSDK_S_CONF_LIST_INFO* pResult = (TSDK_S_CONF_LIST_INFO*)data;
            TSDK_UINT32 currentConfNum = pResult->current_count;
            if (currentConfNum > 0)
            {
                TSDK_S_CONF_BASE_INFO* notifyInfo = nullptr;
                try
                {
                    notifyInfo = new TSDK_S_CONF_BASE_INFO[currentConfNum];
                }
                catch (const bad_alloc& e)
                {
                    return;
                }

                CHECK_POINTER(notifyInfo);
                service_memset_s(notifyInfo, sizeof(TSDK_S_CONF_BASE_INFO)*currentConfNum, 0, sizeof(TSDK_S_CONF_BASE_INFO)*currentConfNum);
                for (unsigned int i = 0; i < currentConfNum; i++)
                {
                    notifyInfo[i].size = pResult->conf_info_list[i].size;
                    strncpy_s(notifyInfo[i].conf_id, TSDK_D_MAX_CONF_ID_LEN + 1, pResult->conf_info_list[i].conf_id, _TRUNCATE);
                    strncpy_s(notifyInfo[i].subject, TSDK_D_MAX_SUBJECT_LEN + 1, pResult->conf_info_list[i].subject, _TRUNCATE);
                    strncpy_s(notifyInfo[i].access_number, TSDK_D_MAX_CONF_ACCESS_LEN + 1, pResult->conf_info_list[i].access_number, _TRUNCATE);
                    strncpy_s(notifyInfo[i].chairman_pwd, TSDK_D_MAX_CONF_PASSWORD_LEN + 1, pResult->conf_info_list[i].chairman_pwd, _TRUNCATE);
                    strncpy_s(notifyInfo[i].guest_pwd, TSDK_D_MAX_CONF_PASSWORD_LEN + 1, pResult->conf_info_list[i].guest_pwd, _TRUNCATE);
                    strncpy_s(notifyInfo[i].start_time, TSDK_D_MAX_TIME_FORMATE_LEN + 1, pResult->conf_info_list[i].start_time, _TRUNCATE);
                    strncpy_s(notifyInfo[i].end_time, TSDK_D_MAX_TIME_FORMATE_LEN + 1, pResult->conf_info_list[i].end_time, _TRUNCATE);
                    notifyInfo[i].conf_media_type = pResult->conf_info_list[i].conf_media_type;
                    notifyInfo[i].conf_state = (TSDK_E_CONF_STATE)pResult->conf_info_list[i].conf_state;
                    strncpy_s(notifyInfo[i].scheduser_account, TSDK_D_MAX_ACCOUNT_LEN + 1, pResult->conf_info_list[i].scheduser_account, _TRUNCATE);
                    strncpy_s(notifyInfo[i].scheduser_name, TSDK_D_MAX_DISPLAY_NAME_LEN + 1, pResult->conf_info_list[i].scheduser_name, _TRUNCATE);
                }

                CDemoMeetingDlg* mettingDlg = maindlg->GetDemoMeetingDlg();
                CHECK_POINTER(mettingDlg);
                ::PostMessage(mettingDlg->GetSafeHwnd(), WM_CONF_CTRL_GET_CONF_LIST_RESULT, (WPARAM)notifyInfo, (LPARAM)currentConfNum);
            }
        }
        else
        {
            maindlg->MessageBox(_T("get conf list failed!"));
        }
        g_isQueryConfList = false;
        break;
    }
    case TSDK_E_CONF_EVT_JOIN_CONF_RESULT:
    {
        if (TSDK_SUCCESS == param2)
        {
            CHECK_POINTER(data);
            TSDK_S_JOIN_CONF_IND_INFO* pResult = (TSDK_S_JOIN_CONF_IND_INFO*)data;
            TSDK_S_JOIN_CONF_IND_INFO* notifyInfo = new TSDK_S_JOIN_CONF_IND_INFO;
            service_memset_s(notifyInfo, sizeof(TSDK_S_JOIN_CONF_IND_INFO), 0, sizeof(TSDK_S_JOIN_CONF_IND_INFO));
            memcpy_s(notifyInfo, sizeof(TSDK_S_JOIN_CONF_IND_INFO), pResult, sizeof(TSDK_S_JOIN_CONF_IND_INFO));
            ::PostMessage(maindlg->GetSafeHwnd(), WM_CONF_CTRL_JOIN_RESULT, (WPARAM)notifyInfo, (LPARAM)param1);

            g_bIsJoinConf = true;
            g_JoinConfCallId = pResult->call_id;

        }
        else
        {
            maindlg->MessageBox(_T("join conf failed!"));
        }
        break;
    }
    case TSDK_E_CONF_EVT_INFO_AND_STATUS_UPDATE:
    {
        CHECK_POINTER(data);
        TSDK_S_CONF_STATUS_INFO* pResult = (TSDK_S_CONF_STATUS_INFO*)data;
        TSDK_S_CONF_STATUS_INFO* notifyInfo = new TSDK_S_CONF_STATUS_INFO;
        service_memset_s(notifyInfo, sizeof(TSDK_S_CONF_STATUS_INFO), 0, sizeof(TSDK_S_CONF_STATUS_INFO));
        memcpy_s(notifyInfo, sizeof(TSDK_S_CONF_STATUS_INFO), pResult, sizeof(TSDK_S_CONF_STATUS_INFO));

        unsigned int attendeenumber = pResult->attendee_num;
        if (0 == attendeenumber)
        {
            return;
        }
        notifyInfo->attendee_list = NULL;
        notifyInfo->attendee_list = (TSDK_S_ATTENDEE*)malloc(attendeenumber * sizeof(TSDK_S_ATTENDEE));
        if (NULL == notifyInfo->attendee_list)
        {
            return;
        }
        (void)service_memset_s(notifyInfo->attendee_list, attendeenumber * sizeof(TSDK_S_ATTENDEE), 0, attendeenumber * sizeof(TSDK_S_ATTENDEE));
        TSDK_S_ATTENDEE* pTempAttendee = notifyInfo->attendee_list;
        for (unsigned int i = 0; i < attendeenumber; i++)
        {
            if (pTempAttendee)
            {
                (void)strncpy_s(pTempAttendee->status_info.participant_id, TSDK_D_MAX_PARTICIPANTID_LEN + 1, pResult->attendee_list[i].status_info.participant_id, _TRUNCATE);
                (void)strncpy_s(pTempAttendee->base_info.number, TSDK_D_MAX_NUMBER_LEN + 1, pResult->attendee_list[i].base_info.number, _TRUNCATE);
                (void)strncpy_s(pTempAttendee->base_info.display_name, TSDK_D_MAX_DISPLAY_NAME_LEN + 1, pResult->attendee_list[i].base_info.display_name, _TRUNCATE);
                (void)strncpy_s(pTempAttendee->base_info.account_id, TSDK_D_MAX_ACCOUNT_LEN + 1, pResult->attendee_list[i].base_info.account_id, _TRUNCATE);
                (void)strncpy_s(pTempAttendee->base_info.email, TSDK_D_MAX_EMAIL_LEN + 1, pResult->attendee_list[i].base_info.email, _TRUNCATE);
                (void)strncpy_s(pTempAttendee->base_info.sms, TSDK_D_MAX_NUMBER_LEN + 1, pResult->attendee_list[i].base_info.sms, _TRUNCATE);

                pTempAttendee->base_info.role = (TSDK_E_CONF_ROLE)pResult->attendee_list[i].base_info.role;
                pTempAttendee->status_info.data_user_id = pResult->attendee_list[i].status_info.data_user_id;
                pTempAttendee->status_info.has_camera = pResult->attendee_list[i].status_info.has_camera;
                pTempAttendee->status_info.is_broadcast = pResult->attendee_list[i].status_info.is_broadcast;
                pTempAttendee->status_info.is_handup = pResult->attendee_list[i].status_info.is_handup;
                pTempAttendee->status_info.is_join_dataconf = pResult->attendee_list[i].status_info.is_join_dataconf;
                pTempAttendee->status_info.is_mute = pResult->attendee_list[i].status_info.is_mute;
                pTempAttendee->status_info.is_only_in_data_conf = pResult->attendee_list[i].status_info.is_only_in_data_conf;
                pTempAttendee->status_info.is_present = pResult->attendee_list[i].status_info.is_present;
                pTempAttendee->status_info.is_self = pResult->attendee_list[i].status_info.is_self;
                pTempAttendee->status_info.state = (TSDK_E_CONF_PARTICIPANT_STATUS)pResult->attendee_list[i].status_info.state;
                pTempAttendee->status_info.is_req_talk = pResult->attendee_list[i].status_info.is_req_talk;
            }
            else
            {
                break;
            }
            pTempAttendee++;
        }

        CDemoAudioMeetingDlg* pAudioMettingDlg = maindlg->GetDemoAudioMeetingDlg();
        CHECK_POINTER(pAudioMettingDlg);
        ::PostMessage(pAudioMettingDlg->GetSafeHwnd(), WM_CONF_CTRL_INFO_AND_STATUS_UPDATE, (WPARAM)notifyInfo, (LPARAM)param1);

        break;
    }
    case TSDK_E_CONF_EVT_SPEAKER_IND:
    {
        CHECK_POINTER(data);
        TSDK_S_CONF_SPEAKER_INFO* pResult = (TSDK_S_CONF_SPEAKER_INFO*)data;
        TSDK_S_CONF_SPEAKER_INFO* notifyInfo = new TSDK_S_CONF_SPEAKER_INFO;
        service_memset_s(notifyInfo, sizeof(TSDK_S_CONF_SPEAKER_INFO), 0, sizeof(TSDK_S_CONF_SPEAKER_INFO));
        memcpy_s(notifyInfo, sizeof(TSDK_S_CONF_SPEAKER_INFO), pResult, sizeof(TSDK_S_CONF_SPEAKER_INFO));

        CDemoAudioMeetingDlg* pAudioMettingDlg = maindlg->GetDemoAudioMeetingDlg();
        CHECK_POINTER(pAudioMettingDlg);
        ::PostMessage(pAudioMettingDlg->GetSafeHwnd(), WM_CONF_CTRL_ADDRESSER_UPDATE_IND, (WPARAM)notifyInfo, NULL);

        break;
    }
    case TSDK_E_CONF_EVT_QUERY_CONF_DETAIL_RESULT:
    {
        if (TSDK_SUCCESS == param1)
        {
            CHECK_POINTER(data);
            TSDK_S_CONF_DETAIL_INFO* pResult = (TSDK_S_CONF_DETAIL_INFO*)data;
            TSDK_S_CONF_DETAIL_INFO* notifyInfo = new TSDK_S_CONF_DETAIL_INFO;
            service_memset_s(notifyInfo, sizeof(TSDK_S_CONF_DETAIL_INFO), 0, sizeof(TSDK_S_CONF_DETAIL_INFO));
            memcpy_s(notifyInfo, sizeof(TSDK_S_CONF_DETAIL_INFO), pResult, sizeof(TSDK_S_CONF_DETAIL_INFO));
            CDemoMeetingDlg* mettingDlg = maindlg->GetDemoMeetingDlg();
            CHECK_POINTER(mettingDlg);
            ::PostMessage(mettingDlg->GetSafeHwnd(), WM_CONF_CTRL_GET_CONF_INFO_RESULT, (WPARAM)notifyInfo, NULL);
        }
        else
        {
            maindlg->MessageBox(_T("get conf detail failed!"));
        }
        break;
    }
    case TSDK_E_CONF_EVT_CONFCTRL_OPERATION_RESULT:
    {
        CHECK_POINTER(data);
        TSDK_S_CONF_OPERATION_RESULT* pResult = (TSDK_S_CONF_OPERATION_RESULT*)data;
        TSDK_S_CONF_OPERATION_RESULT* notifyInfo = new TSDK_S_CONF_OPERATION_RESULT;
        service_memset_s(notifyInfo, sizeof(TSDK_S_CONF_OPERATION_RESULT), 0, sizeof(TSDK_S_CONF_OPERATION_RESULT));
        memcpy_s(notifyInfo, sizeof(TSDK_S_CONF_OPERATION_RESULT), pResult, sizeof(TSDK_S_CONF_OPERATION_RESULT));

        CDemoAudioMeetingDlg* pAudioMettingDlg = maindlg->GetDemoAudioMeetingDlg();
        CHECK_POINTER(pAudioMettingDlg);
        ::PostMessage(pAudioMettingDlg->GetSafeHwnd(), WM_CONF_CTRL_OPERATION_RESULT, (WPARAM)notifyInfo, NULL);

        break;
    }
    case TSDK_E_CONF_EVT_CONF_END_IND:
    {
        ::PostMessage(maindlg->GetSafeHwnd(), WM_CALL_CONF_CLOSE_DLG, NULL, NULL);
        break;
    }
    case TSDK_E_CONF_EVT_CONF_INCOMING_IND:
    {
        CHECK_POINTER(data);
        TSDK_S_CONF_INCOMING_INFO* pResult = (TSDK_S_CONF_INCOMING_INFO*)data;
        TSDK_S_CONF_INCOMING_INFO* notifyInfo = new TSDK_S_CONF_INCOMING_INFO;
        service_memset_s(notifyInfo, sizeof(TSDK_S_CONF_INCOMING_INFO), 0, sizeof(TSDK_S_CONF_INCOMING_INFO));
        memcpy_s(notifyInfo, sizeof(TSDK_S_CONF_INCOMING_INFO), pResult, sizeof(TSDK_S_CONF_INCOMING_INFO));
        ::PostMessage(maindlg->GetSafeHwnd(), WM_CONF_CTRL_CONF_COMMING, (WPARAM)notifyInfo, (LPARAM)param1);
        break;
    }
    case TSDK_E_CONF_EVT_GET_DATACONF_PARAM_RESULT:
    {
        if (TSDK_SUCCESS != param2)
        {
            maindlg->MessageBox(_T("get data conf param failed!"));
        }
        else
        {
            ::PostMessage(maindlg->GetSafeHwnd(), WM_CONF_CTRL_GET_DATA_CONF_PARAM, (WPARAM)param1, NULL);
        }
        break;
    }
    case TSDK_E_CONF_EVT_JOIN_DATA_CONF_RESULT:
    {
        if (0 == service_is_use_ui_plugin())
        {
            ::PostMessage(maindlg->GetSafeHwnd(), WM_CONF_CTRL_JOIN_DATACONF_RESULT, (WPARAM)param1, (LPARAM)param2);
        }
        else
        {
            set_data_conf_handle(param1);
        }
        break;

    }
    case TSDK_E_CONF_EVT_AS_OWNER_CHANGE:
    {
        if (0 == service_is_use_ui_plugin())
        {
            CHECK_POINTER(data);
            CDemoDataconfCtrlDlg* pDataConfCtrlDlg = maindlg->GetDataConfCtrlDlg();
            CHECK_POINTER(pDataConfCtrlDlg);
            ::PostMessage(pDataConfCtrlDlg->GetSafeHwnd(), WM_DATACONF_MODULE_SHARING_SESSION, (WPARAM)param2, (LPARAM)data);
        }
        else
        {
            TSDK_E_CONF_AS_ACTION_TYPE type = (TSDK_E_CONF_AS_ACTION_TYPE)param2;
            TSDK_S_ATTENDEE* share_attendee = (TSDK_S_ATTENDEE*)data;
            if (TSDK_E_CONF_AS_ACTION_ADD == type)
            {
                share_number = share_attendee->base_info.number;
            }
            else if (TSDK_E_CONF_AS_ACTION_DELETE == type)
            {
                share_number = "";
            }
        }
        break;
    }
    case TSDK_E_CONF_EVT_AS_STATE_CHANGE:
    {
        if (0 == service_is_use_ui_plugin())
        {
            CHECK_POINTER(data);
            TSDK_S_CONF_AS_STATE_INFO* pResult = (TSDK_S_CONF_AS_STATE_INFO*)data;
            TSDK_S_CONF_AS_STATE_INFO* notifyInfo = new TSDK_S_CONF_AS_STATE_INFO;
            service_memset_s(notifyInfo, sizeof(TSDK_S_CONF_AS_STATE_INFO), 0, sizeof(TSDK_S_CONF_AS_STATE_INFO));
            memcpy_s(notifyInfo, sizeof(TSDK_S_CONF_AS_STATE_INFO), pResult, sizeof(TSDK_S_CONF_AS_STATE_INFO));

            CDemoDataconfCtrlDlg* pDataConfCtrlDlg = maindlg->GetDataConfCtrlDlg();
            CHECK_POINTER(pDataConfCtrlDlg);
            ::PostMessage(pDataConfCtrlDlg->GetSafeHwnd(), WM_DATACONF_MODULE_SHARING_STATE, (WPARAM)notifyInfo, (LPARAM)param2);
        }

        break;
    }
    case TSDK_E_CONF_EVT_AS_SCREEN_DATA_UPDATE:
    {
        if (0 == service_is_use_ui_plugin())
        {
            CDemoDataconfCtrlDlg* pDataConfCtrlDlg = maindlg->GetDataConfCtrlDlg();
            CHECK_POINTER(pDataConfCtrlDlg);
            ::PostMessage(pDataConfCtrlDlg->GetSafeHwnd(), WM_DATACONF_MODULE_SCREEN_DATA, NULL, NULL);
        }
        break;
    }
    case TSDK_E_CONF_EVT_PRESENTER_GIVE_IND:
    {
        ::PostMessage(maindlg->GetSafeHwnd(), WM_DATACONF_MODULE_PRESENTERCHG, NULL, NULL);
        break;
    }
    case TSDK_E_CONF_EVT_TRANS_TO_CONF_RESULT:
    {
        ::PostMessage(maindlg->GetSafeHwnd(), WM_CALL_TRANS_TO_CONF_RESULT, NULL, (LPARAM)param2);
        break;
    }
    case TSDK_E_CONF_EVT_DS_DOC_LOAD_START:
    {
        CHECK_POINTER(data);
        TSDK_S_DOC_BASE_INFO* pResult = (TSDK_S_DOC_BASE_INFO*)data;
        TSDK_S_DOC_BASE_INFO* notifyInfo = new TSDK_S_DOC_BASE_INFO;
        service_memset_s(notifyInfo, sizeof(TSDK_S_DOC_BASE_INFO), 0, sizeof(TSDK_S_DOC_BASE_INFO));
        memcpy_s(notifyInfo, sizeof(TSDK_S_DOC_BASE_INFO), pResult, sizeof(TSDK_S_DOC_BASE_INFO));

        CDemoDataconfCtrlDlg* pDataConfCtrlDlg = maindlg->GetDataConfCtrlDlg();
        CHECK_POINTER(pDataConfCtrlDlg);
        ::PostMessage(pDataConfCtrlDlg->GetSafeHwnd(), WM_DATACONF_MODULE_DS_NEW, (WPARAM)notifyInfo, (LPARAM)param2);
        break;
    }
    case TSDK_E_CONF_EVT_DS_DOC_PAGE_LOADED:
    {
        CHECK_POINTER(data);
        TSDK_S_DOC_PAGE_BASE_INFO* pResult = (TSDK_S_DOC_PAGE_BASE_INFO*)data;
        TSDK_S_DOC_PAGE_BASE_INFO* notifyInfo = new TSDK_S_DOC_PAGE_BASE_INFO;
        service_memset_s(notifyInfo, sizeof(TSDK_S_DOC_PAGE_BASE_INFO), 0, sizeof(TSDK_S_DOC_PAGE_BASE_INFO));
        memcpy_s(notifyInfo, sizeof(TSDK_S_DOC_PAGE_BASE_INFO), pResult, sizeof(TSDK_S_DOC_PAGE_BASE_INFO));

        CDemoDataconfCtrlDlg* pDataConfCtrlDlg = maindlg->GetDataConfCtrlDlg();
        CHECK_POINTER(pDataConfCtrlDlg);
        ::PostMessage(pDataConfCtrlDlg->GetSafeHwnd(), WM_DATACONF_MODULE_DS_PAGE_LOADED, (WPARAM)notifyInfo, NULL);
        break;
    }
    case TSDK_E_CONF_EVT_DS_DOC_LOAD_FINISH:
    {
        CHECK_POINTER(data);
        TSDK_S_DOC_BASE_INFO* pResult = (TSDK_S_DOC_BASE_INFO*)data;
        TSDK_S_DOC_BASE_INFO* notifyInfo = new TSDK_S_DOC_BASE_INFO;
        service_memset_s(notifyInfo, sizeof(TSDK_S_DOC_BASE_INFO), 0, sizeof(TSDK_S_DOC_BASE_INFO));
        memcpy_s(notifyInfo, sizeof(TSDK_S_DOC_BASE_INFO), pResult, sizeof(TSDK_S_DOC_BASE_INFO));

        CDemoDataconfCtrlDlg* pDataConfCtrlDlg = maindlg->GetDataConfCtrlDlg();
        CHECK_POINTER(pDataConfCtrlDlg);
        ::PostMessage(pDataConfCtrlDlg->GetSafeHwnd(), WM_DATACONF_MODULE_DS_DOCLOADED, (WPARAM)notifyInfo, (LPARAM)param2);
        break;
    }
    case TSDK_E_CONF_EVT_DS_DOC_DRAW_DATA_NOTIFY:
    {
        CDemoDataconfCtrlDlg* pDataConfCtrlDlg = maindlg->GetDataConfCtrlDlg();
        CHECK_POINTER(pDataConfCtrlDlg);
        ::PostMessage(pDataConfCtrlDlg->GetSafeHwnd(), WM_DATACONF_MODULE_DS_DRAW_DATA, NULL, NULL);
        break;
    }
    case TSDK_E_CONF_EVT_DS_DOC_CURRENT_PAGE_IND:
    {
        CHECK_POINTER(data);
        TSDK_S_DOC_PAGE_BASE_INFO* pResult = (TSDK_S_DOC_PAGE_BASE_INFO*)data;
        TSDK_S_DOC_PAGE_BASE_INFO* notifyInfo = new TSDK_S_DOC_PAGE_BASE_INFO;
        service_memset_s(notifyInfo, sizeof(TSDK_S_DOC_PAGE_BASE_INFO), 0, sizeof(TSDK_S_DOC_PAGE_BASE_INFO));
        memcpy_s(notifyInfo, sizeof(TSDK_S_DOC_PAGE_BASE_INFO), pResult, sizeof(TSDK_S_DOC_PAGE_BASE_INFO));

        CDemoDataconfCtrlDlg* pDataConfCtrlDlg = maindlg->GetDataConfCtrlDlg();
        CHECK_POINTER(pDataConfCtrlDlg);
        ::PostMessage(pDataConfCtrlDlg->GetSafeHwnd(), WM_DATACONF_MODULE_DS_PAGE_IND, (WPARAM)notifyInfo, NULL);
        break;
    }
    case TSDK_E_CONF_EVT_DS_DOC_DEL:
    {
        CHECK_POINTER(data);
        TSDK_S_DOC_SHARE_DEL_DOC_INFO* pResult = (TSDK_S_DOC_SHARE_DEL_DOC_INFO*)data;
        TSDK_S_DOC_SHARE_DEL_DOC_INFO* notifyInfo = new TSDK_S_DOC_SHARE_DEL_DOC_INFO;
        service_memset_s(notifyInfo, sizeof(TSDK_S_DOC_SHARE_DEL_DOC_INFO), 0, sizeof(TSDK_S_DOC_SHARE_DEL_DOC_INFO));
        memcpy_s(notifyInfo, sizeof(TSDK_S_DOC_SHARE_DEL_DOC_INFO), pResult, sizeof(TSDK_S_DOC_SHARE_DEL_DOC_INFO));

        CDemoDataconfCtrlDlg* pDataConfCtrlDlg = maindlg->GetDataConfCtrlDlg();
        CHECK_POINTER(pDataConfCtrlDlg);
        ::PostMessage(pDataConfCtrlDlg->GetSafeHwnd(), WM_DATACONF_MODULE_DS_DELETE, (WPARAM)notifyInfo, (LPARAM)param2);
        break;
    }
    case TSDK_E_CONF_EVT_WB_DOC_NEW:
    {
        CHECK_POINTER(data);
        TSDK_S_DOC_BASE_INFO* pResult = (TSDK_S_DOC_BASE_INFO*)data;
        TSDK_S_DOC_BASE_INFO* notifyInfo = new TSDK_S_DOC_BASE_INFO;
        service_memset_s(notifyInfo, sizeof(TSDK_S_DOC_BASE_INFO), 0, sizeof(TSDK_S_DOC_BASE_INFO));
        memcpy_s(notifyInfo, sizeof(TSDK_S_DOC_BASE_INFO), pResult, sizeof(TSDK_S_DOC_BASE_INFO));

        CDemoDataconfCtrlDlg* pDataConfCtrlDlg = maindlg->GetDataConfCtrlDlg();
        CHECK_POINTER(pDataConfCtrlDlg);
        ::PostMessage(pDataConfCtrlDlg->GetSafeHwnd(), WM_DATACONF_MODULE_WB_DOC_NEW, (WPARAM)notifyInfo, (LPARAM)param2);
        break;
    }
    case TSDK_E_CONF_EVT_WB_DOC_CURRENT_PAGE:
    {
        CHECK_POINTER(data);
        TSDK_S_DOC_PAGE_BASE_INFO* pResult = (TSDK_S_DOC_PAGE_BASE_INFO*)data;
        TSDK_S_DOC_PAGE_BASE_INFO* notifyInfo = new TSDK_S_DOC_PAGE_BASE_INFO;
        service_memset_s(notifyInfo, sizeof(TSDK_S_DOC_PAGE_BASE_INFO), 0, sizeof(TSDK_S_DOC_PAGE_BASE_INFO));
        memcpy_s(notifyInfo, sizeof(TSDK_S_DOC_PAGE_BASE_INFO), pResult, sizeof(TSDK_S_DOC_PAGE_BASE_INFO));

        CDemoDataconfCtrlDlg* pDataConfCtrlDlg = maindlg->GetDataConfCtrlDlg();
        CHECK_POINTER(pDataConfCtrlDlg);
        ::PostMessage(pDataConfCtrlDlg->GetSafeHwnd(), WM_DATACONF_MODULE_WB_CURRENT_PAGE, (WPARAM)notifyInfo, (LPARAM)param2);
        break;
    }
    case TSDK_E_CONF_EVT_WB_DOC_CURRENT_PAGE_IND:
    {
        CHECK_POINTER(data);
        TSDK_S_DOC_PAGE_BASE_INFO* pResult = (TSDK_S_DOC_PAGE_BASE_INFO*)data;
        TSDK_S_DOC_PAGE_BASE_INFO* notifyInfo = new TSDK_S_DOC_PAGE_BASE_INFO;
        service_memset_s(notifyInfo, sizeof(TSDK_S_DOC_PAGE_BASE_INFO), 0, sizeof(TSDK_S_DOC_PAGE_BASE_INFO));
        memcpy_s(notifyInfo, sizeof(TSDK_S_DOC_PAGE_BASE_INFO), pResult, sizeof(TSDK_S_DOC_PAGE_BASE_INFO));

        CDemoDataconfCtrlDlg* pDataConfCtrlDlg = maindlg->GetDataConfCtrlDlg();
        CHECK_POINTER(pDataConfCtrlDlg);
        ::PostMessage(pDataConfCtrlDlg->GetSafeHwnd(), WM_DATACONF_MODULE_WB_CURRENT_PAGE_IND, (WPARAM)notifyInfo, (LPARAM)param2);
        break;
    }
    case TSDK_E_CONF_EVT_WB_PAGE_NEW:
    {
        CHECK_POINTER(data);
        TSDK_S_DOC_PAGE_BASE_INFO* pResult = (TSDK_S_DOC_PAGE_BASE_INFO*)data;
        TSDK_S_DOC_PAGE_BASE_INFO* notifyInfo = new TSDK_S_DOC_PAGE_BASE_INFO;
        service_memset_s(notifyInfo, sizeof(TSDK_S_DOC_PAGE_BASE_INFO), 0, sizeof(TSDK_S_DOC_PAGE_BASE_INFO));
        memcpy_s(notifyInfo, sizeof(TSDK_S_DOC_PAGE_BASE_INFO), pResult, sizeof(TSDK_S_DOC_PAGE_BASE_INFO));

        CDemoDataconfCtrlDlg* pDataConfCtrlDlg = maindlg->GetDataConfCtrlDlg();
        CHECK_POINTER(pDataConfCtrlDlg);
        ::PostMessage(pDataConfCtrlDlg->GetSafeHwnd(), WM_DATACONF_MODULE_WB_PAG_NEW, (WPARAM)notifyInfo, (LPARAM)param2);
        break;
    }
    case TSDK_E_CONF_EVT_WB_DOC_DRAW_DATA_NOTIFY:
    {
        CHECK_POINTER(data);
        TSDK_S_DOC_PAGE_BASE_INFO* pResult = (TSDK_S_DOC_PAGE_BASE_INFO*)data;
        TSDK_S_DOC_PAGE_BASE_INFO* notifyInfo = new TSDK_S_DOC_PAGE_BASE_INFO;
        service_memset_s(notifyInfo, sizeof(TSDK_S_DOC_PAGE_BASE_INFO), 0, sizeof(TSDK_S_DOC_PAGE_BASE_INFO));
        memcpy_s(notifyInfo, sizeof(TSDK_S_DOC_PAGE_BASE_INFO), pResult, sizeof(TSDK_S_DOC_PAGE_BASE_INFO));

        CDemoDataconfCtrlDlg* pDataConfCtrlDlg = maindlg->GetDataConfCtrlDlg();
        CHECK_POINTER(pDataConfCtrlDlg);
        ::PostMessage(pDataConfCtrlDlg->GetSafeHwnd(), WM_DATACONF_MODULE_WB_DRAW_DATA, (WPARAM)notifyInfo, (LPARAM)param2);
        break;
    }
    case TSDK_E_CONF_EVT_WB_DOC_DEL:
    {
        CHECK_POINTER(data);
        TSDK_S_WB_DEL_DOC_INFO* pResult = (TSDK_S_WB_DEL_DOC_INFO*)data;
        TSDK_S_WB_DEL_DOC_INFO* notifyInfo = new TSDK_S_WB_DEL_DOC_INFO;

        service_memset_s(notifyInfo, sizeof(TSDK_S_WB_DEL_DOC_INFO), 0, sizeof(TSDK_S_WB_DEL_DOC_INFO));
        memcpy_s(notifyInfo, sizeof(TSDK_S_WB_DEL_DOC_INFO), pResult, sizeof(TSDK_S_WB_DEL_DOC_INFO));

        CDemoDataconfCtrlDlg* pDataConfCtrlDlg = maindlg->GetDataConfCtrlDlg();
        CHECK_POINTER(pDataConfCtrlDlg);
        ::PostMessage(pDataConfCtrlDlg->GetSafeHwnd(), WM_DATACONF_MODULE_WB_DOC_DEL, (WPARAM)notifyInfo, (LPARAM)param2);
        break;
    }
    /*case TSDK_E_CONF_EVT_WB_PAGE_DEL:
    {
        CHECK_POINTER(data);
        TSDK_S_DOC_PAGE_BASE_INFO* pResult = (TSDK_S_DOC_PAGE_BASE_INFO*)data;
        TSDK_S_DOC_PAGE_BASE_INFO* notifyInfo = new TSDK_S_DOC_PAGE_BASE_INFO;

        service_memset_s(notifyInfo, sizeof(TSDK_S_DOC_PAGE_BASE_INFO), 0, sizeof(TSDK_S_DOC_PAGE_BASE_INFO));
        memcpy_s(notifyInfo, sizeof(TSDK_S_DOC_PAGE_BASE_INFO), pResult, sizeof(TSDK_S_DOC_PAGE_BASE_INFO));

        CDemoDataconfCtrlDlg* pDataConfCtrlDlg = maindlg->GetDataConfCtrlDlg();
        CHECK_POINTER(pDataConfCtrlDlg);
        ::PostMessage(pDataConfCtrlDlg->GetSafeHwnd(), , (WPARAM)notifyInfo, (LPARAM)param2);
        break;
    }*/
    case TSDK_E_CONF_EVT_RECV_CHAT_MSG:
    {
        CHECK_POINTER(data);
        TSDK_S_CONF_CHAT_MSG_INFO* pResult = (TSDK_S_CONF_CHAT_MSG_INFO*)data;
        TSDK_S_CONF_CHAT_MSG_INFO* notifyInfo = new TSDK_S_CONF_CHAT_MSG_INFO;

        service_memset_s(notifyInfo, sizeof(TSDK_S_CONF_CHAT_MSG_INFO), 0, sizeof(TSDK_S_CONF_CHAT_MSG_INFO));

        memcpy_s(notifyInfo, sizeof(TSDK_S_CONF_CHAT_MSG_INFO), pResult, sizeof(TSDK_S_CONF_CHAT_MSG_INFO));

        notifyInfo->chat_msg = new char[notifyInfo->chat_msg_len + 1];
        service_memset_s(notifyInfo->chat_msg, notifyInfo->chat_msg_len + 1, 0, notifyInfo->chat_msg_len + 1);
        strncpy_s(notifyInfo->chat_msg, notifyInfo->chat_msg_len + 1, pResult->chat_msg, notifyInfo->chat_msg_len);

        CDemoAudioMeetingDlg* pAudioMettingDlg = maindlg->GetDemoAudioMeetingDlg();
        CHECK_POINTER(pAudioMettingDlg);
        ::PostMessage(pAudioMettingDlg->GetSafeHwnd(), WM_DATACONF_MODULE_RECEIVED_CHATMSG, (WPARAM)notifyInfo, NULL);

        break;
    }
    case TSDK_E_CONF_EVT_RECV_CUSTOM_DATA_IND:
    {
        CHECK_POINTER(data);
        TSDK_S_CONF_CUSTOM_DATA_INFO* pResult = (TSDK_S_CONF_CUSTOM_DATA_INFO*)data;
        TSDK_S_CONF_CUSTOM_DATA_INFO* notifyInfo = new TSDK_S_CONF_CUSTOM_DATA_INFO;

        service_memset_s(notifyInfo, sizeof(TSDK_S_CONF_CUSTOM_DATA_INFO), 0, sizeof(TSDK_S_CONF_CUSTOM_DATA_INFO));

        memcpy_s(notifyInfo, sizeof(TSDK_S_CONF_CUSTOM_DATA_INFO), pResult, sizeof(TSDK_S_CONF_CUSTOM_DATA_INFO));

        if (notifyInfo->interface_type == TSDK_S_CONF_NORMAL_SEND_DATA_INTERFACE_TYPE)
        {
            notifyInfo->data_content = new TSDK_UINT8[notifyInfo->data_len + 1];
            service_memset_s(notifyInfo->data_content, notifyInfo->data_len + 1, 0, notifyInfo->data_len + 1);
            memcpy_s(notifyInfo->data_content, pResult->data_len + 1, pResult->data_content, pResult->data_len);

            CDemoAudioMeetingDlg* pAudioMettingDlg = maindlg->GetDemoAudioMeetingDlg();
            CHECK_POINTER(pAudioMettingDlg);
            ::PostMessage(pAudioMettingDlg->GetSafeHwnd(), WM_DATACONF_MODULE_RECEIVED_USER_DATAMSG, (WPARAM)notifyInfo, NULL);
        }

        break;
    }

    case TSDK_E_CONF_EVT_AS_PRIVILEGE_CHANGE:
    {
        if (0 == service_is_use_ui_plugin())
        {
            CHECK_POINTER(data);
            TSDK_S_CONF_AS_PRIVILEGE_INFO* pResult = (TSDK_S_CONF_AS_PRIVILEGE_INFO*)data;
            TSDK_S_CONF_AS_PRIVILEGE_INFO* notifyInfo = new TSDK_S_CONF_AS_PRIVILEGE_INFO;
            service_memset_s(notifyInfo, sizeof(TSDK_S_CONF_AS_PRIVILEGE_INFO), 0, sizeof(TSDK_S_CONF_AS_PRIVILEGE_INFO));
            memcpy_s(notifyInfo, sizeof(TSDK_S_CONF_AS_PRIVILEGE_INFO), pResult, sizeof(TSDK_S_CONF_AS_PRIVILEGE_INFO));

            CDemoDataconfCtrlDlg* pDataConfCtrlDlg = maindlg->GetDataConfCtrlDlg();
            CHECK_POINTER(pDataConfCtrlDlg);
            ::PostMessage(pDataConfCtrlDlg->GetSafeHwnd(), WM_DATACONF_MODULE_AS_PRIVILEGE_CHANGE, (WPARAM)notifyInfo, (LPARAM)param2);
        }
        else
        {
            CHECK_POINTER(data);
            TSDK_S_CONF_AS_PRIVILEGE_INFO* privilegeInfo = (TSDK_S_CONF_AS_PRIVILEGE_INFO*)data;

            if (TSDK_E_CONF_SHARE_PRIVILEGE_CONTROL == privilegeInfo->privilege_type)
            {
                CString selfNum = CTools::GetSipNumber(g_sipNumber);
                std::string strSelfNum = CTools::UNICODE2UTF(selfNum);
                switch (privilegeInfo->action)
                {
                case TSDK_E_CONF_AS_ACTION_DELETE:
                {
                    if (strcmp(strSelfNum.c_str(), privilegeInfo->attendee.base_info.number) == 0)
                    {
                        CTools::ShowMessageTimeout(_T("Your remote control permission has been released."), 5000);
                    }
                    else if (strcmp(strSelfNum.c_str(), CTools::UNICODE2UTF(share_number).c_str()) == 0)
                    {
                        CTools::ShowMessageTimeout(_T("Remote control permission has been Revoked from ") + CTools::UTF2UNICODE(privilegeInfo->attendee.base_info.display_name), 5000);
                    }
                    break;
                }

                case TSDK_E_CONF_AS_ACTION_ADD:
                {
                    if (strcmp(strSelfNum.c_str(), privilegeInfo->attendee.base_info.number) == 0)
                    {
                        CTools::ShowMessageTimeout(_T("You are granted remote control permission."), 5000);
                    }
                    else if (strcmp(strSelfNum.c_str(), CTools::UNICODE2UTF(share_number).c_str()) == 0)
                    {
                        CTools::ShowMessageTimeout(_T("Your remote control permission has been granted to ") + CTools::UTF2UNICODE(privilegeInfo->attendee.base_info.display_name), 5000);
                    }
                    break;
                }

                case TSDK_E_CONF_AS_ACTION_MODIFY:
                {
                    break;
                }

                case TSDK_E_CONF_AS_ACTION_REQUEST:
                {
                    CDemoPromptDlg dlg;
                    dlg.SetTextOfContent(CTools::UTF2UNICODE(privilegeInfo->attendee.base_info.display_name) + _T(" request remote control your desk, do you agree?"));
                    INT_PTR nResponse = dlg.DoModal();

                    if (IDOK == nResponse)
                    {
                        //ͬ������Զ�̿���Ȩ��
                        service_data_conf_app_share_set_privilege(privilegeInfo->attendee.base_info.number, TSDK_E_CONF_SHARE_PRIVILEGE_CONTROL, TSDK_E_CONF_AS_ACTION_ADD);
                    }
                    if (IDCANCEL == nResponse || IDCLOSE == nResponse)
                    {
                        //�ܾ�����Զ�̿���Ȩ��
                        service_data_conf_app_share_set_privilege(privilegeInfo->attendee.base_info.number, TSDK_E_CONF_SHARE_PRIVILEGE_CONTROL, TSDK_E_CONF_AS_ACTION_REJECT);
                    }
                    break;
                }

                case TSDK_E_CONF_AS_ACTION_REJECT: //����Զ�̿��Ƶ��û����ܾ����յ���Ȩ�ޱ���¼�
                {
                    CTools::ShowMessageTimeout(_T("Your remote control request has been rejected."), 5000);
                    break;
                }

                default:
                    break;
                }
            }
        }
        break;
    }

    case TSDK_E_CONF_EVT_DATA_COMPT_TOKEN_MSG:
    {
        CHECK_POINTER(data);
        TSDK_S_CONF_TOKEN_MSG* token_info = (TSDK_S_CONF_TOKEN_MSG*)data;

        if (TSDK_NULL_PTR != token_info && token_info->result != 0)
        {
            CTools::ShowMessageTimeout(_T("Token request failed."), 2000);
        }
        break;
    }

    default:
        break;
    }
}

void NotifyCallBack::ldapFrontstageMsgNotify(unsigned int msg_id, unsigned int param1, unsigned int param2, void* data)
{
    CDemoApp* app = (CDemoApp*)AfxGetApp();
    if (!app)
    {
        //�����Ѿ��ر�
        return;
    }

    CDemoMainDlg* maindlg = (CDemoMainDlg*)(app->m_pMainDlgWnd);
    CHECK_POINTER(maindlg);

    switch (msg_id)
    {
    case TSDK_E_LDAP_FRONTSTAGE_EVT_SEARCH_RESULT:
    {
        if (TSDK_SUCCESS == param1)
        {
            CHECK_POINTER(data);
            TSDK_S_LDAP_SEARCH_RESULT_INFO* pResult = (TSDK_S_LDAP_SEARCH_RESULT_INFO*)data;

            if (pResult == NULL 
                || (pResult != NULL && pResult->search_result_data == NULL)
                || (pResult != NULL && pResult->search_result_data != NULL && pResult->search_result_data->current_count == 0))
            {
                maindlg->MessageBox(_T("search no data!"));
                return;
            }

            if (pResult != NULL)
            {
                TSDK_S_LDAP_SEARCH_RESULT_INFO* notifyInfo = new TSDK_S_LDAP_SEARCH_RESULT_INFO;
                service_memset_s(notifyInfo, sizeof(TSDK_S_LDAP_SEARCH_RESULT_INFO), 0, sizeof(TSDK_S_LDAP_SEARCH_RESULT_INFO));
                memcpy_s(notifyInfo, sizeof(TSDK_S_LDAP_SEARCH_RESULT_INFO), pResult, sizeof(TSDK_S_LDAP_SEARCH_RESULT_INFO));

                if (pResult->cookie_len > 0)
                {
                    char * charPageCookie = (char *)malloc(pResult->cookie_len * sizeof(char));
                    service_memset_s(charPageCookie, pResult->cookie_len * sizeof(char), 0, pResult->cookie_len * sizeof(char));
                    memcpy_s(charPageCookie, pResult->cookie_len * sizeof(char), pResult->page_cookie, pResult->cookie_len * sizeof(char));
                    notifyInfo->page_cookie = charPageCookie;
                }

                if (pResult->search_result_data != NULL)
                {
                    TSDK_S_LDAP_SEARCH_RESULT_DATA * search_result_data = new TSDK_S_LDAP_SEARCH_RESULT_DATA;
                    service_memset_s(search_result_data, sizeof(TSDK_S_LDAP_SEARCH_RESULT_DATA), 0, sizeof(TSDK_S_LDAP_SEARCH_RESULT_DATA));
                    memcpy_s(search_result_data, sizeof(TSDK_S_LDAP_SEARCH_RESULT_DATA), pResult->search_result_data, sizeof(TSDK_S_LDAP_SEARCH_RESULT_DATA));
                    notifyInfo->search_result_data = search_result_data;

                    if (NULL != pResult->search_result_data->contact_list && pResult->search_result_data->current_count > 0)
                    {
                        TSDK_S_LDAP_CONTACT* contact_list = new TSDK_S_LDAP_CONTACT[pResult->search_result_data->current_count];
                        service_memset_s(contact_list, sizeof(TSDK_S_LDAP_CONTACT) * pResult->search_result_data->current_count, 0, sizeof(TSDK_S_LDAP_CONTACT) * pResult->search_result_data->current_count);
                        memcpy_s(contact_list, sizeof(TSDK_S_LDAP_CONTACT) * pResult->search_result_data->current_count, pResult->search_result_data->contact_list, sizeof(TSDK_S_LDAP_CONTACT) * pResult->search_result_data->current_count);
                        notifyInfo->search_result_data->contact_list = contact_list;
                    }
                }

                CDemoEUAContactDlg* demoEUAContactDlg = maindlg->GetDemoEUAContactDlg();
                CHECK_POINTER(demoEUAContactDlg);
                ::PostMessage(demoEUAContactDlg->GetSafeHwnd(), WM_LDAP_FRONTSTAGE_GET_SEARCH_LIST_RESULT, (WPARAM)notifyInfo, (LPARAM)0);
            }
        }
        else
        {
            TSDK_S_LDAP_SEARCH_RESULT_INFO* pResult = (TSDK_S_LDAP_SEARCH_RESULT_INFO*)data;

            CDemoEUAContactDlg* demoEUAContactDlg = maindlg->GetDemoEUAContactDlg();
            if (demoEUAContactDlg != NULL)
            {
                demoEUAContactDlg->ClearSearchResult();
            }
            CString info;
            info.Format(_T("get ldap search result list failed! failed:%d"), pResult->result_code);
            maindlg->MessageBox(info);
        }
        break;
    }
    default:
        break;
    }
}

void NotifyCallBack::uiPluginMsgNotify(unsigned int msg_id, unsigned int param1, unsigned int param2, void* data)
{
    CDemoApp* app = (CDemoApp*)AfxGetApp();
    if (!app)
    {
        //�����Ѿ��ر�
        return;
    }

    CDemoMainDlg* maindlg = (CDemoMainDlg*)(app->m_pMainDlgWnd);
    CHECK_POINTER(maindlg);

    switch (msg_id)
    {
    case TSDK_E_UI_PLUGIN_EVT_CLICK_HANGUP_CALL:
    {
        CDemoCallCtrlDlg* pCallDlg;
        pCallDlg = CallDlgManager::GetInstance().GetCallDlgByCallID(param1);
        CHECK_POINTER(pCallDlg);
        ::PostMessage(pCallDlg->GetSafeHwnd(), WM_CALL_UI_PLUGIN_CLICK_HANGUP_CALL, NULL, NULL);
        break;
    }

    case TSDK_E_UI_PLUGIN_EVT_CLICK_LEAVE_CONF:
    {
        CDemoAudioMeetingDlg* pAudioMettingDlg = maindlg->GetDemoAudioMeetingDlg();
        CHECK_POINTER(pAudioMettingDlg);
        ::PostMessage(pAudioMettingDlg->GetSafeHwnd(), WM_CONF_CTRL_UI_PLUGIN_CLICK_LEAVE_CONF, NULL, NULL);
        break;
    }

    case TSDK_E_UI_PLUGIN_EVT_CLICK_END_CONF:
    {
        CDemoAudioMeetingDlg* pAudioMettingDlg = maindlg->GetDemoAudioMeetingDlg();
        CHECK_POINTER(pAudioMettingDlg);
        ::PostMessage(pAudioMettingDlg->GetSafeHwnd(), WM_CONF_CTRL_UI_PLUGIN_CLICK_END_CONF, NULL, NULL);
        break;
    }


    case TSDK_E_UI_PLUGIN_EVT_CLICK_START_SHARE:
    {
        /*CDemoAudioMeetingDlg* pAudioMettingDlg = maindlg->GetDemoAudioMeetingDlg();
        CHECK_POINTER(pAudioMettingDlg);
        ::PostMessage(pAudioMettingDlg->GetSafeHwnd(), WM_CONF_CTRL_UI_PLUGIN_CLICK_START_SHARE, NULL, NULL);*/
        break;
    }

    case TSDK_E_UI_PLUGIN_EVT_SET_WINDOW_SIZE:
    {
        CHECK_POINTER(data);
        CDemoAudioMeetingDlg* pAudioMettingDlg = maindlg->GetDemoAudioMeetingDlg();
        CHECK_POINTER(pAudioMettingDlg);
        TSDK_S_UI_PLUGIN_WND_SIZE_INFO* notifyInfo = new TSDK_S_UI_PLUGIN_WND_SIZE_INFO;
        service_memset_s(notifyInfo, sizeof(TSDK_S_UI_PLUGIN_WND_SIZE_INFO), 0, sizeof(TSDK_S_UI_PLUGIN_WND_SIZE_INFO));
        memcpy_s(notifyInfo, sizeof(TSDK_S_UI_PLUGIN_WND_SIZE_INFO), data, sizeof(TSDK_S_UI_PLUGIN_WND_SIZE_INFO));

        ::PostMessage(pAudioMettingDlg->GetSafeHwnd(), WM_CONF_CTRL_UI_PLUGIN_EVT_SET_WINDOW_SIZE, NULL, (LPARAM)notifyInfo);
        break;
    }

    case TSDK_E_UI_PLUGIN_START_SHARE_FAILED:
    {
        CTools::ShowMessageTimeout(_T("Start share failed."), 2000);
        break;
    }


    default:
        break;
    }
}
