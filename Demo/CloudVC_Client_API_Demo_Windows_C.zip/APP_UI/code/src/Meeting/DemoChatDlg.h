#pragma once
#include "Resource.h"

// CDemoChatDlg �Ի���

class CDemoChatDlg : public CDialogEx
{
	DECLARE_DYNAMIC(CDemoChatDlg)

public:
	CDemoChatDlg(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CDemoChatDlg();

// �Ի�������
	enum { IDD = IDD_CHAT_DLG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	DECLARE_MESSAGE_MAP()
public:
    afx_msg void OnBnClickedOk();
    CString& GetChatMsg();
    virtual BOOL OnInitDialog();
    void SetDlgType(bool bIsSending){m_bIsSending = bIsSending;}
private:
    CString m_szChatMsg;
    bool m_bIsSending;
};
