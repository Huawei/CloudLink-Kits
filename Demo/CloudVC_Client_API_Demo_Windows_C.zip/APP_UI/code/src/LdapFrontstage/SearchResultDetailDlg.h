#pragma once
#include "stdafx.h"
#include "resource.h"
#include "afxdtctl.h"
#include "afxcmn.h"
#include "tsdk_ldap_frontstage_def.h"

// CDemoEUAContactDlg dialog


class CSearchResultDetailDlg : public CDialogEx
{
    DECLARE_DYNAMIC(CSearchResultDetailDlg)

public:
    CSearchResultDetailDlg(CWnd* pParent = NULL);   // standard constructor
    virtual ~CSearchResultDetailDlg();

    // Dialog����
    enum { IDD = IDD_LDAP_SEARCH_RESULT_DETAIL };

protected:
    virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

    DECLARE_MESSAGE_MAP()

    virtual BOOL OnInitDialog();

private:
    TSDK_S_LDAP_CONTACT *m_contactData;
    //CEdit m_editSearchKeyWord;
public:
    void SetContactData(TSDK_S_LDAP_CONTACT *contactData);
};

