#include <afxpriv.h>
#include "stdafx.h"
#include "afxdialogex.h"
#include "DemoData.h"
#include "DemoCommonTools.h"
#include "SearchResultDetailDlg.h"
#include "service_tools.h"
#include "service_call_interface.h"
#include "tsdk_ldap_frontstage_def.h"
#include "service_ldap_interface.h"
#include "service_os_adapt.h"


// DemoEUAContactDlg dialog

IMPLEMENT_DYNAMIC(CSearchResultDetailDlg, CDialogEx)

CSearchResultDetailDlg::CSearchResultDetailDlg(CWnd* pParent /*=NULL*/)
    : CDialogEx(CSearchResultDetailDlg::IDD, pParent)
{

}

CSearchResultDetailDlg::~CSearchResultDetailDlg()
{
}


void CSearchResultDetailDlg::DoDataExchange(CDataExchange* pDX)
{
    CDialogEx::DoDataExchange(pDX);
    //DDX_Control(pDX, IDC_DEPARTMENT_TREE, m_treeContactDepartmentList);
}

BEGIN_MESSAGE_MAP(CSearchResultDetailDlg, CDialogEx)
END_MESSAGE_MAP()

// CDemoMeetingDlg message handlers
BOOL CSearchResultDetailDlg::OnInitDialog()
{
    CDialogEx::OnInitDialog();

    if (m_contactData != NULL)
    {
        GetDlgItem(IDC_EDIT1)->SetWindowText(CTools::UTF2UNICODE(m_contactData->id_));
        GetDlgItem(IDC_EDIT2)->SetWindowText(CTools::UTF2UNICODE(m_contactData->uri_));
        GetDlgItem(IDC_EDIT3)->SetWindowText(CTools::UTF2UNICODE(m_contactData->ucAcc_));
        GetDlgItem(IDC_EDIT4)->SetWindowText(CTools::UTF2UNICODE(m_contactData->staffNo_));
        GetDlgItem(IDC_EDIT5)->SetWindowText(CTools::UTF2UNICODE(m_contactData->name_));
        GetDlgItem(IDC_EDIT6)->SetWindowText(CTools::UTF2UNICODE(m_contactData->nickName_));
        GetDlgItem(IDC_EDIT7)->SetWindowText(CTools::UTF2UNICODE(m_contactData->qpinyin_));
        GetDlgItem(IDC_EDIT8)->SetWindowText(CTools::UTF2UNICODE(m_contactData->spinyin_));
        GetDlgItem(IDC_EDIT9)->SetWindowText(CTools::UTF2UNICODE(m_contactData->homePhone_));
        GetDlgItem(IDC_EDIT10)->SetWindowText(CTools::UTF2UNICODE(m_contactData->officePhone_));
        GetDlgItem(IDC_EDIT11)->SetWindowText(CTools::UTF2UNICODE(m_contactData->mobile_));
        GetDlgItem(IDC_EDIT12)->SetWindowText(CTools::UTF2UNICODE(m_contactData->otherPhone_));
        GetDlgItem(IDC_EDIT13)->SetWindowText(CTools::UTF2UNICODE(m_contactData->address_));
        GetDlgItem(IDC_EDIT14)->SetWindowText(CTools::UTF2UNICODE(m_contactData->email_));
        GetDlgItem(IDC_EDIT15)->SetWindowText(CTools::UTF2UNICODE(m_contactData->duty_));
        GetDlgItem(IDC_EDIT16)->SetWindowText(CTools::UTF2UNICODE(m_contactData->fax_));
        GetDlgItem(IDC_EDIT17)->SetWindowText(CTools::UTF2UNICODE(m_contactData->gender_));
        GetDlgItem(IDC_EDIT18)->SetWindowText(CTools::UTF2UNICODE(m_contactData->corpName_));
        GetDlgItem(IDC_EDIT19)->SetWindowText(CTools::UTF2UNICODE(m_contactData->deptName_));
        GetDlgItem(IDC_EDIT20)->SetWindowText(CTools::UTF2UNICODE(m_contactData->webSite_));
        GetDlgItem(IDC_EDIT21)->SetWindowText(CTools::UTF2UNICODE(m_contactData->desc_));
        GetDlgItem(IDC_EDIT22)->SetWindowText(CTools::UTF2UNICODE(m_contactData->zip_));
        GetDlgItem(IDC_EDIT23)->SetWindowText(CTools::UTF2UNICODE(m_contactData->signature_));
        GetDlgItem(IDC_EDIT24)->SetWindowText(CTools::UTF2UNICODE(m_contactData->imageID_));
        GetDlgItem(IDC_EDIT25)->SetWindowText(CTools::UTF2UNICODE(m_contactData->position_));
        GetDlgItem(IDC_EDIT26)->SetWindowText(CTools::UTF2UNICODE(m_contactData->location_));
        GetDlgItem(IDC_EDIT27)->SetWindowText(CTools::UTF2UNICODE(m_contactData->tzone_));
        GetDlgItem(IDC_EDIT28)->SetWindowText(CTools::UTF2UNICODE(m_contactData->avtool_));
        GetDlgItem(IDC_EDIT29)->SetWindowText(CTools::UTF2UNICODE(m_contactData->device_));
        GetDlgItem(IDC_EDIT30)->SetWindowText(CTools::UTF2UNICODE(m_contactData->terminalType_));
        GetDlgItem(IDC_EDIT31)->SetWindowText(CTools::num2CString(m_contactData->flow_));
        GetDlgItem(IDC_EDIT32)->SetWindowText(CTools::UTF2UNICODE(m_contactData->confid_));
        GetDlgItem(IDC_EDIT33)->SetWindowText(CTools::UTF2UNICODE(m_contactData->accessNum_));
        GetDlgItem(IDC_EDIT34)->SetWindowText(CTools::UTF2UNICODE(m_contactData->chair_pwd_));
        
    }
    return TRUE;
}

void CSearchResultDetailDlg::SetContactData(TSDK_S_LDAP_CONTACT *contactData)
{
    m_contactData = contactData;
}
