//
//  DemoMeetingDlg.h
//  EC_SDK_DEMO
//
//  Created by EC Open support team.
//  Copyright(C), 2018, Huawei Tech. Co., Ltd. ALL RIGHTS RESERVED.
//

#pragma once
#include "stdafx.h"
#include "resource.h"
#include "afxdtctl.h"
#include "afxcmn.h"
#include "tsdk_ldap_frontstage_def.h"

// CDemoEUAContactDlg dialog

class CDemoEUAContactDlg : public CDialogEx
{
    DECLARE_DYNAMIC(CDemoEUAContactDlg)

public:
    CDemoEUAContactDlg(CWnd* pParent = NULL);   // standard constructor
    virtual ~CDemoEUAContactDlg();

    // Dialog����
    enum { IDD = IDD_LDAP_SEARCH_RESULT_DLG };

protected:
    virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

    DECLARE_MESSAGE_MAP()

    virtual BOOL OnInitDialog();

public:
    afx_msg void OnBnClickedGetSearchlist();
    afx_msg LRESULT OnGetSearchResultList(WPARAM wParam, LPARAM lparam);
    bool findinExistGroup(CString group);
    void ClearSearchResult();
    void FreeTreeNodeData(HTREEITEM childItem);
private:
    CTreeCtrl m_treeContactDepartmentList;
    HTREEITEM m_tree_root;
    vector<CString>  added_grp_tree_node;
    CEdit m_editSearchKeyWord;
    CEdit m_editPageSize;
    CString m_SearchKeyWordString;
    CString m_PageSizeString;
    CListCtrl m_listBoxSearchResult;
    unsigned int g_current_seq_no = -1;
    unsigned int m_cookie_len;
    char m_page_cookie[100];
public:
    afx_msg void OnTvnSelchangedDepartmentTree(NMHDR *pNMHDR, LRESULT *pResult);
    afx_msg void OnNextPageBtnClicked();
    afx_msg void OnResultListItemClick(NMHDR *pNMHDR, LRESULT *pResult);
    afx_msg void OnResultListNMClick(NMHDR *pNMHDR, LRESULT *pResult);
    afx_msg void OnClose();
    afx_msg void OnDestroy();
};

