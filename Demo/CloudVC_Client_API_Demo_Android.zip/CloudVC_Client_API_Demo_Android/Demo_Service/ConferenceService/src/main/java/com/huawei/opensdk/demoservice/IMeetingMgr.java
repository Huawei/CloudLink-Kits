package com.huawei.opensdk.demoservice;


/**
 * Meeting function interface.
 */
public interface IMeetingMgr {
}
