package com.huawei.opensdk.contactservice.ldap;

import android.util.Log;

import com.huawei.ecterminalsdk.base.TsdkPageCookieData;
import com.huawei.ecterminalsdk.base.TsdkSearchLdapContactsParam;
import com.huawei.ecterminalsdk.base.TsdkOnEvtSearchLdapContactsResult;
import com.huawei.ecterminalsdk.base.TsdkSearchLdapContactsResult;
import com.huawei.ecterminalsdk.models.TsdkCommonResult;
import com.huawei.ecterminalsdk.models.TsdkManager;
import com.huawei.ecterminalsdk.models.ldap.TsdkLdapFrontstageManager;

import java.util.ArrayList;

/**
 * This class is about ldap frontstage manager.
 * ldap地址本模块管理类
 */
public class LdapFrontstageMgr {

    private static final String TAG = LdapFrontstageMgr.class.getSimpleName();

    /**
     * The LdapFrontstageMgr function object.
     * LdapFrontstageMgr对象
     */
    private static LdapFrontstageMgr instance;

    /**
     * UI notification.
     * 回调接口对象
     */
    private ILdapFrontstageNotification notification;

    /**
     * The TsdkLdapFrontstageManager object.
     * TsdkLdapFrontstageManager对象
     */
    private TsdkLdapFrontstageManager tsdkLdapFrontstageManager;

    /**
     * This is a constructor of this class
     * 构造函数
     */
    public LdapFrontstageMgr() {
        tsdkLdapFrontstageManager = TsdkManager.getInstance().getLdapFrontstageManager();
    }

    /**
     * This method is used to get instance object of EnterpriseAddressBookMgr.
     * 获取EnterpriseAddressBookMgr对象实例
     *
     * @return EnterpriseAddressBookMgr Return instance object of EnterpriseAddressBookMgr
     * 返回一个对象的示例
     */
    public static LdapFrontstageMgr getInstance() {
        if (instance == null) {
            instance = new LdapFrontstageMgr();
        }
        return instance;
    }

    /**
     * This method is used to register EnterpriseAddressBookMgr module UI callback.
     * 注册回调
     *
     * @param notification
     */
    public void registerNotification(ILdapFrontstageNotification notification) {
        this.notification = notification;
    }

    /**
     * This method is used to search contact's information.
     * 获取联系人的信息
     *
     * @param keyWords Indicates keyWords
     *                 搜索条件
     * @return int Return seq
     * 返回查询的序列号
     */
    public int searchLdapContacts(String keyWords, String currentBaseDN, String sortAttribute, int searchSingleLevel,
                                  int pageSize, int cookieLength, ArrayList<TsdkPageCookieData> pageCookie) {
        if (null == keyWords) {
            Log.e(TAG, "Search condition is empty");
        }

        TsdkSearchLdapContactsParam searchLdapContactsParam = new TsdkSearchLdapContactsParam();
        searchLdapContactsParam.setKeywords(keyWords);
        searchLdapContactsParam.setCurrentBaseDN(currentBaseDN);
        searchLdapContactsParam.setSortAttribute(sortAttribute);
        searchLdapContactsParam.setSearchSingleLevel(searchSingleLevel);
        searchLdapContactsParam.setPageSize(pageSize);
        searchLdapContactsParam.setCookieLength(cookieLength);
        searchLdapContactsParam.setPageCookie(pageCookie);

        int result = tsdkLdapFrontstageManager.searchLdapContacts(searchLdapContactsParam);

        Log.i(TAG, "searchResult -->" + result);
        return result;
    }

    /**
     * This method is used to get search contacts result.
     * 查询联系人信息返回结果
     *
     * @param result              Indicates search result
     *                            查询结果
     * @param searchParamResult Indicates search contact information
     *                            查询到的联系人信息
     */
    public void handleSearchLdapContactResult(TsdkCommonResult result, TsdkOnEvtSearchLdapContactsResult.Param searchParamResult) {
        int ret = result.getResult();
        //c层返回boolean 1true 0false  获取联系人成功返回1
        if (ret == 1) {
            TsdkSearchLdapContactsResult searchResultData = searchParamResult.getSearchResultData();
            if (searchResultData != null) {
                int currentCount = searchParamResult.getSearchResultData().getCurrentCount();
                //查询到0个联系人
                if (0 == currentCount) {
                    notification.onEntLdapFrontstageNotify(LdapFrontstageConstant.Event.SEARCH_CONTACTS_NOT_FOUND, null);
                } else {
                    notification.onEntLdapFrontstageNotify(LdapFrontstageConstant.Event.SEARCH_CONTACTS_COMPLETE, searchParamResult);
                }
                Log.i(TAG, currentCount + "Get the current number of returned contacts");
            } else {
                notification.onEntLdapFrontstageNotify(LdapFrontstageConstant.Event.SEARCH_CONTACTS_NOT_FOUND, null);
            }
        } else {
            Log.e(TAG, "Search contacts failed, result.result 1true 0false-->" + result.result);
            Log.e(TAG, "Search contacts failed, result.reasonDescription -->" + result.reasonDescription);
            notification.onEntLdapFrontstageNotify(LdapFrontstageConstant.Event.SEARCH_CONTACTS_FAILED, null);
        }
    }
}
