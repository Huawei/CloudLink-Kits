package com.huawei.opensdk.contactservice.ldap;

/**
 * This class is about definition of enterprise address constant.
 * Ldap地址本功能常量类
 */
public class LdapFrontstageConstant {

    public enum Event
    {
        /**
         * Failed to search contacts
         * 查询联系人失败
         */
        SEARCH_CONTACTS_FAILED(),

        /**
         * No contacts were searched
         * 查询到0个联系人
         */
        SEARCH_CONTACTS_NOT_FOUND(),

        /**
         * Search contacts completed
         * 查询联系人成功
         */
        SEARCH_CONTACTS_COMPLETE(),

        /**
         * Search self
         * 查询自己的信息
         */
        SEARCH_SELF_COMPLETE(),

        UNKNOWN()
    }
}
