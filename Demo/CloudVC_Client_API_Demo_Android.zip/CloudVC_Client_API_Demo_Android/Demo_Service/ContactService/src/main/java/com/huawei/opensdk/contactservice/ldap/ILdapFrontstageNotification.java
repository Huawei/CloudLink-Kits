package com.huawei.opensdk.contactservice.ldap;

/**
 * This interface is about ldap frontstage service event notify.
 * Ldap地址本业务事件通知接口
 */
public interface ILdapFrontstageNotification {

    /**
     * This is a callback function to handle the getting user's icon result.
     * 处理获取地址本联系人查询返回结果的回调
     * @param event  Indicates event
     *               获取联系人的结果事件
     * @param object Indicates contact info
     *               获取到的具体信息
     */
    void onEntLdapFrontstageNotify(LdapFrontstageConstant.Event event, Object object);
}
