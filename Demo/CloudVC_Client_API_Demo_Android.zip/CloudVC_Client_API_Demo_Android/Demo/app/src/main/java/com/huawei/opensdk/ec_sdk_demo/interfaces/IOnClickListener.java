package com.huawei.opensdk.ec_sdk_demo.interfaces;

public interface IOnClickListener {
    void IOnClick(int position);
}