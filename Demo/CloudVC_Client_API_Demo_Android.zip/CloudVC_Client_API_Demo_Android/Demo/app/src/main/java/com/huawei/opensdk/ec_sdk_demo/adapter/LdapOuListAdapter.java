package com.huawei.opensdk.ec_sdk_demo.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.huawei.opensdk.ec_sdk_demo.R;
import com.huawei.opensdk.ec_sdk_demo.beans.DeptDataInfo;
import com.huawei.opensdk.ec_sdk_demo.interfaces.IOnClickListener;

import java.util.ArrayList;

/**
 * The type ldap frontstage adapter.
 * Ldap地址本分组的适配层
 */
public class LdapOuListAdapter extends BaseAdapter {

    private Context context;
    private ArrayList<DeptDataInfo> ouDataList;
    private IOnClickListener onClickListener;

    public LdapOuListAdapter(Context context) {
        this.context = context;
        ouDataList = new ArrayList<>();
    }

    public void setDeptDataList(ArrayList<DeptDataInfo> deptNameList) {
        this.ouDataList = deptNameList;
    }

    public ArrayList<DeptDataInfo> getDeptDataList() {
        return ouDataList;
    }

    @Override
    public int getCount() {
        if (ouDataList.size() != 0) {
            return ouDataList.size();
        }
        return 0;
    }

    @Override
    public Object getItem(int position) {
        return ouDataList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        ViewHolder viewHolder;
        if (convertView == null) {
            viewHolder = new ViewHolder();
            convertView = LayoutInflater.from(context).inflate(R.layout.ldap_ou_item, null);
            viewHolder.tvOuText = (TextView) convertView.findViewById(R.id.tv_ou_text);
            viewHolder.vLineUnder = convertView.findViewById(R.id.v_line_under);
            convertView.setTag(viewHolder);
        } else {
            viewHolder = (ViewHolder) convertView.getTag();
        }

        DeptDataInfo deptDataInfo = ouDataList.get(position);
        String deptName = deptDataInfo.getDeptName();
        viewHolder.tvOuText.setText(deptName);

        if (ouDataList.size() > 0) {
            if (ouDataList.size() == 1) {
                viewHolder.vLineUnder.setVisibility(View.GONE);
            } else {
                if (position == ouDataList.size() - 1) {
                    viewHolder.vLineUnder.setVisibility(View.GONE);
                } else {
                    viewHolder.vLineUnder.setVisibility(View.VISIBLE);
                }
            }
        }

        viewHolder.tvOuText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onClickListener.IOnClick(position);
            }
        });

        return convertView;
    }

    public void setOnClickListener(IOnClickListener onClickListener) {
        this.onClickListener = onClickListener;
    }

    private static class ViewHolder {
        private TextView tvOuText;
        private View vLineUnder;
    }


}
