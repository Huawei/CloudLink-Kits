package com.huawei.opensdk.ec_sdk_demo.ui.ldap;

import android.content.Intent;
import android.view.View;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.huawei.ecterminalsdk.base.TsdkLdapContactsInfo;
import com.huawei.opensdk.ec_sdk_demo.R;
import com.huawei.opensdk.ec_sdk_demo.adapter.LdapFrontstageDetailAdapter;
import com.huawei.opensdk.ec_sdk_demo.beans.DeptDataInfo;
import com.huawei.opensdk.ec_sdk_demo.common.UIConstants;
import com.huawei.opensdk.ec_sdk_demo.ui.base.BaseActivity;

import java.util.ArrayList;

public class LdapFrontstageDetailActivity extends BaseActivity implements View.OnClickListener {

    private TsdkLdapContactsInfo ldapContactsInfo;
    private ImageView bookBack;
    private TextView tvTitle;
    private ListView detailList;

    @Override
    public void initializeData() {
        Intent intent = getIntent();
        ldapContactsInfo = (TsdkLdapContactsInfo) intent.getSerializableExtra(UIConstants.LDAP_CONTACTS_INFO);
    }

    @Override
    public void initializeComposition() {
        setContentView(R.layout.activity_ldap_frontstage_detail);
        bookBack = (ImageView)findViewById(R.id.book_back);
        tvTitle = (TextView)findViewById(R.id.title);
        detailList = (ListView)findViewById(R.id.detail_list);

        bookBack.setOnClickListener(this);

        String name = ldapContactsInfo.getName();
        tvTitle.setText(name);

        ArrayList<DeptDataInfo> deptDataInfoList= getData();
        LdapFrontstageDetailAdapter ldapFrontstageDetailAdapter = new LdapFrontstageDetailAdapter(this);
        detailList.setAdapter(ldapFrontstageDetailAdapter);
        ldapFrontstageDetailAdapter.setData(deptDataInfoList);
        ldapFrontstageDetailAdapter.notifyDataSetChanged();
    }

    private ArrayList<DeptDataInfo> getData() {
        ArrayList<DeptDataInfo> deptDataInfoList = new ArrayList<>();
        String accessNum = ldapContactsInfo.getAccessNum();
        String address = ldapContactsInfo.getAddress();
        String avtool = ldapContactsInfo.getAvtool();
        String chairPwd = ldapContactsInfo.getChairPwd();
        String confid = ldapContactsInfo.getConfid();
        String corpName = ldapContactsInfo.getCorpName();
        String deptName = ldapContactsInfo.getDeptName();
        String desc = ldapContactsInfo.getDesc();
        String device = ldapContactsInfo.getDevice();
        String duty = ldapContactsInfo.getDuty();
        String email = ldapContactsInfo.getEmail();
        String fax = ldapContactsInfo.getFax();
        int flow = ldapContactsInfo.getFlow();
        String flowStr = String.valueOf(flow);
        String gender = ldapContactsInfo.getGender();
        String homePhone = ldapContactsInfo.getHomePhone();
        String id = ldapContactsInfo.getId();
        String imageID = ldapContactsInfo.getImageID();
        String location = ldapContactsInfo.getLocation();
        String mobile = ldapContactsInfo.getMobile();
        String name1 = ldapContactsInfo.getName();
        String nickName = ldapContactsInfo.getNickName();
        String officePhone = ldapContactsInfo.getOfficePhone();
        String otherPhone = ldapContactsInfo.getOtherPhone();
        String position = ldapContactsInfo.getPosition();
        String qpinyin = ldapContactsInfo.getQpinyin();
        String signature = ldapContactsInfo.getSignature();
        String spinyin = ldapContactsInfo.getSpinyin();
        String staffNo = ldapContactsInfo.getStaffNo();
        String terminalType = ldapContactsInfo.getTerminalType();
        String tzone = ldapContactsInfo.getTzone();
        String ucAcc = ldapContactsInfo.getUcAcc();
        String uri = ldapContactsInfo.getUri();
        String webSite = ldapContactsInfo.getWebSite();
        String zip = ldapContactsInfo.getZip();

        DeptDataInfo deptDataInfo1  = new DeptDataInfo("accessNum",accessNum);
        DeptDataInfo deptDataInfo2  = new DeptDataInfo("address",address);
        DeptDataInfo deptDataInfo3  = new DeptDataInfo("avtool",avtool);
        DeptDataInfo deptDataInfo4  = new DeptDataInfo("chairPwd",chairPwd);
        DeptDataInfo deptDataInfo5  = new DeptDataInfo("confid",confid);
        DeptDataInfo deptDataInfo6  = new DeptDataInfo("corpName",corpName);
        DeptDataInfo deptDataInfo7  = new DeptDataInfo("deptName",deptName);
        DeptDataInfo deptDataInfo8  = new DeptDataInfo("desc",desc);
        DeptDataInfo deptDataInfo9  = new DeptDataInfo("device",device);
        DeptDataInfo deptDataInfo10 = new DeptDataInfo("duty",duty);
        DeptDataInfo deptDataInfo11 = new DeptDataInfo("email",email);
        DeptDataInfo deptDataInfo12 = new DeptDataInfo("fax",fax);
        DeptDataInfo deptDataInfo13 = new DeptDataInfo("flow",flowStr);
        DeptDataInfo deptDataInfo14 = new DeptDataInfo("gender",gender);
        DeptDataInfo deptDataInfo15 = new DeptDataInfo("homePhone",homePhone);
        DeptDataInfo deptDataInfo16 = new DeptDataInfo("id",id);
        DeptDataInfo deptDataInfo17 = new DeptDataInfo("imageID",imageID);
        DeptDataInfo deptDataInfo18 = new DeptDataInfo("location",location);
        DeptDataInfo deptDataInfo19 = new DeptDataInfo("mobile",mobile);
        DeptDataInfo deptDataInfo20 = new DeptDataInfo("name",name1);
        DeptDataInfo deptDataInfo21 = new DeptDataInfo("nickName",nickName);
        DeptDataInfo deptDataInfo22 = new DeptDataInfo("officePhone",officePhone);
        DeptDataInfo deptDataInfo23 = new DeptDataInfo("otherPhone",otherPhone);
        DeptDataInfo deptDataInfo24 = new DeptDataInfo("position",position);
        DeptDataInfo deptDataInfo25 = new DeptDataInfo("qpinyin",qpinyin);
        DeptDataInfo deptDataInfo26 = new DeptDataInfo("signature",signature);
        DeptDataInfo deptDataInfo27 = new DeptDataInfo("spinyin",spinyin);
        DeptDataInfo deptDataInfo28 = new DeptDataInfo("staffNo",staffNo);
        DeptDataInfo deptDataInfo29 = new DeptDataInfo("terminalType",terminalType);
        DeptDataInfo deptDataInfo30 = new DeptDataInfo("tzone",tzone);
        DeptDataInfo deptDataInfo31 = new DeptDataInfo("ucAcc",ucAcc);
        DeptDataInfo deptDataInfo32 = new DeptDataInfo("uri",uri);
        DeptDataInfo deptDataInfo33 = new DeptDataInfo("webSite",webSite);
        DeptDataInfo deptDataInfo34 = new DeptDataInfo("zip",zip);

        deptDataInfoList.add(deptDataInfo1  );
        deptDataInfoList.add(deptDataInfo2  );
        deptDataInfoList.add(deptDataInfo3  );
        deptDataInfoList.add(deptDataInfo4  );
        deptDataInfoList.add(deptDataInfo5  );
        deptDataInfoList.add(deptDataInfo6  );
        deptDataInfoList.add(deptDataInfo7  );
        deptDataInfoList.add(deptDataInfo8  );
        deptDataInfoList.add(deptDataInfo9  );
        deptDataInfoList.add(deptDataInfo10 );
        deptDataInfoList.add(deptDataInfo11 );
        deptDataInfoList.add(deptDataInfo12 );
        deptDataInfoList.add(deptDataInfo13 );
        deptDataInfoList.add(deptDataInfo14 );
        deptDataInfoList.add(deptDataInfo15 );
        deptDataInfoList.add(deptDataInfo16 );
        deptDataInfoList.add(deptDataInfo17 );
        deptDataInfoList.add(deptDataInfo18 );
        deptDataInfoList.add(deptDataInfo19 );
        deptDataInfoList.add(deptDataInfo20 );
        deptDataInfoList.add(deptDataInfo21 );
        deptDataInfoList.add(deptDataInfo22 );
        deptDataInfoList.add(deptDataInfo23 );
        deptDataInfoList.add(deptDataInfo24 );
        deptDataInfoList.add(deptDataInfo25 );
        deptDataInfoList.add(deptDataInfo26 );
        deptDataInfoList.add(deptDataInfo27 );
        deptDataInfoList.add(deptDataInfo28 );
        deptDataInfoList.add(deptDataInfo29 );
        deptDataInfoList.add(deptDataInfo30 );
        deptDataInfoList.add(deptDataInfo31 );
        deptDataInfoList.add(deptDataInfo32 );
        deptDataInfoList.add(deptDataInfo33 );
        deptDataInfoList.add(deptDataInfo34 );
        return deptDataInfoList;
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.book_back:
                finish();
                break;
            default:
                break;
        }
    }
}
