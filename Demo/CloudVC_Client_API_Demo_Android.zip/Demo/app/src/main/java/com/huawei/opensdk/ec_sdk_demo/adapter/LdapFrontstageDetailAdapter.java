package com.huawei.opensdk.ec_sdk_demo.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.huawei.opensdk.ec_sdk_demo.R;
import com.huawei.opensdk.ec_sdk_demo.beans.DeptDataInfo;

import java.util.ArrayList;

public class LdapFrontstageDetailAdapter extends BaseAdapter {

    private Context context;
    private ArrayList<DeptDataInfo> deptDataInfoList;

    public LdapFrontstageDetailAdapter(Context context) {
        this.context =context;
        deptDataInfoList = new ArrayList<>();
    }

    public void setData(ArrayList<DeptDataInfo> deptDataInfoList) {
        this.deptDataInfoList = deptDataInfoList;
    }

    @Override
    public int getCount() {
        if (deptDataInfoList.size() != 0) {
            return deptDataInfoList.size();
        }
        return 0;
    }

    @Override
    public Object getItem(int position) {
        return deptDataInfoList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder viewHolder;
        if (convertView == null) {
            viewHolder = new ViewHolder();
            convertView = LayoutInflater.from(context).inflate(R.layout.ldap_ou_item, null);
            viewHolder.tvOuText = (TextView) convertView.findViewById(R.id.tv_ou_text);
            viewHolder.rlytA = (RelativeLayout) convertView.findViewById(R.id.rlyt_a);
            viewHolder.rlytB = (RelativeLayout) convertView.findViewById(R.id.rlyt_b);
            viewHolder.tvK = (TextView) convertView.findViewById(R.id.tv_k);
            viewHolder.tvV = (TextView) convertView.findViewById(R.id.tv_v);
            convertView.setTag(viewHolder);
        } else {
            viewHolder = (ViewHolder) convertView.getTag();
        }

        viewHolder.tvOuText.setVisibility(View.GONE);
        viewHolder.rlytA.setVisibility(View.GONE);
        viewHolder.rlytB.setVisibility(View.VISIBLE);

        String corpName = deptDataInfoList.get(position).getCorpName();
        String deptName = deptDataInfoList.get(position).getDeptName();

        viewHolder.tvK.setText(corpName);
        viewHolder.tvV.setText(deptName);
        return convertView;
    }

    private static class ViewHolder {
        private TextView tvOuText;
        private TextView tvK;
        private TextView tvV;
        private RelativeLayout rlytA;
        private RelativeLayout rlytB;
    }
}
