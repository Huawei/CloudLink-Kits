package com.huawei.opensdk.ec_sdk_demo.ui.conference;

import com.huawei.opensdk.ec_sdk_demo.ui.base.MVPBaseActivity;
import com.huawei.opensdk.ec_sdk_demo.ui.base.MVPBasePresenter;

public class OneKeyJoinActivity extends MVPBaseActivity
{
    @Override
    protected Object createView()
    {
        return null;
    }

    @Override
    protected MVPBasePresenter createPresenter()
    {
        return null;
    }

    @Override
    public void initializeComposition()
    {

    }

    @Override
    public void initializeData()
    {

    }
}
