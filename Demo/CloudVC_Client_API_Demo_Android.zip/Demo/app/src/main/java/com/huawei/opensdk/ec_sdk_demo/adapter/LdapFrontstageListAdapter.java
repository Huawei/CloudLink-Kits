package com.huawei.opensdk.ec_sdk_demo.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.huawei.ecterminalsdk.base.TsdkLdapContactsInfo;
import com.huawei.opensdk.ec_sdk_demo.R;

import java.util.ArrayList;

/**
 * The type ldap frontstage adapter.
 * Ldap地址本适配层
 */
public class LdapFrontstageListAdapter extends BaseAdapter {

    private Context context;
    private ArrayList<TsdkLdapContactsInfo> ldapDataList;

    public LdapFrontstageListAdapter(Context context, ArrayList<TsdkLdapContactsInfo> ldapDataList) {
        this.context = context;
        this.ldapDataList = ldapDataList;
    }

    /**
     * Refresh the date(Contacts list).
     * @param adapterData the contacts list
     */
    public void notifyDataSetChanged(ArrayList<TsdkLdapContactsInfo> adapterData)
    {
        this.ldapDataList = adapterData;
        notifyDataSetChanged();
    }

    @Override
    public int getCount() {
        if(ldapDataList.size() != 0) {
            return ldapDataList.size();
        }
        return 0;
    }

    @Override
    public Object getItem(int position) {
        return ldapDataList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ContactViewHolder viewHolder;
        if(convertView == null) {
            viewHolder = new ContactViewHolder();
            convertView = LayoutInflater.from(context).inflate(R.layout.activity_enterprise_list,null);
            viewHolder.ivHead = (ImageView) convertView.findViewById(R.id.head);
            viewHolder.tvAccount = (TextView) convertView.findViewById(R.id.user_account);
            viewHolder.tvDept = (TextView) convertView.findViewById(R.id.dept);
            viewHolder.tvUri = (TextView) convertView.findViewById(R.id.uri);
            convertView.setTag(viewHolder);
        }
        else {
            viewHolder = (ContactViewHolder) convertView.getTag();
        }

        String name = ldapDataList.get(position).getName();
        String ucAcc = ldapDataList.get(position).getUcAcc();
        String uri = ldapDataList.get(position).getUri();

        String type;
        if (uri.contains("sip:")){
            type = "SIP";
        } else {
            type = "无";
        }

        viewHolder.tvUri.setVisibility(View.VISIBLE);
        viewHolder.ivHead.setVisibility(View.GONE);
        viewHolder.tvAccount.setText("名称: " + name);
        viewHolder.tvDept.setText("号码: " + ucAcc);
        viewHolder.tvUri.setText("类型" + type);

        return convertView;
    }

    /**
     * View-holding classes improve processing performance
     * to reduce the overhead of view memory consumption
     * 视图持有类，为减少视图占用内存的开销，提高处理性能
     */
    private static class ContactViewHolder {
        private ImageView ivHead;
        private TextView tvAccount;
        private TextView tvDept;
        private TextView tvUri;
    }
}
