package com.huawei.opensdk.ec_sdk_demo.beans;

public class DeptDataInfo {
    private String corpName;
    private String deptName;

    public DeptDataInfo()
    {

    }

    public DeptDataInfo(String corpName, String deptName) {
        this.corpName = corpName;
        this.deptName = deptName;
    }

    public String getCorpName() {
        return corpName;
    }

    public void setCorpName(String corpName) {
        this.corpName = corpName;
    }

    public String getDeptName() {
        return deptName;
    }

    public void setDeptName(String deptName) {
        this.deptName = deptName;
    }
}
